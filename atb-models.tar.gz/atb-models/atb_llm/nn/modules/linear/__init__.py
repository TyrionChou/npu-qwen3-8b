# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
from enum import Enum


class TransposeType(int, Enum):
    INVALID = -1
    NOT_TRANSPOSE = 0
    TRANSPOSE = 1
