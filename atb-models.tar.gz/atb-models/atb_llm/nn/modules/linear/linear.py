# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
import torch

from ..module import Module
from ...parameter import WeightParameter, Parameter
from ...network import Tensor, Node, get_default_net
from ....utils.quantize.quant_type import LinearTypeV2
from ....utils.quantize.pack_type import TransposeType


class Linear(Module):
    '''Base linear module, used for float tensor linear computation.'''
    linear_desc = LinearTypeV2.INVALID

    def __init__(self, prefix: str, output_dtype: torch.dtype, bias=False, **kwargs):
        super().__init__()
        self.weight = WeightParameter(prefix=prefix, suffix="weight", target_dtype=output_dtype)
        self.bias = Parameter(prefix=prefix, suffix="bias", target_dtype=output_dtype) if bias else None
        self.linear_desc = LinearTypeV2.FLOAT16 if output_dtype == torch.float16 else LinearTypeV2.BFLOAT16

    def __call__(
            self,
            input_tensor: Tensor
        ) -> Tensor:
        return self._forward(input_tensor)

    def _forward(
            self,
            input_tensor: Tensor,
        ) -> Tensor:
        out = Tensor()
        inputs = [input_tensor, Tensor(self.weight.name)]
        has_bias = False
        if self.bias is not None:
            inputs.append(Tensor(self.bias.name))
            has_bias = True
        param = {
            'hasBias': has_bias,
            'transposeB': self.weight.trans_flag == TransposeType.TRANSPOSE
        }
        node = Node('Linear', param, inputs, [out])
        get_default_net().push_node(node)
        get_default_net().push_weight_key(self.weight.name)
        return out
