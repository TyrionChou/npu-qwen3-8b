# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import torch

from .module import Module
from ..network import Tensor, Node, get_default_net
from ..parameter import Parameter


class RmsNorm(Module):
    def __init__(self, prefix: str, epsilon: float, output_dtype: torch.dtype, **kwargs):
        super().__init__()
        self.epsilon = epsilon
        self.weight = Parameter(prefix=prefix, suffix="weight", target_dtype=output_dtype)

    def __call__(self, input_tensor: Tensor):
        return self._forward(input_tensor)

    def _forward(self, input_tensor: Tensor) -> Tensor:
        out = Tensor()
        param = {'layerType':'RMS_NORM_NORM', 'epsilon': self.epsilon}
        node = Node('RmsNorm', param, [input_tensor, Tensor(self.weight.name)], [out])
        get_default_net().push_node(node)
        get_default_net().push_weight_key(self.weight.name)
        return out
