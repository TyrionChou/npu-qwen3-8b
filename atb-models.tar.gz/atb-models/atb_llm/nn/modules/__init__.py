# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from .module import (
    Module as Module,
    ModuleList as ModuleList
)
from .normalization import RmsNorm as RmsNorm
from .linear.linear import Linear as Linear