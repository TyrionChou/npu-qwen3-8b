# Copyright Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from torch import nn


class Module(nn.Module):
    def __init__(self):
        nn.Module.__init__(self)
        self._aliases = {}
    
    def add_aliases(self, alias_map: dict[str, str]):
        '''
        Update a mapping from alias to attribute name. For example, to get the attribute
        `foo` from alias `bar`, use `add_aliases({"bar": "foo"})` to register the alias.
        Then access the attribute `foo` by `getattr_by_alias("bar")`.
        '''
        self._aliases.update(alias_map)

    def getattr_by_alias(self, alias):
        if alias in self._aliases:
            attribute_name = self._aliases[alias]
            try:
                return getattr(self, attribute_name)
            except AttributeError as e:
                raise AttributeError(f"Alias mapping error: `{alias}` -> `{attribute_name}`."
                    f"Missing attribute: '{attribute_name}' not found in module. Possible causes: "
                    "1. Typo in attribute name when `add_aliases`. 2. Attribute not initialized in __init__."
                ) from e
        else:
            try:
                return getattr(self, alias)
            except AttributeError as e:
                raise AttributeError(
                    f"Attribute '{alias}' not found in module. Possible causes: 1. Typo in attribute name;"
                    "2. Attribute not initialized in __init__; 3. Alias not registered (use add_alias() to register)."
                ) from e


class ModuleList(nn.ModuleList):
    def __init__(self, modules):
        super().__init__(modules=modules)
