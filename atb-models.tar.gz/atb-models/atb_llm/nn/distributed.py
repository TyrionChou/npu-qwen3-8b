# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from enum import Enum
import json
from .network import Tensor, Node, get_default_net
from ..utils.initial import NPUSocInfo
from ..utils import file_utils


class AllReduceType(str, Enum):
    SUM = 'sum'
    PROD = 'prod'
    MAX = 'max'
    MIN = 'min'


backend = NPUSocInfo().communication_backend


def all_reduce(
    send_tensor: Tensor,
    rank: int,
    rank_size: int,
    rank_table_file: str = "",
    comm_id: int = -1,
    all_reduce_type: AllReduceType = AllReduceType.SUM
) -> Tensor:
    if rank_size == 1:
        return send_tensor

    recv_tensor = Tensor()
    param = {
        "rank": rank,
        "rankSize": rank_size,
        "backend": backend,
        "allReduceType": all_reduce_type,
        "rankTableFile": rank_table_file
    }
    if comm_id >= 0:
        param.update({"commDomain": str(comm_id)})
    node = Node('AllReduce', param, [send_tensor], [recv_tensor])
    get_default_net().push_node(node)
    return recv_tensor


def all_gather(
    send_tensor: Tensor,
    rank: int,
    rank_size: int,
    rank_ids: list | None = None,
    rank_table_file: str = "",
    comm_id: int = -1,
    group_id: int = 0,
    buffer_size: int = 128
) -> Tensor:

    if rank_size == 1:
        return send_tensor
    
    recv_tensor = Tensor()
    param = {
        "rank": rank,
        "rankSize": rank_size,
        "rankIds": rank_ids if rank_ids is not None else [],
        "backend": "hccl" if is_across_nodes(rank_table_file, rank_ids) else backend,
        "rankTableFile": rank_table_file,
        "groupId": group_id,
        "bufferSize": buffer_size
    }
    if comm_id >= 0:
        param.update({"commDomain": str(comm_id)})
    node = Node('AllGather', param, [send_tensor], [recv_tensor])
    get_default_net().push_node(node)
    return recv_tensor


def is_across_nodes(rank_table_file, rank_ids):
    if rank_table_file == "":
        return False

    with file_utils.safe_open(rank_table_file, 'r', encoding='utf-8') as f:
        ranktable = json.load(f)

    rank_device_dict = {}
    for server_info in ranktable.get("server_list", []):
        for idx, device_info in enumerate(server_info.get("device", [])):
            rank_device_dict[device_info.get("rank_id", -1)] = idx

    device_idx = -1
    for rank_id in rank_ids:
        if rank_device_dict.get(rank_id) != device_idx and device_idx != -1:
            return True
        device_idx = rank_device_dict.get(rank_id)

    return True
