# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from enum import Enum

from atb_llm.nn.network import Tensor, Node, get_default_net


class ReduceType(str, Enum):
    REDUCE_UNDEFINED = "REDUCE_UNDEFINED"
    REDUCE_MAX = "REDUCE_MAX"
    REDUCE_MIN = "REDUCE_MIN"
    REDUCE_SUM = "REDUCE_SUM"


def cos(x: Tensor):
    out = Tensor()
    param = {
        "elewiseType":"ELEWISE_COS",
    }
    node = Node('Elewise', param, [x], [out])
    get_default_net().push_node(node)
    return out


def sin(x: Tensor):
    out = Tensor()
    param = {
        "elewiseType":"ELEWISE_SIN",
    }
    node = Node('Elewise', param, [x], [out])
    get_default_net().push_node(node)
    return out


def neg(x: Tensor):
    out = Tensor()
    param = {
        "elewiseType":"ELEWISE_NEG",
    }
    node = Node('Elewise', param, [x], [out])
    get_default_net().push_node(node)
    return out


def logical_not(x: Tensor):
    out = Tensor()
    param = {
        "elewiseType":"ELEWISE_LOGICAL_NOT",
    }
    node = Node('Elewise', param, [x], [out])
    get_default_net().push_node(node)
    return out


def logical_or(x: Tensor, y: Tensor):
    out = Tensor()
    param = {
        "elewiseType":"ELEWISE_LOGICAL_OR",
    }
    node = Node('Elewise', param, [x, y], [out])
    get_default_net().push_node(node)
    return out


def logical_and(x: Tensor, y: Tensor):
    out = Tensor()
    param = {
        "elewiseType":"ELEWISE_LOGICAL_AND",
    }
    node = Node('Elewise', param, [x, y], [out])
    get_default_net().push_node(node)
    return out


def eq(x: Tensor, y: Tensor):
    out = Tensor()
    param = {
        "elewiseType":"ELEWISE_EQUAL",
    }
    node = Node('Elewise', param, [x, y], [out])
    get_default_net().push_node(node)
    return out


def reduce_max(x: Tensor, axis: list[int]):
    out = Tensor()
    node = Node("Reduce", {"reduceType": ReduceType.REDUCE_MIN, "axis": axis}, [x], [out])
    get_default_net().push_node(node)
    return out


def reduce_min(x: Tensor, axis: list[int]):
    out = Tensor()
    node = Node("Reduce", {"reduceType": ReduceType.REDUCE_MIN, "axis": axis}, [x], [out])
    get_default_net().push_node(node)
    return out


def reduce_sum(x: Tensor, axis: list[int]):
    out = Tensor()
    node = Node("Reduce", {"reduceType": ReduceType.REDUCE_SUM, "axis": axis}, [x], [out])
    get_default_net().push_node(node)
    return out


def std(x: Tensor):
    out = Tensor()
    param = {}
    node = Node("Std", param, [x], [out])
    get_default_net().push_node(node)
    return out


def norm(x: Tensor):
    out = Tensor()
    param = {}
    node = Node("VectorNorm", param, [x], [out])
    get_default_net().push_node(node)
    return out


def matmul(x: Tensor,
           weight: Tensor,
           bias: Tensor = None,
           transpose_a: bool = False,
           transpose_b: bool = True,
           has_bias: bool = True,
           out_data_type: str = "ACL_DT_UNDEFINED",
           en_accum: bool = False):
    out = Tensor()
    inputs = [x, weight] + ([bias] if has_bias else [])
    param = {
        "transposeA": transpose_a,
        "transposeB": transpose_b,
        "hasBias": has_bias,
        "outDataType": out_data_type,
        "enAccum": en_accum
    }
    node = Node("Linear", param, inputs, [out])
    get_default_net().push_node(node)
    return out
