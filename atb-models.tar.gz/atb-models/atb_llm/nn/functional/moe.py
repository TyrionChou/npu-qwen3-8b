# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

from atb_llm.nn.network import Tensor, Node, get_default_net


def moe_topk_softmax(input_tensor: Tensor, topk_num: int) -> list[Tensor]:
    output = Tensor()
    expert_idx_out = Tensor()
    row_idx_out = Tensor()
    outputs = [output, expert_idx_out, row_idx_out]
    param = {
        "topkNum": topk_num
    }
    node = Node('MoeTopkSoftmax', param, [input_tensor], outputs)
    get_default_net().push_node(node)
    return outputs


def moe_init_routing(
        input_tensor: Tensor,
        expert_idx: Tensor,
        topk_num: int,
        expert_num: int) -> list[Tensor]:
    expanded_x_out = Tensor()
    expanded_row_idx_out = Tensor()
    expert_tokens_count_or_cumsum_out = Tensor()
    outputs = [expanded_x_out, expanded_row_idx_out, expert_tokens_count_or_cumsum_out]
    param = {
        "topkNum": topk_num,
        "expertNum": expert_num
    }
    node = Node('MoeInitRouting', param, [input_tensor, expert_idx], outputs)
    get_default_net().push_node(node)
    return outputs


def moe_token_unpermute(
        permuted_tokens: Tensor,
        sorted_indices: Tensor,
        experts_weights: Tensor) -> Tensor:
    param = {}
    output = Tensor()
    node = Node('MoeTokenUnpermute', param, [permuted_tokens, sorted_indices, experts_weights], [output])
    get_default_net().push_node(node)
    return output


def gating(
        topk: Tensor,
        idx_arr: Tensor,
        topk_expert_num: int,
        cum_sum_num: int,
        cum_sum_int64: bool = False,
        device_expert: list[int] = None) -> list[Tensor]:
    param = {
        "topkExpertNum": topk_expert_num,
        "cumSumNum": cum_sum_num,
        "cumSumInt64": cum_sum_int64,
    }
    token_index = Tensor()
    cum_sum = Tensor()
    original_index = Tensor()
    outputs = [token_index, cum_sum, original_index]
    if device_expert:
        param["deviceExpert"] = device_expert
        valid_index = Tensor()
        outputs.append(valid_index)
    node = Node('Gating', param, [topk, idx_arr], outputs)
    get_default_net().push_node(node)
    return outputs


def group_topk(input_tensor: Tensor, index: Tensor, group_num=1, k=0):
    param = {
        "groupNum": group_num,
        "k": k
    }
    node = Node('GroupTopk', param, [input_tensor, index], [input_tensor])
    get_default_net().push_node(node)
