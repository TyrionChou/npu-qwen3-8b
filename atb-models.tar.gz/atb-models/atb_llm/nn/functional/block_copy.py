# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.

from ..network import Tensor, Node, get_default_net


def copy_blocks(key_cache: Tensor, value_cache: Tensor,
               src_block_indices: Tensor, dst_block_indices: Tensor,
               cum_sum: Tensor):
    param = {}
    input_tensor = [key_cache, value_cache, src_block_indices, dst_block_indices, cum_sum]
    outputs = {}
    node = Node('BlockCopy', param, input_tensor, outputs)
    get_default_net().push_node(node)
 