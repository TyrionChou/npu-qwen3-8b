# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
from atb_llm.nn.network import Tensor, Node, get_default_net


def dynamic_quant(x: Tensor) -> list[Tensor]:
    param = {}
    y = Tensor()
    scale = Tensor()
    node = Node('DynamicQuant', param, [x], [y, scale])
    get_default_net().push_node(node)
    return [y, scale]
