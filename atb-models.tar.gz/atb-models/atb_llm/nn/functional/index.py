# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from atb_llm.nn.network import Tensor, Node, get_default_net


def repeat(input_tensor: Tensor, multiples: list[int] = None):
    out = Tensor()
    param = {
        "multiples": multiples
    }
    node = Node('Repeat', param, [input_tensor], [out])
    get_default_net().push_node(node)
    return out


def sort(input_tensor: Tensor, num: int = 0):
    out = Tensor()
    indices = Tensor()
    param = {
        "num": [num]
    }
    node = Node('Sort', param, [input_tensor], [out, indices])
    get_default_net().push_node(node)
    return out, indices


def argsort(input_tensor: Tensor):
    out = Tensor()
    param = {}
    node = Node('Argsort', param, [input_tensor], [out])
    get_default_net().push_node(node)
    return out
