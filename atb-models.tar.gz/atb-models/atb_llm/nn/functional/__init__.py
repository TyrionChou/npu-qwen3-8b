# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from .math import (cos, sin, neg, logical_not, logical_or, logical_and, eq, reduce_max, reduce_min, reduce_sum,
                   std, norm, matmul)
from .position_embedding import rope
from .attention.flash_attention import flash_attention
from .attention.paged_attention import paged_attention, MaskType
from .activation import ActType, GeluMode, activation, softmax
from .block_copy import copy_blocks
from .quantization import dynamic_quant
from .index import repeat, sort, argsort
from .moe import moe_topk_softmax, moe_token_unpermute, gating, moe_init_routing, group_topk
