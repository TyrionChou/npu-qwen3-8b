# Copyright (c) Huawei Technologies Co., Ltd. 2025-2024. All rights reserved.
from typing import List

import torch
from torch import nn
import torch_npu

from .modules.linear import TransposeType
from .network import Format
from ..utils.env import ENV
from ..utils.initial import NPUSocInfo
from ..utils.loader.weight_loader import WeightLoader
from ..utils.log import print_log, logger


class Parameter(nn.Parameter):
    def __new__(cls, **kwargs):
        return super().__new__(cls, data=None, requires_grad=False)

    def __init__(self, prefix: str, suffix: str, target_dtype: torch.dtype, **kwargs):
        self.prefix = prefix
        self.suffix = suffix
        self.target_dtype = target_dtype
        self.format_ = Format.ND
        super().__init__()

    @property
    def name(self):
        return f"{self.prefix}.{self.suffix}"

    def load_whole_weight(self, weight_tool: WeightLoader, prefixes: List[str], **kwargs):
        weight_tensors = [weight_tool.get_tensor(f"{p}.{self.suffix}") for p in prefixes]
        if len(weight_tensors) > 1:
            weight_tensors = [torch.cat(weight_tensors)]
        self.data = weight_tensors[0].to(self.target_dtype)

    def load_parallel_weight(self, weight_tool: WeightLoader, prefixes: List[str], dim: int, **kwargs):
        weight_tensors = [weight_tool.get_sharded(f"{p}.{self.suffix}", dim=dim) for p in prefixes]
        if len(weight_tensors) > 1:
            weight_tensors = [torch.cat(weight_tensors)]
        self.data = weight_tensors[0].to(self.target_dtype)


class WeightParameter(Parameter):
    soc_info = None

    def __init__(self, prefix: str, suffix: str, target_dtype: torch.dtype):
        super().__init__(prefix, suffix, target_dtype)
        self.trans_flag = TransposeType.TRANSPOSE
        if not self.soc_info:
            self.set_soc_info()

    @classmethod
    def set_soc_info(cls):
        cls.soc_info = NPUSocInfo()

    def weight_format_cast(self, enable_nd_nz: bool):
        if enable_nd_nz:
            tensor = self.data
            self.format_ = Format.NZ
            torch_npu.npu_format_cast_(tensor, 29)
            self.data = tensor
            print_log(ENV.rank, logger.debug, f"Tensor trans to {torch_npu.get_npu_format(self.data)}")

    def set_transpose(self, trans_flag: TransposeType):
        if trans_flag != TransposeType.INVALID and self.trans_flag != trans_flag:
            if trans_flag != TransposeType.TRANSPOSE:
                self.trans_flag = trans_flag
            if trans_flag == TransposeType.NOT_TRANSPOSE:
                self.data = torch.transpose(self.data, 0, 1).contiguous()

    def check_transpose(self, weight: torch.Tensor):
        if self.soc_info.need_nz or not ENV.auto_transpose_enable:
            return TransposeType.TRANSPOSE
        
        if self.soc_info.matmul_nd_nz:
            # transpose weights to [k, n] when using nz format
            return TransposeType.NOT_TRANSPOSE

        is_k_divisible = weight.shape[1] % 256 == 0
        is_n_divisible = weight.shape[0] % 256 == 0
        if not is_k_divisible and is_n_divisible:
            return TransposeType.NOT_TRANSPOSE
        return TransposeType.TRANSPOSE

    def transpose_weight_as_need(self):
        self.set_transpose(self.check_transpose(self.data))

    def load_parallel_weight(self, weight_tool: WeightLoader, prefixes: List[str], **kwargs):
        super().load_parallel_weight(weight_tool, prefixes, **kwargs)
        self.transpose_weight_as_need()
