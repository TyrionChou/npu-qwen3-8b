# coding=utf-8
#  Copyright 2022 EleutherAI and the HuggingFace Inc. team. All rights reserved.
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
#
# This code is based on EleutherAI's GPT-NeoX library and the GPT-NeoX
# and OPT implementations in this library. It has been modified from its
# original forms to accommodate minor architectural differences compared
# to GPT-NeoX and OPT used by the Meta AI team that trained the model.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import torch
from torch import nn
from atb_llm.utils.layers import (
    TensorParallelEmbedding,
    TensorEmbedding,
    TensorReplicatedLinear,
    TensorParallelRowLinear,
    PositionRotaryEmbedding,
    TensorParallelColumnLinear,
)
from atb_llm.utils.quantize.pack_type import PackType, calc_linear_pack_type
from atb_llm.models.base.modeling import MLP
from atb_llm.utils.log import logger
from atb_llm.utils.log.error_code import ErrorCode



class MiniCpm3RMSNorm(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        """
        MiniCpmRMSNorm is equivalent to T5LayerNorm
        """
        super().__init__()

        weight = weights.get_tensor(f"{prefix}.weight")
        self.weight = nn.Parameter(weight)
        self.variance_epsilon = eps


class FlashMiniCpm3Attention(nn.Module):
    def __init__(self, prefix, config, weights):
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.attention_dropout = config.attention_dropout
        self.max_position_embeddings = config.max_position_embeddings
        self.rope_theta = config.rope_theta
        self.q_lora_rank = config.q_lora_rank
        self.qk_rope_head_dim = config.qk_rope_head_dim
        self.kv_lora_rank = config.kv_lora_rank
        self.v_head_dim = config.v_head_dim
        self.qk_nope_head_dim = config.qk_nope_head_dim
        self.q_head_dim = config.qk_nope_head_dim + config.qk_rope_head_dim
        self.num_key_value_heads = config.num_key_value_heads
        self.head_size = self.hidden_size // self.num_heads

        linear_names = []
        self.q_a_proj = TensorReplicatedLinear.load(
            config,
            prefix=f"{prefix}.q_a_proj",
            weights=weights,
            bias=False,
        )
        linear_names.append(f"{prefix}.q_a_proj")
        self.q_b_proj = TensorParallelColumnLinear.load(
            config,
            prefix=f"{prefix}.q_b_proj",
            weights=weights,
            bias=False,
        )
        linear_names.append(f"{prefix}.q_b_proj")
        self.kv_a_proj_with_mqa = TensorReplicatedLinear.load(
            config,
            prefix=f"{prefix}.kv_a_proj_with_mqa",
            weights=weights,
            bias=False,
        )
        linear_names.append(f"{prefix}.kv_a_proj_with_mqa")
        self.kv_b_proj = TensorParallelColumnLinear.load(
            config,
            prefix=f"{prefix}.kv_b_proj",
            weights=weights,
            bias=False,
        )
        linear_names.append(f"{prefix}.kv_b_proj")
        self.o_proj = TensorParallelRowLinear.load(
            config,
            prefix=f"{prefix}.o_proj",
            weights=weights,
            bias=False,
        )
        linear_names.append(f'{prefix}.o_proj')
        
        self.kv_a_layernorm = MiniCpm3RMSNorm(prefix=f"{prefix}.kv_a_layernorm", weights=weights)
        self.q_a_layernorm = MiniCpm3RMSNorm(prefix=f"{prefix}.q_a_layernorm", weights=weights)

        layer_prefix = '.'.join(prefix.split('.')[:-1])
        norm_name = f'{layer_prefix}.input_layernorm'
        self.pack_type = calc_linear_pack_type(weights, linear_names, norm_name)
        self.softmax_scale = self.q_head_dim ** -0.5
        self.rotary_emb = PositionRotaryEmbedding.static(
            dim=self.qk_rope_head_dim, base=self.rope_theta, device="cpu").to(weights.device)
        self.num_groups = self.num_heads // self.num_key_value_heads
        self.kv_head_mapping = torch.arange(
            0, self.num_key_value_heads, dtype=torch.int32, device=weights.device
        ).repeat_interleave(self.num_groups)

        self.prefix = prefix


class MiniCpm3MLP(MLP):
    def __init__(self, prefix, config, weights, **kwargs):
        super().__init__(prefix, config, weights, **kwargs)
        self.load_weights(**kwargs)


class FlashMiniCpm3Layer(nn.Module):
    def __init__(self, layer_id, config, weights, model_prefix="model"):
        super().__init__()
        prefix = f"{model_prefix}.layers.{layer_id}"
        self.self_attn = FlashMiniCpm3Attention(
            prefix=f"{prefix}.self_attn", config=config, weights=weights
        )
        self.mlp = MiniCpm3MLP(prefix=f"{prefix}.mlp", config=config, weights=weights)

        if self.self_attn.pack_type in [PackType.ALL_FP, PackType.ALL_W8A8, PackType.ALL_W4A16, PackType.ALL_W8A16]:
            self.input_layernorm = MiniCpm3RMSNorm(
                prefix=f"{prefix}.input_layernorm", weights=weights, eps=config.rms_norm_eps
            )
        else:
            msg = f"Not support pack type of self attention: {self.self_attn.pack_type}"
            logger.error(
                msg,
                ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE
            )
            raise ValueError(msg)

        if self.mlp.pack_type in [PackType.ALL_FP, PackType.ALL_W8A8, PackType.ALL_W4A16, PackType.ALL_W8A16]:
            self.post_attention_layernorm = MiniCpm3RMSNorm(
                prefix=f"{prefix}.post_attention_layernorm",
                weights=weights,
                eps=config.rms_norm_eps,
            )
        else:
            msg = f"Not support pack type of mlp:  {self.mlp.pack_type}"
            logger.error(
                msg,
                ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE
            )
            raise ValueError(msg)


class FlashMiniCpm3Model(nn.Module):
    def __init__(self, config, weights, model_prefix="model"):
        super().__init__()

        process_group = weights.process_group
        self.tp_rank = process_group.rank()
        self.tp_world_size = process_group.size()
        self.parallel_embedding = False
        self.embed_tokens = (TensorParallelEmbedding if self.parallel_embedding else TensorEmbedding)(
            prefix=f"{model_prefix}.embed_tokens", weights=weights
        )
        self.layers = nn.ModuleList(
            [
                FlashMiniCpm3Layer(
                    layer_id,
                    config,
                    weights,
                    model_prefix
                )
                for layer_id in range(config.num_hidden_layers)
            ]
        )
        self.norm = MiniCpm3RMSNorm(prefix=f"{model_prefix}.norm", weights=weights, eps=config.rms_norm_eps)

        self.gradient_checkpointing = False
        self.head_size = self.layers[0].self_attn.head_size
        self.num_heads = self.layers[0].self_attn.num_heads
        self.num_key_value_heads = self.layers[0].self_attn.num_key_value_heads
