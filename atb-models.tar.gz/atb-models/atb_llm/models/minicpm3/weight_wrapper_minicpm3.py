# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
import torch
from atb_llm.utils.data.weight_wrapper import NormWrapper, WeightWrapper, get_module
from atb_llm.utils.quantize.pack_type import LinearType
from atb_llm.utils.log import logger
from atb_llm.utils.log.error_code import ErrorCode


class MiniCpm3AttnWrapper(NormWrapper):
    def __init__(self,
                 norm_name,
                 wrapper_name,
                 num_attention_heads,
                 num_key_value_heads,
                 qk_nope_head_dim,
                 qk_rope_head_dim,
                 q_lora_rank,
                 kv_lora_rank,
                 v_head_dim):
        super().__init__(norm_name)
        self.wrapper_name = wrapper_name
        self.num_attention_heads = num_attention_heads
        self.num_key_value_heads = num_key_value_heads
        self.qk_nope_head_dim = qk_nope_head_dim
        self.qk_rope_head_dim = qk_rope_head_dim
        self.q_lora_rank = q_lora_rank
        self.kv_lora_rank = kv_lora_rank
        self.q_head_dim_before = qk_nope_head_dim + qk_rope_head_dim
        self.k_head_dim = kv_lora_rank + qk_rope_head_dim
        self.v_head_dim = v_head_dim

        self.attn_linear_types = []
        self.mlp_linear_types = []
        self.attn_linear_transpose_types = []
        self.mlp_linear_transpose_types = []


class MiniCpm3WeightWrapper(WeightWrapper):
    def __init__(self, soc_info, tp_rank, attn_wrapper, mlp_wrapper):
        super().__init__(soc_info, tp_rank, None, mlp_wrapper)
        self.attn_wrapper = attn_wrapper

        self.attn_linear_types = []
        self.mlp_linear_types = []
        self.attn_linear_transpose_types = []
        self.mlp_linear_transpose_types = []

    @staticmethod
    def preprocess_kv_weights(kv_b_proj_weight, mla_wrapper):
        kv_b_proj_weight = kv_b_proj_weight.reshape(mla_wrapper.num_key_value_heads,
                                                    mla_wrapper.qk_nope_head_dim + mla_wrapper.v_head_dim,
                                                    mla_wrapper.kv_lora_rank)
        k_b_proj_preprocessed = kv_b_proj_weight[:, :mla_wrapper.qk_nope_head_dim, :].contiguous()
        v_b_proj_preprocessed = kv_b_proj_weight[:, mla_wrapper.qk_nope_head_dim:, :].transpose(1, 2).contiguous()

        return k_b_proj_preprocessed, v_b_proj_preprocessed
    
    @staticmethod
    def trans_rope_weight(weight, rope_dim):
        weight_1 = weight[..., -rope_dim:: 2, :].contiguous()
        weight_2 = weight[..., -rope_dim + 1:: 2, :].contiguous()
        weight[..., -rope_dim:, :] = torch.cat([weight_1, weight_2], dim=-2)

        return weight.contiguous()

    @staticmethod
    def view_tensor(weight, mla_wrapper, proj_name, pre_view=True):
        if proj_name == "projq":
            if pre_view:
                return weight.view(mla_wrapper.num_attention_heads, mla_wrapper.q_head_dim_before, -1).contiguous()
            else:
                return weight.view(mla_wrapper.num_attention_heads * mla_wrapper.q_head_dim_before, -1).contiguous()
        elif proj_name == "projk":
            return weight.view((mla_wrapper.k_head_dim), -1).contiguous()
        else:
            msg = f"`proj_name`'s type field must be one of ['projq', 'projk'], " \
                  f"got {proj_name}"
            logger.error(msg, ErrorCode.ATB_MODELS_EXECUTION_FAILURE)
            raise ValueError(msg)

    def preprocess_linear_for_rope(self, linear, mla_wrapper, quantize_type, proj_name):
        weight = linear.weight.data
        weight = self.view_tensor(weight, mla_wrapper, proj_name=proj_name, pre_view=True)
        weight = self.trans_rope_weight(weight, mla_wrapper.qk_rope_head_dim)
        linear.weight.data = self.view_tensor(weight, mla_wrapper, proj_name=proj_name, pre_view=False)

    def register_absorbed_linear_wrapper(self, linear, mla_wrapper, quantize_type):
        k_b_proj, v_b_proj = self.preprocess_kv_weights(linear.weight.data, mla_wrapper)
        self.register_absorbed_linear(linear, k_b_proj)
        self.register_absorbed_linear(linear, v_b_proj)

    def register_absorbed_linear(self, linear, weight):
        trans_flag = linear.trans_flag
        self.weights.append(weight)
        self.weights.append(self.placeholder)
        self.weights.extend([self.placeholder] * 4)
        self.layer_linear_type.append(LinearType.FP)
        self.layer_linear_transpose_types.append(trans_flag)
        # linear param no use temporary when no quantization is applied
    
    def register_layer_attn(self, layer, wrapper, quantize_type):
        wrapper_module = get_module(layer, wrapper.wrapper_name)
        pack_type = wrapper_module.pack_type
        self.register_layer_norm(layer, wrapper, pack_type)

        self.register_linear_wrapper(wrapper_module.q_a_proj.linear, quantize_type)
        self.register_norm(wrapper_module.q_a_layernorm)
        self.register_linear_wrapper(wrapper_module.q_b_proj.linear, quantize_type)

        self.register_linear_wrapper(wrapper_module.kv_a_proj_with_mqa.linear, quantize_type)
        self.register_norm(wrapper_module.kv_a_layernorm)

        self.register_absorbed_linear_wrapper(wrapper_module.kv_b_proj.linear, wrapper, quantize_type)
        self.register_linear_wrapper(wrapper_module.o_proj.linear, quantize_type)


    def register_layer(self, layer, quantize_type):
        self.layer_linear_type.clear()
        self.layer_linear_transpose_types.clear()
        self.register_layer_attn(layer, self.attn_wrapper, quantize_type)
        self.attn_linear_types.append(self.layer_linear_type.copy())
        self.attn_linear_transpose_types.append(self.layer_linear_transpose_types.copy())

        self.layer_linear_type.clear()
        self.layer_linear_transpose_types.clear()
        self.register_layer_mlp(layer, self.mlp_wrapper, quantize_type)
        self.mlp_linear_types.append(self.layer_linear_type.copy())
        self.mlp_linear_transpose_types.append(self.layer_linear_transpose_types.copy())

        attn_pack_type = get_module(layer, self.attn_wrapper.wrapper_name).pack_type
        mlp_pack_type = get_module(layer, self.mlp_wrapper.wrapper_name).pack_type
        self.pack_quant_type.append([attn_pack_type, mlp_pack_type])
