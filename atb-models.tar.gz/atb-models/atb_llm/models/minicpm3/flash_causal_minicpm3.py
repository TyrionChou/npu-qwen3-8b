#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import json
from typing import Optional, List, Tuple
import torch
from ..base.flash_causal_lm import FlashForCausalLM
from .modeling_minicpm3 import FlashMiniCpm3Model
from .config_minicpm3 import MiniCpm3Config
from ...utils.layers import load_column_multi
from .weight_wrapper_minicpm3 import MiniCpm3AttnWrapper, MiniCpm3WeightWrapper
from ...utils.data.weight_wrapper import MlpWrapper
from ...utils.layers.embedding.position_rotary_embedding import PositionEmbeddingType
from ...utils.layers import PositionRotaryEmbedding
from ...utils.layers.norm.fast_layer_norm import NormType
from ...utils.env import ENV
from ...utils.log import logger
from ...utils.log.error_code import ErrorCode

CPP_MINICPM3_MODEL_CLASS_NAME = "minicpm3_MiniCPM3DecoderModel"


class FlashMinicpm3ForCausalLM(FlashForCausalLM):
    def __init__(self, config, weights, lmhead_prefix="model.embed_tokens", model_prefix="model", **kwargs):
        super().__init__(config, weights)
    
        self.model = FlashMiniCpm3Model(config, weights, model_prefix)

        self.lm_head = load_column_multi(
            config,
            prefixes=[lmhead_prefix],
            weights=weights,
            head_size=1,
            lm_head=True,
        )
        self.in_tensor_length = 12
        self.acl_encoder_operation_inputs: list[None | torch.Tensor] = [None] * self.in_tensor_length
        self.acl_decoder_operation_inputs: list[None | torch.Tensor] = [None] * self.in_tensor_length
        self.position_embedding_type = "ROPE"
        self.scale_emb = config.scale_emb
        self.scale_depth = config.scale_depth
        self.dim_model_base = config.dim_model_base
        self.transdata_operation = torch.classes.OperationTorch.OperationTorch("TransdataOperation")
        self.transdata_param = json.dumps({})  
        self.transdata_operation.set_param(self.transdata_param)
        self.placeholder = torch.zeros(1, dtype=self.dtype, device="npu")
        self.lm_head_indices_fake = torch.tensor([0], dtype=torch.int64, device="npu")
        self.acl_param = None
        self.ascend_weight = None
        self.cos_embed = None
        self.sin_embed = None
        self.skip_word_embedding = False
        self.q_lora_rank = config.q_lora_rank
        self.kv_lora_rank = config.kv_lora_rank
        self.v_head_dim = config.v_head_dim
        self.qk_nope_head_dim = config.qk_nope_head_dim
        self.qk_rope_head_dim = config.qk_rope_head_dim
        self.softmax_scale = (config.qk_nope_head_dim + config.qk_rope_head_dim) ** (-0.5)
        self.rotary_embedding = PositionRotaryEmbedding.static(dim=self.qk_rope_head_dim, base=self.rope_theta,
                                                        device="cpu", scaling_factor=self.scaling_factor)

    def init_position_rotary_embedding(self,
                                       position_ids: torch.Tensor,
                                       max_seq_len: int):
        self.rotary_embedding.update_long_rope_minicpm3_cos_sin_cache_total(self.dtype,
                                                        position_ids.device, max_seq_len)
        self.cos_embed = self.rotary_embedding.get_cos_cached_total()
        self.sin_embed = self.rotary_embedding.get_sin_cached_total()

    def init_ascend_operations(self, config: MiniCpm3Config):
        self.acl_encoder_operation = torch.classes.ModelTorch.ModelTorch(CPP_MINICPM3_MODEL_CLASS_NAME)
        self.acl_decoder_operation = torch.classes.ModelTorch.ModelTorch(CPP_MINICPM3_MODEL_CLASS_NAME)

    def get_weight_wrapper(self):
        attn_wrapper = MiniCpm3AttnWrapper(
            norm_name='input_layernorm',
            wrapper_name='self_attn',
            num_attention_heads=self.num_attention_heads,
            num_key_value_heads=self.num_key_value_heads,
            qk_nope_head_dim=self.config.qk_nope_head_dim,
            qk_rope_head_dim=self.config.qk_rope_head_dim,
            q_lora_rank=self.config.q_lora_rank,
            kv_lora_rank=self.config.kv_lora_rank,
            v_head_dim=self.config.v_head_dim
        )
        mlp_wrapper = MlpWrapper(
            norm_name='post_attention_layernorm',
            wrapper_name='mlp',
            pack_name='gate_up_proj',
            sep_names=['gate_proj', 'up_proj'],
            down_name='down_proj'
        )

        weight_wrapper = MiniCpm3WeightWrapper(self.soc_info, self.tp_rank,
                                                attn_wrapper, mlp_wrapper)
        weight_wrapper.register_embedding(self.model.embed_tokens)
        return weight_wrapper

    def get_weights(self):
        weight_wrapper = self.get_weight_wrapper()
        for i in range(self.num_layers):
            layer = self.model.layers[i]
            weight_wrapper.register_layer(layer, self.quantize)

            if self.soc_info.need_nz:
                del layer.self_attn
                del layer.mlp
                del layer.post_attention_layernorm
        weight_wrapper.register_model_norm(self.model.norm)
        weight_wrapper.register_model_lmhead(self.lm_head)
        return weight_wrapper
    
    def init_ascend_weight(self):
        weight_wrapper = self.get_weights()
        self.ascend_weight = weight_wrapper.weights
        pack_quant_configs = weight_wrapper.pack_quant_type
        if self.position_embedding_type == "ROPE":
            position_embedding_type = PositionEmbeddingType.ROPE
        else:
            position_embedding_type = PositionEmbeddingType.ALIBI

        attn_linear_types = weight_wrapper.attn_linear_types
        mlp_linear_types = weight_wrapper.mlp_linear_types

        attn_linear_transpose_types = weight_wrapper.attn_linear_transpose_types
        mlp_linear_transpose_types = weight_wrapper.mlp_linear_transpose_types
        
        coder_param = {
            "normEps": self.config.rms_norm_eps,
            "normType": NormType.RMS_NORM,
            "numAttentionHeadsPerRank": self.num_attention_heads,
            "hiddenSizePerAttentionHead": self.head_size,
            "numKeyValueHeadsPerRank": self.num_key_value_heads,
            "skipWordEmbedding": False,
            "isUnpadInputs": True,
            "isFA": False,
            "isBF16": self.dtype == torch.bfloat16,
            "rank": self.tp_rank,
            "qLoraRank": self.config.q_lora_rank if self.config.q_lora_rank is not None else 0,
            "kvLoraRank": self.config.kv_lora_rank,
            "qkNopeHeadDim": self.config.qk_nope_head_dim,
            "qkRopeHeadDim": self.config.qk_rope_head_dim,
            "softmaxScale": self.softmax_scale,
            "worldSize": self.tp_world_size,
            "backend": self.soc_info.communication_backend,
            "hiddenSize": self.hidden_size,
            "rankTableFile": ENV.rank_table_file,
            "packQuantType": pack_quant_configs,

            "attnLinearQuantType": attn_linear_types,
            "mlpLinearQuantType": mlp_linear_types,
            "attnLinearTransposeType": attn_linear_transpose_types,
            "mlpLinearTransposeType": mlp_linear_transpose_types,

            "isEmbeddingParallel": self.model.parallel_embedding,
            "isLmHeadParallel": True,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
            "enableSwiGLU": False if self.soc_info.need_nz else True,
            "enableKvQuant": self.config.quantization_config.kv_quant_type is not None,
            "positionEmbeddingType": position_embedding_type,
            "enableAddNorm": False,
            "enableCompressHead": self.compress_head_enable,
            "numHiddenLayers": self.config.num_hidden_layers,
            "scale_emb": self.scale_emb,
            "scale_depth": self.scale_depth,
            "dim_model_base": self.dim_model_base,
            "enableSpeculate": False,
        }
        encoder_param = {
            **coder_param, "isPrefill": True, "enableLcoc": self.lcoc_enable,
            "skipWordEmbedding": self.skip_word_embedding
        }
        decoder_param = {
            **coder_param, "isPrefill": False, "enableLcoc": False
        }

        self.acl_encoder_operation.set_param(json.dumps({**encoder_param}))
        self.acl_decoder_operation.set_param(json.dumps({**decoder_param}))

        self.acl_encoder_operation.set_weight(self.ascend_weight)
        self.acl_decoder_operation.set_weight(self.ascend_weight)

    def init_cos_sin_table(self, max_seq_len, dtype, device):

        self._init_rope_cos_sin(max_seq_len, dtype, device)


    def get_attention_mask(self, max_base_len, dtype, device):
        min_dtype = torch.finfo(dtype).min
        causal_mask = torch.full(
            (max_base_len, max_base_len), fill_value=min_dtype, dtype=dtype, device=device
        )

        if max_base_len != 1:
            causal_mask = torch.triu(causal_mask, diagonal=1)
        return causal_mask 


    def prepare_inputs_for_ascend(
            self, input_ids: torch.Tensor,
            position_ids: torch.Tensor,
            is_prefill: bool,
            kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
            block_tables: torch.Tensor,
            slots: torch.Tensor,
            input_lengths: torch.Tensor,
            max_seq_len: int,
            lm_head_indices: Optional[torch.Tensor] = None,
            **kwargs
    ):
        if is_prefill:
            attention_mask = self.attn_mask.get_attn_mask(self.max_base_len, self.dtype,
                                                      self.device)

            self.init_cos_sin_table(self.max_position_embeddings, self.dtype, self.device)

            if self.soc_info.need_nz:
                attention_mask = self.transdata_operation.execute([attention_mask])[0]
            if lm_head_indices is None:
                lm_head_indices = torch.tensor(range(input_ids.shape[0]),
                                               dtype=torch.int64, device=input_ids.device)


            self.acl_encoder_operation_inputs[0] = input_ids
            self.acl_encoder_operation_inputs[1] = position_ids.to(torch.int64)
            self.acl_encoder_operation_inputs[2] = self.cos_embed
            self.acl_encoder_operation_inputs[3] = self.sin_embed
            self.acl_encoder_operation_inputs[4] = attention_mask
            self.acl_encoder_operation_inputs[5] = block_tables.to(torch.int32)
            self.acl_encoder_operation_inputs[6] = slots.to(torch.int32)

            self.acl_param = json.dumps({
                "seqLen": input_lengths.tolist()
            })

            #IN_TENSOR_KV_CACHE_IDX
            self.acl_encoder_operation_inputs[7] = self.placeholder

            #IN_TENSOR_TOKEN_OFFSET
            self.acl_encoder_operation_inputs[8] = self.placeholder

            #IN_TENSOR_PLACE_HOLDER
            self.acl_encoder_operation_inputs[9] = self.placeholder

            #IN_TENSOR_SEQ_LEN
            self.acl_encoder_operation_inputs[10] = input_lengths.to(torch.int32)

            #IN_TENSOR_LOGTIS_INDICES
            self.acl_encoder_operation_inputs[11] = lm_head_indices.to(torch.int64)

            return self.acl_encoder_operation_inputs, self.acl_param
        else:

            spec_mask = kwargs.get('spec_mask', None)
            attention_mask = spec_mask if self.speculate_enable else self.attn_mask_fake

            self.acl_decoder_operation_inputs[0] = input_ids
            self.acl_decoder_operation_inputs[1] = position_ids.to(torch.int64)
            self.acl_decoder_operation_inputs[2] = self.cos_embed
            self.acl_decoder_operation_inputs[3] = self.sin_embed
            self.acl_decoder_operation_inputs[4] = attention_mask
            self.acl_decoder_operation_inputs[5] = block_tables.to(torch.int32)
            self.acl_decoder_operation_inputs[6] = slots.to(torch.int32)
            self.acl_decoder_operation_inputs[7] = self.placeholder
            self.acl_decoder_operation_inputs[8] = self.placeholder
            self.acl_decoder_operation_inputs[9] = self.placeholder
            self.acl_decoder_operation_inputs[10] = input_lengths.to(torch.int32)
            self.acl_decoder_operation_inputs[11] = self.lm_head_indices_fake

            self.acl_param = json.dumps({
                "seqLen": input_lengths.tolist(),
                "qLen": kwargs.get('q_lens', [])
            })

            return self.acl_decoder_operation_inputs, self.acl_param
    
    
    def _init_rope_cos_sin(self, max_seq_len, dtype, device):
        if self.config.rope_scaling is None:
            self.rotary_embedding.update_cos_sin_cache_total(dtype, device, max_seq_len)
        else:
            scaling_type = self.config.rope_scaling.type
            if scaling_type == "longrope":
                self.rotary_embedding.update_long_rope_minicpm3_cos_sin_cache_total(
                    self.config,
                    dtype,
                    device,
                    max_seq_len
                )
            else:
                logger.error("Error: MiniCPM only support scaling type: linear, longrope (for MiniCPM3-4B)."
                             " check your config.json: scaling_type", ErrorCode.ATB_MODELS_MODEL_PARAM_JSON_INVALID)
                raise ValueError("Unknown RoPE scaling type, check your config.json: rope_scaling type")

        self.cos_embed = self.rotary_embedding.get_cos_cached_total()
        self.sin_embed = self.rotary_embedding.get_sin_cached_total()

