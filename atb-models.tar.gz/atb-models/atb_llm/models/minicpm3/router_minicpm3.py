#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from dataclasses import dataclass

from ..base.router import BaseRouter
from ..base.input_builder import InputBuilder
from ..base.model_utils import safe_get_tokenizer_from_pretrained
from .config_minicpm3 import MiniCpm3Config


@dataclass
class Minicpm3Router(BaseRouter):
    def get_config(self):
        config = MiniCpm3Config.from_dict(self.config_dict)
        if self.max_position_embeddings:
            config.max_position_embeddings = self.max_position_embeddings
        super().check_config(config)
        return config

    def get_input_builder(self):
        return InputBuilder(self.tokenizer, self.model_version)

    def get_tokenizer(self):
        tokenizer = safe_get_tokenizer_from_pretrained(
            self.model_name_or_path,
            revision=self.revision,
            padding_side="left",
            truncation_side="left",
            trust_remote_code=True,
            use_fast=True,
        )
        # 需要添加PAD token
        tokenizer.add_special_tokens({'pad_token': '[PAD]'})
        return tokenizer
        
