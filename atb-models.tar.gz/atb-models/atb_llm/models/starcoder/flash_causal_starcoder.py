# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.

from typing import Optional, List, Tuple

import torch
import torch.distributed
from atb_llm.utils.layers import TensorParallelHead

from atb_llm.models.base.flash_causal_lm_v2 import FlashCausalLMV2
from atb_llm.models.base.config import BaseConfig
from atb_llm.utils.weights import Weights
from .modeling_starcoder import FlashStarcoderModel
from ...utils.data.weight_wrapper import WeightWrapper, AttnWrapper, MlpWrapper
from ...utils.layers.norm.fast_layer_norm import NormType
from ...utils.layers.embedding.position_rotary_embedding import PositionEmbeddingType


CPP_STARCODER_MODEL_CLASS_NAME = "starcoder_DecoderModel"


class FlashStarcoderForCausalLM(FlashCausalLMV2):
    def __init__(self, config: BaseConfig, weights: Weights, lmhead_prefix="lm_head", model_prefix="model", **kwargs):
        super().__init__(config, weights, **kwargs)
        self.head_dim = config.hidden_size // config.num_attention_heads
        self.max_seq_len_every_batch = config.max_position_embeddings
        self.config.rms_norm_eps = config.layer_norm_epsilon
        self.acl_encoder_operation = None
        self.acl_decoder_operation = None
        self.model = FlashStarcoderModel(config, weights)
        self.lm_head = TensorParallelHead.load(
            config,
            prefix="lm_head",
            weights=weights,
            is_norm=True
        )
        self.attn_wrapper = AttnWrapper(
            norm_name='ln_1',
            wrapper_name='self_attn',
            pack_name='c_attn',
            sep_names=None,
            o_name='c_proj'
        )
        self.mlp_wrapper = MlpWrapper(
            norm_name='ln_2',
            wrapper_name='mlp',
            pack_name='c_fc',
            sep_names=None,
            down_name='c_proj'
        )

    @property
    def model_torch_class_name(self):
        """
        This method returns the name of the PyTorch class for the model.
        """
        return "starcoder_DecoderModel"
        
    def get_device_weights(self, **kwargs) -> WeightWrapper:
        """
        Retrieves the weights for the device.

        Args:
            **kwargs: Additional keyword arguments.

        Returns:
            WeightWrapper: The weight wrapper object contains weight metadata.
        """
        weight_wrapper = WeightWrapper(self.soc_info, self.mapping.rank, self.attn_wrapper, self.mlp_wrapper)
        weight_wrapper.register_embedding(self.model.wte)
        weight_wrapper.register_embedding(self.model.wpe)
        for i in range(self.config_metadata.num_hidden_layers):
            layer = self.model.layers[i]
            weight_wrapper.register_layer(layer, self.config.quantize)
            if self.soc_info.need_nz:
                del layer.self_attn
                del layer.mlp
        weight_wrapper.register_model_norm(self.model.norm)
        weight_wrapper.register_model_lmhead(self.lm_head)
        return weight_wrapper

    def update_engine_static_param(self):
        """
        The method is responsible for setting the static parameters for the engine.
        It accomplishes this by first obtaining a set of default parameters by calling
        the `update_engine_static_param method` from the `FlashCausalLMV2` class.
        Afterward, it updates these default parameters by adding the following settings:
        whether to utilize tensor parallelism in word embedding.
        """
        engine_static_param = super().update_engine_static_param()
        engine_static_param.update({
            "normEps": self.config.rms_norm_eps,
            "normType": NormType.LAYER_NORM,
            "positionEmbeddingType": PositionEmbeddingType.ABSOLUTE,
            "isEmbeddingParallel": False,
            "enableSwiGLU": False,
            "enableLcoc": False,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
            "linearHasBias": [[True, True, True, True]] * self.config_metadata.num_hidden_layers,
        })
        return engine_static_param

    def prepare_default_inputs(
            self,
            input_ids: torch.Tensor,
            position_ids: torch.Tensor,
            is_prefill: bool,
            kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
            block_tables: torch.Tensor,
            slots: torch.Tensor,
            input_lengths: torch.Tensor,
            max_seq_len: int,
            lm_head_indices: Optional[torch.Tensor] = None,
            **kwargs
        ) -> None:
        """
        This method prepares the default inputs for the model.
        It first calls the parent class method to prepare the default inputs.
        Then, it updates input embedding and input ids of the input engines.
        """
        super().prepare_default_inputs(
            input_ids, position_ids, is_prefill, kv_cache,
            block_tables, slots, input_lengths, max_seq_len,
            lm_head_indices, **kwargs)
        self.engine_inputs = [
            *self.engine_inputs[:2],
            self.placeholder,
            self.placeholder,
            *self.engine_inputs[4:],
        ]
