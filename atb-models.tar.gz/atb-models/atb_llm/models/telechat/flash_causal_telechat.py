# Copyright Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
import math
import torch
from torch import nn
from transformers.activations import ACT2FN
from atb_llm.models.base.flash_causal_lm_v2 import FlashCausalLMV2
from atb_llm.models.base.config import BaseConfig
from atb_llm.utils.weights import Weights
from atb_llm.utils.layers import (
    TensorParallelColumnLinear,
    TensorParallelRowLinear,
    TensorEmbedding,
    PositionRotaryEmbedding,
    TensorParallelHead,
    load_column_multi,
)
from atb_llm.utils.data.weight_wrapper import (
    AttnWrapper,
    MlpWrapper,
    WeightWrapper,
)
from atb_llm.utils.layers.linear import get_linear
from atb_llm.utils.quantize.pack_type import PackType, calc_linear_pack_type
from .config_telechat import TelechatConfig


def contains_telechat2(auto_map):
    for _, value in auto_map.items():
        if "telechat2" in value.lower():
            return True
    return False


class RMSNorm(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        super().__init__()

        weight = weights.get_tensor(f"{prefix}.weight")
        self.weight = nn.Parameter(weight)
        self.variance_epsilon = eps


class RMSNormBias(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        super().__init__()

        weight = weights.get_tensor(f"{prefix}.weight")
        try:
            bias = weights.get_tensor(f"{prefix}.bias")
        except AssertionError:
            bias = torch.zeros(weight.shape, dtype=torch.float16)
        self.weight = nn.Parameter(weight)
        self.bias = nn.Parameter(bias)
        self.variance_epsilon = eps


class RMSNormWrapper(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        super().__init__()

        self.ori = RMSNorm(prefix, weights, eps)
        self.anti = RMSNormBias(f"{prefix}.module", weights, eps)


class FlashTelechatAttention(torch.nn.Module):
    def __init__(
        self,
        prefix: str,
        config: TelechatConfig,
        weights,
    ):
        super().__init__()
        self.num_heads = config.n_head
        self.hidden_size = config.hidden_size
        self.head_dim = self.hidden_size // self.num_heads

        self.rotary_emb = PositionRotaryEmbedding.static(
            dim=self.head_dim, base=10000.0, device="cpu"
        ).to(weights.device)
        self.softmax_scale = self.head_dim**-0.5

        try:
            self.num_heads = math.ceil(self.num_heads / weights.process_group.size())
        except ZeroDivisionError as e:
            raise ZeroDivisionError from e

        linear_names = [f"{prefix}.query", f"{prefix}.key_value"]
        pack_name = f'{prefix}.w_pack'
        layer_prefix = ".".join(prefix.split(".")[:-1])
        norm_name = f"{layer_prefix}.input_layernorm"
        self.pack_type = calc_linear_pack_type(weights, linear_names, norm_name, pack_name)

        if self.pack_type in [
            PackType.ALL_W8A16,
            PackType.ALL_W8A8SC,
        ]:
            self.w_pack = TensorParallelColumnLinear.load(
                config,
                prefix=f"{prefix}.w_pack",
                weights=weights,
                bias=False
            )
            self.w_pack_ori = TensorParallelColumnLinear.load(
                config,
                prefix=f"{prefix}.w_pack_ori",
                weights=weights,
                bias=False
            )
            self.dense = TensorParallelRowLinear.load(
                config,
                prefix=f"{prefix}.dense",
                weights=weights,
                bias=True,
                bias_pre_add=True
            )
        else:
            q_weight = weights.get_multi_weights_col(
                [f"{prefix}.query"], quantize=config.quantize, dim=0
            )
            kv_weight = weights.get_weights_col_packed_kv(
                f"{prefix}.key_value", config.quantize, self.hidden_size, self.head_dim
            )

            if isinstance(q_weight, torch.Tensor):
                weight = torch.cat([q_weight, kv_weight], dim=0)
            else:
                weight = [torch.cat([q, kv], dim=0) for q, kv in zip(q_weight, kv_weight)]
                weight[3] = q_weight[3]
                weight[4] = q_weight[4]

            self.w_pack = TensorParallelColumnLinear(
                get_linear(weight, bias=None, quantize=config.quantize)
            )
            self.pack_type = calc_linear_pack_type(weights, linear_names, norm_name)

            self.w_pack_ori = TensorParallelColumnLinear.load_multi(
                config,
                prefixes=[f"{prefix}.query", f"{prefix}.key_value"],
                weights=weights,
                bias=False,
                dim=0,
            )

            self.dense = TensorParallelRowLinear.load(
                config,
                prefix=f"{prefix}.dense",
                weights=weights,
                bias=True,
                bias_pre_add=True,
            )
        self.prefix = prefix


class TelechatMLP(nn.Module):
    def __init__(self, prefix, config: TelechatConfig, weights):
        super().__init__()
        act = config.hidden_act
        
        def gelu_activation(x, act):
            approximate_mode = "tanh" if act in ["gelu_fast", "gelu_pytorch_tanh"] else "none"
            return torch.nn.functional.gelu(x, approximate_mode)
        
        self.act = (
            ACT2FN[act]
            if "gelu" not in act
            else lambda x: gelu_activation(x, act)
        )
        
        linear_names = [f"{prefix}.gate_proj", f"{prefix}.up_proj"]
        pack_name = f"{prefix}.gate_up_proj"
        layer_prefix = ".".join(prefix.split(".")[:-1])
        norm_name = f"{layer_prefix}.post_attention_layernorm"
        self.pack_type = calc_linear_pack_type(weights, linear_names, norm_name, pack_name)

        if self.pack_type in [
            PackType.ALL_FP,
            PackType.ALL_W8A8,
            PackType.ALL_W8A8_ANTI,
            PackType.ALL_W8A16,
        ]:
            self.gate_up_proj = load_column_multi(
                config,
                prefixes=[f"{prefix}.gate_proj", f"{prefix}.up_proj"],
                weights=weights,
                head_size=1,
            )
        elif self.pack_type in [PackType.ALL_W8A8SC]:
            self.gate_up_proj = TensorParallelColumnLinear.load(
                config,
                prefix=f"{prefix}.gate_up_proj",
                weights=weights,
                bias=False
            )
        else:
            self.gate_proj = TensorParallelColumnLinear.load(
                config,
                prefix=f"{prefix}.gate_proj",
                weights=weights,
                bias=False,
            )
            self.up_proj = TensorParallelColumnLinear.load(
                config,
                prefix=f"{prefix}.up_proj",
                weights=weights,
                bias=False,
            )

        self.down_proj = TensorParallelRowLinear.load(
            config,
            prefix=f"{prefix}.down_proj",
            weights=weights,
            bias=True,
            bias_pre_add=True,
        )

        try:
            self.intermediate_size = math.ceil(
                config.intermediate_size / weights.process_group.size()
            )
        except ZeroDivisionError as e:
            raise ZeroDivisionError from e


class TelechatBlock(nn.Module):
    def __init__(self, layer_id, config, weights):
        super().__init__()
        is_telechat2 = contains_telechat2(config.auto_map)
        if config.n_layer >= 38:
            if config.quantize == 'w8a8sc':
                prefix = f"model.h.{layer_id}"
            else:
                prefix = f"transformer.h.{layer_id}"
        else:
            if config.quantize == 'w8a8' or is_telechat2:
                prefix = f"transformer.h.{layer_id}"
            else:
                prefix = f"h.{layer_id}"

        self.self_attention = FlashTelechatAttention(
            prefix=f"{prefix}.self_attention", config=config, weights=weights
        )
        self.mlp = TelechatMLP(prefix=f"{prefix}.mlp", config=config, weights=weights)

        if self.self_attention.pack_type in [
            PackType.ALL_W8A8_ANTI,
            PackType.MIX_W8A8_ANTI,
        ]:
            self.input_layernorm = RMSNormWrapper(
                prefix=f"{prefix}.input_layernorm",
                weights=weights,
                eps=config.layer_norm_epsilon,
            )
        elif self.self_attention.pack_type in [PackType.ALL_W8A8, PackType.ALL_W8A8SC]:
            self.input_layernorm = RMSNormBias(
                prefix=f"{prefix}.input_layernorm",
                weights=weights,
                eps=config.layer_norm_epsilon,
            )
        else:
            self.input_layernorm = RMSNorm(
                prefix=f"{prefix}.input_layernorm",
                weights=weights,
                eps=config.layer_norm_epsilon,
            )

        if self.mlp.pack_type in [PackType.ALL_W8A8_ANTI, PackType.MIX_W8A8_ANTI]:
            self.post_attention_layernorm = RMSNormWrapper(
                prefix=f"{prefix}.post_attention_layernorm",
                weights=weights,
                eps=config.layer_norm_epsilon,
            )
        elif self.mlp.pack_type in [PackType.ALL_W8A8, PackType.ALL_W8A8SC]:
            self.post_attention_layernorm = RMSNormBias(
                prefix=f"{prefix}.post_attention_layernorm",
                weights=weights,
                eps=config.layer_norm_epsilon,
            )
        else:
            self.post_attention_layernorm = RMSNorm(
                prefix=f"{prefix}.post_attention_layernorm",
                weights=weights,
                eps=config.layer_norm_epsilon,
            )


class FlashTelechatModel(torch.nn.Module):
    def __init__(self, config, weights):
        super().__init__()

        self.embed_dim = config.hidden_size
        self.num_heads = config.n_head
        is_telechat2 = contains_telechat2(config.auto_map)
        if config.n_layer >= 38:
            if config.quantize == 'w8a8sc':
                prefix = "model."
            else:    
                prefix = "transformer."
        else:
            if config.quantize == 'w8a8' or is_telechat2:
                prefix = "transformer."
            else:
                prefix = ""

        self.word_embeddings = TensorEmbedding(
            prefix=f"{prefix}word_embeddings", weights=weights
        )

        # Transformer blocks
        self.h = nn.ModuleList(
            [
                TelechatBlock(layer_id, config, weights)
                for layer_id in range(config.num_hidden_layers)
            ]
        )
        # Final Layer Norm
        self.ln_f = RMSNorm(
            prefix=f"{prefix}ln_f", weights=weights, eps=config.layer_norm_epsilon
        )

        self.gradient_checkpointing = False


class FlashTelechatForCausalLM(FlashCausalLMV2):
    """
    This class serves as the primary functional class that inherits from the `FlashCausalLMV2` class.
    It is responsible for constructing the model architecture by integrating the FlashLlamaModel.
    """
    def __init__(self, config: BaseConfig, weights: Weights, **kwargs):
        super().__init__(config, weights, **kwargs)
        self.infer_param.update_matmul_nz(
            self.soc_info, config.quantize
        )

        # model structure
        self.model = FlashTelechatModel(config, weights)
        is_telechat2 = contains_telechat2(config.auto_map)
        self.quantize = config.quantize
        if config.quantize == 'w8a8sc':
            prefix = "model."
        elif config.quantize in ['w8a8', 'w8a8s']:
            prefix = "transformer."
        else:
            prefix = ""

        if config.n_layer == 30 and not is_telechat2:
            self.lm_head = load_column_multi(
                config,
                prefixes=[f"{prefix}word_embeddings"],
                weights=weights,
                head_size=1,
                lm_head=True,
                norm=self.config.vocab_size == 125696,
            )
        elif config.n_layer >= 30:
            if config.quantize == 'w8a8sc':
                self.lm_head = TensorParallelHead.load_weight(
                    config,
                    prefix="lm_head", # lm_head 头
                    weights=weights,
                    is_norm=True,  # 不生效的配置
                )
            else:
                self.lm_head = load_column_multi(
                    config,
                    prefixes=["lm_head"], # lm_head 头
                    weights=weights,
                    head_size=1,
                    lm_head=True,
                )

        process_group = weights.process_group
        self.tp_rank = process_group.rank()
        self.num_layers = config.num_hidden_layers
        

    @property
    def model_torch_class_name(self):
        """
        This method returns the name of the PyTorch class for the model.
        """
        return "telechat_DecoderModel"

    def update_engine_static_param(self):
        """
        The method is responsible for setting the static parameters for the engine.
        It accomplishes this by first obtaining a set of default parameters by calling
        the `update_engine_static_param method` from the `FlashCausalLMV2` class.
        Afterward, it updates these default parameters by adding the following settings:
        whether to utilize tensor parallelism in word embedding.
        """
        engine_static_param = super().update_engine_static_param()
        engine_static_param.update({
            "enableAddNorm": False,
            "isEmbeddingParallel": False,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
            "isUnpadInputs": True,
            "linearHasBias": [[False, True, False, True]] * self.config_metadata.num_hidden_layers,
        })
        return engine_static_param

    def get_device_weights(self, **kwargs) -> WeightWrapper:
        attn_module_names = AttnWrapper(
            norm_name="input_layernorm",
            pack_name="w_pack",
            o_name="dense",
            sep_names=None,
            wrapper_name="self_attention"
        )
        mlp_module_names = MlpWrapper(
            norm_name="post_attention_layernorm",
            pack_name="gate_up_proj",
            sep_names=["gate_proj", "up_proj"],
            down_name="down_proj",
            wrapper_name="mlp"
        )
        weight_wrapper = WeightWrapper(
            self.soc_info, self.tp_rank, attn_module_names, mlp_module_names
        )
        weight_wrapper.register_embedding(self.model.word_embeddings)
        for i in range(self.num_layers):
            layer = self.model.h[i]
            weight_wrapper.register_layer(
                layer,
                self.quantize,
            )
            if self.soc_info.need_nz:
                del layer.self_attention
                del layer.post_attention_layernorm
                del layer.mlp
        weight_wrapper.register_model_norm(self.model.ln_f)
        weight_wrapper.register_model_lmhead(self.lm_head)
        
        return weight_wrapper
