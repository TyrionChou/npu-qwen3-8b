# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
import copy
import os
import json
import math
import tempfile
from enum import Enum
from typing import List, Optional, Tuple

import numpy as np
import torch
import torch_npu

from atb_llm.models.base.flash_causal_lm import FlashForCausalLM
from atb_llm.models.deepseekv2.modeling_deepseekv2 import FlashDeepseekV2Model
from atb_llm.models.deepseekv2.config_deepseekv2 import DeepseekV2Config
from atb_llm.models.deepseekv2.position_embedding_deepseekv2 import DeepseekV2YarnRotaryEmbedding
from atb_llm.models.deepseekv2.weight_wrapper_deepseekv2 import Deepseekv2WeightWrapper
from atb_llm.utils.data.moe_weight_wrapper import MoeMlpWrapper
from atb_llm.utils.data.weight_wrapper import AttnWrapper
from atb_llm.utils.env import ENV
from atb_llm.utils.layers import PositionRotaryEmbedding
from atb_llm.utils.layers import load_column_multi

from atb_llm.utils.layers.norm.fast_layer_norm import NormType
from atb_llm.utils.log import logger
from atb_llm.utils.log.error_code import ErrorCode
from atb_llm.utils.moe_utils import assign, EPLBType
from atb_llm.utils.weights import ProcessGroupType
from atb_llm.utils.log import print_log
from atb_llm.utils import file_utils
from ...models import InferenceMode

try:
    from atb_llm.utils.prof.profiler import span_start, span_end
except ImportError:
    # Define dummy functions if the module is not found
    def span_start(*args, **kwargs):
        # Maybe add a log warning here if needed
        return None # Or some dummy context manager

    def span_end(*args, **kwargs):
        pass


_ROPE_SCALING_KEYS = ["original_max_position_embeddings", "beta_fast", "beta_slow", "mscale", "mscale_all_dim"]
NUM_HIDDEN_LAYERS = 61

SEQUENCE_LENGTH = "seqLen"
SEQUENCE_LENGTH_SP = "seqLenSp"


class ExpertParallelDegree(int, Enum):
    NO_EP = 0
    STATIC_EP = 1
    DYNAMIC_EP = 2
    MIX_EP = 3


class MaskType(int, Enum):
    NO_MASK = 0
    SPEC_MASK = 1
    FREE_MASK = 2


class FlashDeepseekv2ForCausalLM(FlashForCausalLM):
    def __init__(self, config, weights, **kwargs):
        self.num_speculative_tokens = kwargs.get('num_speculative_tokens', int(ENV.deepseek_mtp))
        if self.num_speculative_tokens:
            inference_mode = kwargs.get('inference_mode', None)
            if not inference_mode and not hasattr(inference_mode, 'enable_decode_pa'):
                kwargs['inference_mode'] = InferenceMode.SPECULATE 
            if 'maskType' not in kwargs:
                kwargs['maskType'] = MaskType.FREE_MASK
        self.distributed_enable = kwargs.get('distributed_enable', False)
        self.max_batch_size = kwargs.get('max_batch_size', 0)
        if not self.distributed_enable:
            self.max_batch_size = 0
        super().__init__(config, weights, **kwargs)
        self.maskfree = kwargs.get('maskType', MaskType.NO_MASK) == MaskType.FREE_MASK

        if self.llm_config is not None:
            self.ds_config = self.llm_config.models.deepseekv2
            self.parallel_config = self.llm_config.parallel_options
        else:
            self.ds_config = None
            self.parallel_config = None

        self.ep = self.mapping.has_moe_ep()
        if self.ep:
            if not hasattr(self.ds_config, "ep_level"):
                logger.info("For expert parallel, "
                    "the ep_level variable needs to be defined in the model configuration file."
                    "The available options are 1, 2, or 3.")
                self.ep_level = ExpertParallelDegree.STATIC_EP
            else:
                self.ep_level = self.ds_config.ep_level
        else:
            self.ep_level = ExpertParallelDegree.NO_EP
        self.nz_cache = False if self.ds_config is None else self.ds_config.nz_cache
        self.enable_dangling_shared_expert = False \
            if self.ds_config is None else self.ds_config.enable_dangling_shared_expert
        
        self.llm_config = self.init_eplb_config(self.llm_config, self.ep_level)
        self.llm_config = self.init_h3p_config(self.llm_config, self.ep_level)
        config.ep_level = self.ep_level
        config.tp_num_attention_heads = self.num_attention_heads
        config.tp_num_key_value_heads = self.num_key_value_heads
        config.num_speculative_tokens = self.num_speculative_tokens
        config.num_dangling_shared_experts = 0
        if self.enable_dangling_shared_expert:
            config.num_dangling_shared_experts = self.mapping.moe_ep.group_size - config.n_routed_experts
        if hasattr(self.ds_config, 'alltoall_ep_buffer_scale_factors'):
            config.alltoall_ep_buffer_scale_factors = self.ds_config.alltoall_ep_buffer_scale_factors
        self.model = FlashDeepseekV2Model(config, weights, llm_config=self.llm_config)
        self.kvcache_quant_layers = self.model.kvcache_quant_layers
        if ENV.enable_dp_partition_up:
            weights.switch_process_group(ProcessGroupType.LM_HEAD)
        else:
            weights.switch_process_group(ProcessGroupType.MLP)
        self.lm_head = load_column_multi(
            config,
            prefixes=["lm_head"],
            weights=weights,
            head_size=1,
            lm_head=True,
        )

        self.config = config
        self.acl_encoder_operation_inputs = []
        self.acl_decoder_operation_inputs = []
        self.max_decode_dp_token_size = self.max_batch_size

        self.placeholder = torch.zeros(1, dtype=self.dtype, device=self.device)
        self.lm_head_indices_fake = torch.tensor([0], dtype=torch.int64, device=self.device)

        self.transdata_operation = torch.classes.OperationTorch.OperationTorch("TransdataOperation")
        self.transdata_param = json.dumps({})
        self.transdata_operation.set_param(self.transdata_param)
        self.padding_idx = config.pad_token_id

        if hasattr(config, "mla_quantize"):
            self.mla_quantize = config.mla_quantize
        else:
            self.mla_quantize = self.quantize
        self.moe_quantize = getattr(config, "moe_quantize", self.quantize)
        self.hidden_dim = config.hidden_size
        self.final_hidden_states = []
        self.expert_array = []

        self.expert_group = torch.arange(1024, dtype=torch.int32).npu() # 1024: const for groupedTopK
        self.routed_scaling_factor = config.routed_scaling_factor
        self.one_hot = torch.tensor([1], dtype=torch.int32).npu()
        self.zero_hot = torch.tensor([0], dtype=torch.int32).npu()
        self.final_bias = torch.zeros([self.config.n_routed_experts, self.config.hidden_size], dtype=self.dtype).npu()

        self.num_of_experts = config.n_routed_experts
        self.num_of_selected_experts = [config.num_experts_per_tok]
        self.n_group = config.n_group
        self.topk_group = config.topk_group
        self.topk_method = config.topk_method
        self.tp = config.tp if config.tp else True # Defaulting the model to tensor parallel
        self.first_k_dense_replace = config.first_k_dense_replace if config.first_k_dense_replace else 0
        self.n_shared_experts = config.n_shared_experts if config.n_shared_experts else 0
        self.norm_topk_prob = config.norm_topk_prob if config.norm_topk_prob else False
        self.first_k_dense_replace = config.first_k_dense_replace
        self.q_lora_rank = config.q_lora_rank
        self.kv_lora_rank = config.kv_lora_rank
        self.v_head_dim = config.v_head_dim
        self.qk_nope_head_dim = config.qk_nope_head_dim
        self.qk_rope_head_dim = config.qk_rope_head_dim
        self.nz_cache = config.nz_cache
        self.enable_gmmswigluquant = (self.quantize == "w8a8_dynamic") and (self.mapping.world_size > 16)

        if self.maskfree:
            self.atten_mask_free = self.gen_mask(self.num_speculative_tokens + 1, self.dtype).npu()

        self.softmax_scale = (config.qk_nope_head_dim + config.qk_rope_head_dim) ** (-0.5)
        factor_name = "factor"
        if self.config.rope_scaling_dict is not None:
            mscale_all_dim = self.config.rope_scaling_dict.get("mscale_all_dim", 0)
            scaling_factor = self.config.rope_scaling_dict[factor_name]
            if mscale_all_dim:
                mscale = DeepseekV2YarnRotaryEmbedding.yarn_get_mscale(scaling_factor, mscale_all_dim)
                self.softmax_scale = self.softmax_scale * mscale * mscale

        if self.config.rope_scaling_dict is None:
            if hasattr(config, 'rope_scaling') and self.config.rope_scaling_dict is not None:
                self.scaling_factor = self.config.rope_scaling_dict.get(factor_name, 1.0)
            else:
                self.scaling_factor = 1.0
            self.rotary_embedding = PositionRotaryEmbedding.static(
                dim=self.qk_rope_head_dim,
                base=self.rope_theta,
                device="cpu",
                scaling_factor=self.scaling_factor
            ).to(self.device)
        else:
            self.scaling_type = config.rope_scaling_dict["type"]
            self.scaling_factor = config.rope_scaling_dict["factor"]
            if self.scaling_type == "yarn":
                kwargs = {
                    key: self.config.rope_scaling_dict[key]
                    for key in _ROPE_SCALING_KEYS
                    if key in self.config.rope_scaling_dict
                }
                yarn_kwargs = DeepseekV2YarnRotaryEmbedding.StaticInputArgs(
                                            max_position_embeddings=self.max_position_embeddings,
                                            scaling_factor=scaling_factor,
                                            **kwargs,)
                self.rotary_embedding = DeepseekV2YarnRotaryEmbedding.static_yarn(dim=self.qk_rope_head_dim,
                                                                             base=self.rope_theta,
                                                                             device="cpu",
                                                                             yarn_kwargs=yarn_kwargs).to(self.device)
            else:
                msg = f"Unknown RoPE scaling type {self.scaling_type}"
                logger.error(msg, ErrorCode.ATB_MODELS_EXECUTION_FAILURE)
                raise ValueError(msg)
        self.mask_start_idx = 0

        self.communication_backend = self.soc_info.communication_backend
        self.p_to_d_weight = False
        self.num_of_redundant_expert = 0
        self.hotpot_save_count = 0
        if self.eplb_level == EPLBType.STATIC_EPLB:
            self.expert_routing_map = [None] * (self.num_layers - self.first_k_dense_replace)
            for i in weights.expert_routing_map.keys():
                self.expert_routing_map[i - self.first_k_dense_replace] = \
                    torch.tensor(weights.expert_routing_map[i], dtype=torch.int32).unsqueeze(0)

            self.expert_routing_map = torch.cat(self.expert_routing_map, dim=0).npu()

            self.num_of_redundant_expert = self.eplb_rep_per_rank * self.mapping.moe_ep.group_size

            self.device_expert = assign(self.config.n_routed_experts + self.num_of_redundant_expert, 
                                        self.mapping.moe_ep.group_size)[self.mapping.moe_ep.rank]
        else:
            if self.enable_dangling_shared_expert and self.config.num_dangling_shared_experts:
                self.device_expert = ([[0]] * self.config.num_dangling_shared_experts +
                    assign(config.n_routed_experts, config.n_routed_experts))[self.mapping.moe_ep.rank]
            else:
                self.device_expert = assign(self.config.n_routed_experts, self.mapping.moe_ep.group_size)[
                    self.mapping.moe_ep.rank]
        if self.ep:
            if self.ep_level in [ExpertParallelDegree.DYNAMIC_EP, ExpertParallelDegree.MIX_EP]:
                self.dep_communication_backend = ['hccl', 'hccl'] \
                    if self.ds_config is None else self.ds_config.communication_backend
                self.p_to_d_weight = self.ep_level == ExpertParallelDegree.MIX_EP
            logger.info(f"Expert parallel level is {self.ep_level}.")
            logger.info(f"Experts of rank {self.mapping.moe_ep.rank} are: {self.device_expert}")
            
        self.num_of_device_expert = len(self.device_expert)
        self.start_device_expert_id = torch.tensor(self.device_expert[0], dtype=torch.int64).npu().view(-1)
        self.max_device_expert_id = torch.tensor([len(self.device_expert) - 1], dtype=torch.int64).npu().view(-1)

        if self.eplb_level == EPLBType.STATIC_EPLB:
            self.device_expert_mtp = assign(self.config.n_routed_experts, self.mapping.moe_ep.group_size)[
                self.mapping.moe_ep.rank]
            self.num_of_device_expert_mtp = len(self.device_expert_mtp)
            self.start_device_expert_id_mtp = torch.tensor(self.device_expert_mtp[0], dtype=torch.int64).npu().view(-1)
            self.max_device_expert_id_mtp = torch.tensor([len(self.device_expert_mtp) - 1],
                                                         dtype=torch.int64).npu().view(-1)    
        elif self.eplb_level == EPLBType.FORCE_EPLB:
            fake_topk = torch.arange(self.num_of_experts)
            fake_topk = torch.cat([fake_topk[::2], fake_topk[1::2]])
            fake_topk = torch.cat([
                fake_topk[self.mapping.moe_ep.rank * self.num_of_experts // self.mapping.moe_ep.group_size::1],
                fake_topk[:self.mapping.moe_ep.rank * self.num_of_experts // self.mapping.moe_ep.group_size:1]
                ])
            self.fake_topk = fake_topk.repeat(512).view(-1, config.num_experts_per_tok).to(torch.int32).npu()

    def init_eplb_config(self, config, ep_level=ExpertParallelDegree.NO_EP):
        try:
            level = config.models.deepseekv2.eplb.level
            flag_level_unvalid = level not in [e.value for e in EPLBType] or level == EPLBType.DYNAMIC_EPLB
            if flag_level_unvalid:
                msg = "Invalid EPLB configuration. " \
                    "Valid values are NO_EPLB(0), STATIC_EPLB(1), or FORCE_EPLB(3). " \
                    "Dynamic load balancing (2) is not supported yet. Defaulting to level 0."
                logger.warning(msg)
                level = EPLBType.NO_EPLB
            if ep_level != ExpertParallelDegree.DYNAMIC_EP and level != EPLBType.NO_EPLB:
                msg = "EPLB only supports EP level 2 (ExpertParallelDegree.DYNAMIC_EP). " \
                    "Defaulting to level 0."
                logger.warning(msg)
                level = EPLBType.NO_EPLB
            if level == EPLBType.STATIC_EPLB and not os.path.isfile(config.models.deepseekv2.eplb.expert_map_file):
                msg = "Invalid EPLB file path. Defaulting to level 0."
                logger.warning(msg)
                level = EPLBType.NO_EPLB
            if config.models.deepseekv2.eplb.rep_per_rank < 0:
                msg = "Invalid EPLB parameter. rep_per_rank should be greater than 0. Defaulting to level 0."
                logger.warning(msg)
                level = EPLBType.NO_EPLB
                config.models.deepseekv2.eplb.rep_per_rank = 0
            
            config.models.deepseekv2.eplb.level = level
            self.eplb_level = level
            self.eplb_expert_map_file = config.models.deepseekv2.eplb.expert_map_file
            self.eplb_rep_per_rank = config.models.deepseekv2.eplb.rep_per_rank
            
        except (AttributeError, KeyError):
            msg = "EPLB configuration not found. Defaulting to level 0."
            logger.warning(msg)
            self.eplb_level = EPLBType.NO_EPLB
            self.eplb_expert_map_file = ""
            self.eplb_rep_per_rank = 0
        
        logger.info(f"EPLB level is : {self.eplb_level}.")
        logger.info(f"EPLB expert map path is : {self.eplb_expert_map_file}.")
        logger.info(f"EPLB rep per rank is : {self.eplb_rep_per_rank}.")

        return config

    def init_h3p_config(self, config, ep_level=ExpertParallelDegree.NO_EP):
        # Prefill H3P, Hierarchical & Heterogeneous & Hybrid Parallel
        if config is None:
            self.enable_qkvdown_dp = False
            self.enable_gating_dp = False
            self.enable_shared_expert_dp = False
            self.enable_shared_expert_overlap = False
        else:
            if ep_level != ExpertParallelDegree.STATIC_EP:
                msg = "H3P optimization only takes effect in static EP."
                logger.warning(msg)
                config.models.deepseekv2.h3p.enable_qkvdown_dp = False
                config.models.deepseekv2.h3p.enable_gating_dp = False
                config.models.deepseekv2.h3p.enable_shared_expert_dp = False
                config.models.deepseekv2.h3p.enable_shared_expert_overlap = False
            
            if not self.mapping.has_attn_tp():
                msg = "H3P qkvdown dp optimization only takes effect when there is " \
                "a tp strategy in the attn part and the moe tail uses allgather."
                logger.warning(msg)
                config.models.deepseekv2.h3p.enable_qkvdown_dp = False
            
            if self.mapping.attn_dp.group_size == 1:
                msg = "H3P moe dp optimization only takes effect when there is a dp " \
                "strategy in the attn part and an allgather at the tail of the attn."
                logger.warning(msg)
                config.models.deepseekv2.h3p.enable_gating_dp = False
                config.models.deepseekv2.h3p.enable_shared_expert_dp = False
                config.models.deepseekv2.h3p.enable_shared_expert_overlap = False
            
            if not config.models.deepseekv2.h3p.enable_shared_expert_dp and \
                config.models.deepseekv2.h3p.enable_shared_expert_overlap:
                msg = "H3P shared expert overlap depend on shared expert dp."
                logger.warning(msg)
                config.models.deepseekv2.h3p.enable_shared_expert_overlap = False
                
            self.enable_qkvdown_dp = config.models.deepseekv2.h3p.enable_qkvdown_dp
            self.enable_gating_dp = config.models.deepseekv2.h3p.enable_gating_dp
            self.enable_shared_expert_dp = config.models.deepseekv2.h3p.enable_shared_expert_dp
            self.enable_shared_expert_overlap = config.models.deepseekv2.h3p.enable_shared_expert_overlap
        
        print_log(self.tp_rank, logger.info, f"Enable qkvdown dp is : {self.enable_qkvdown_dp}.")
        print_log(self.tp_rank, logger.info, f"Enable gating dp is : {self.enable_gating_dp}.")
        print_log(self.tp_rank, logger.info, f"Enable shared expert dp is : {self.enable_shared_expert_dp}.")
        print_log(self.tp_rank, logger.info, f"Enable shared expert overlap is : {self.enable_shared_expert_overlap}.")
        return config

    def gen_mask(self, q_len, dtype):
        pre_mask_factor = -10000.0
        if dtype == torch.bfloat16:
            pre_mask_factor = 1.0
        mask_free = np.full((125 + 2 * q_len, 128), pre_mask_factor) # 125 and 2 is match formula, 128 is block_size
        mask_free = np.triu(mask_free, 2 - q_len)
        return torch.from_numpy(mask_free).to(dtype)

    def init_position_rotary_embedding(self,
                                       position_ids: torch.Tensor,
                                       max_seq_len: int):
        self.rotary_embedding.update_cos_sin_cache_total(self.dtype, position_ids.device, max_seq_len)
        self.cos_embed = self.rotary_embedding.get_cos_cached_total()
        self.sin_embed = self.rotary_embedding.get_sin_cached_total()

    def init_ascend_operations(self, config: DeepseekV2Config):
        self.acl_encoder_operation = torch.classes.ModelTorch.ModelTorch("deepseekV2_DecoderModel")
        self.acl_decoder_operation = torch.classes.ModelTorch.ModelTorch("deepseekV2_DecoderModel")
        if self.num_speculative_tokens:
            self.acl_encoder_operation_mtp = torch.classes.ModelTorch.ModelTorch("deepseekV2_MtpDecoderModel")
            self.acl_decoder_operation_mtp = torch.classes.ModelTorch.ModelTorch("deepseekV2_MtpDecoderModel")

    def init_weight_wrapper(self):
        attn_wrapper = AttnWrapper(norm_name='input_layernorm', wrapper_name='self_attn')
        moe_mlp_wrapper = MoeMlpWrapper(
            norm_name='post_attention_layernorm',
            router_name='gate',
            wrapper_name='mlp',
            pack_name='gate_up_proj',
            sep_names=['gate_proj', 'up_proj'],
            down_name='down_proj',
            shared_experts=(self.n_shared_experts > 0 and not self.enable_dangling_shared_expert),
        )
        weight_wrapper = Deepseekv2WeightWrapper(self.soc_info, self.tp_rank,
                                                attn_wrapper, moe_mlp_wrapper,
                                                self.num_of_experts,
                                                self.mapping.moe_ep.rank, self.config.num_dangling_shared_experts)
        weight_wrapper.register_embedding(self.model.embed_tokens)
        return weight_wrapper

    def get_layer_weights(self, weight_wrapper, layer, i, quantize=None, mla_quantize=None):
        if i < self.first_k_dense_replace:
            weight_wrapper.register_moe_layer(layer, quantize, dense_layer=True,
                                            attn_quantize_type=mla_quantize)
        elif self.ep:
            weight_wrapper.register_moe_layer(layer, quantize,
                            expert_roster=[i for i, _ in enumerate(self.device_expert)],
                            attn_quantize_type=mla_quantize, moe_quantize_type=self.moe_quantize)
            if self.p_to_d_weight:
                weight_wrapper.register_shared_expert_dp2tp(layer, quantize, "shared_experts_tp")
                weight_wrapper.register_router(layer, quantize, "shuffled_gate")
            del layer.mlp 
            torch.npu.empty_cache()
        else:
            weight_wrapper.register_moe_layer(layer, quantize, dense_layer=False,
                                            attn_quantize_type=mla_quantize, moe_quantize_type=self.moe_quantize)
            del layer.mlp
            torch.npu.empty_cache()
        if self.config.quantization_config.fa_quant_type is not None:
            weight_wrapper.register_layer_qkvquant(layer)

        if self.soc_info.need_nz:
            del layer.self_attn
            del layer.post_attention_layernorm
            torch.npu.empty_cache()

    def get_weights(self):
        weight_wrapper = self.init_weight_wrapper()
        for i in range(self.num_layers):
            layer = self.model.layers[i]
            self.get_layer_weights(weight_wrapper, layer, i, self.quantize, self.mla_quantize)

        weight_wrapper.register_model_norm(self.model.norm)
        weight_wrapper.register_model_lmhead(self.lm_head)

        if self.num_speculative_tokens:
            # mtp_word_embedding
            weight_wrapper.register_embedding(self.model.embed_tokens)
            # mtp_enorm
            weight_wrapper.weights.append(self.model.mtp_enorm.weight.data)
            # mtp_hnorm
            weight_wrapper.weights.append(self.model.mtp_hnorm.weight.data)
            # mtp_eh_proj
            weight_wrapper.weights.append(self.model.eh_proj.weight.data)

            # mtp_decode_layer
            mtp_layer_id = NUM_HIDDEN_LAYERS
            self.mtp_layer_pos = len(weight_wrapper.weights)
            layer = self.model.mtp_layer
            self.get_layer_weights(weight_wrapper, layer, mtp_layer_id)

            # mtp_head
            weight_wrapper.weights.append(self.model.shared_head_norm.weight.data)
            weight_wrapper.weights.append(self.lm_head.linear.weight.data)
            torch.npu.empty_cache()

        return weight_wrapper

    def init_ascend_weight(self):
        weight_wrapper = self.get_weights()
        self.ascend_weight = weight_wrapper.weights
        pack_quant_configs = weight_wrapper.pack_quant_type
        moe_pack_type = weight_wrapper.moe_pack_type

        attn_linear_types = weight_wrapper.attn_linear_types
        mlp_linear_types = weight_wrapper.mlp_linear_types
        moe_linear_types = weight_wrapper.moe_linear_types

        attn_linear_transpose_types = weight_wrapper.attn_linear_transpose_types
        mlp_linear_transpose_types = weight_wrapper.mlp_linear_transpose_types
        moe_linear_transpose_types = weight_wrapper.moe_linear_transpose_types

        if self.num_speculative_tokens:

            layer_weight_num = 84 + 4 + 2
            self.ascend_weight_mtp = self.ascend_weight[-layer_weight_num:]
            self.ascend_weight = self.ascend_weight[:-layer_weight_num]

            pack_quant_configs_mtp = pack_quant_configs[self.config.num_hidden_layers:]
            attn_linear_types_mtp = attn_linear_types[self.config.num_hidden_layers:]
            moe_linear_types_mtp = moe_linear_types[self.config.num_hidden_layers:]
            mlp_linear_types_mtp = mlp_linear_types[self.config.num_hidden_layers:]
            attn_linear_transpose_types_mtp = attn_linear_transpose_types[self.config.num_hidden_layers:]
            mlp_linear_transpose_types_mtp = mlp_linear_transpose_types[self.config.num_hidden_layers:]
            moe_linear_transpose_types_mtp = moe_linear_transpose_types[self.config.num_hidden_layers:]

            pack_quant_configs = pack_quant_configs[:self.config.num_hidden_layers]
            attn_linear_types = attn_linear_types[:self.config.num_hidden_layers]
            moe_linear_types = moe_linear_types[:self.config.num_hidden_layers]
            mlp_linear_types = mlp_linear_types[:self.config.num_hidden_layers]
            attn_linear_transpose_types = attn_linear_transpose_types[:self.config.num_hidden_layers]
            mlp_linear_transpose_types = mlp_linear_transpose_types[:self.config.num_hidden_layers]
            moe_linear_transpose_types = moe_linear_transpose_types[:self.config.num_hidden_layers]

        is_w8a8_dynamic = self.quantize == "w8a8_dynamic"
        coder_param = {
            "isUnpadInputs": True,
            "normEps": self.config.rms_norm_eps,
            "normType": NormType.RMS_NORM,
            "numAttentionHeadsPerRank": self.num_attention_heads,
            "hiddenSizePerAttentionHead": self.head_size,
            "numHiddenLayers": self.config.num_hidden_layers,
            "numKeyValueHeadsPerRank": 1, # for MLA
            "isFA": False,
            "isBF16": self.dtype == torch.bfloat16,
            "packQuantType": pack_quant_configs,
            "isEmbeddingParallel": self.config.parallel_embedding if self.config.parallel_embedding else True,
            "isLmHeadParallel": True,
            "attnLinearQuantType": attn_linear_types,
            "mlpLinearQuantType": mlp_linear_types,
            "moeLinearQuantType": moe_linear_types,
            "attnLinearTransposeType": attn_linear_transpose_types,
            "mlpLinearTransposeType": mlp_linear_transpose_types,
            "moeLinearTransposeType": moe_linear_transpose_types,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
            "enableSwiGLU": False if self.soc_info.need_nz else True,
            "enableSwiGLUQuantForSharedExperts": False,
            'hasSharedExpert': True if self.n_shared_experts > 0 and not self.enable_dangling_shared_expert else False,
            'hasSharedExpertGate': False,
            "rank": self.mapping.rank,
            "qLoraRank": self.config.q_lora_rank if self.config.q_lora_rank is not None else 0,
            "kvLoraRank": self.config.kv_lora_rank,
            "qkNopeHeadDim": self.config.qk_nope_head_dim,
            "qkRopeHeadDim": self.config.qk_rope_head_dim,
            "softmaxScale": self.softmax_scale,
            "maskStartIdx": self.mask_start_idx,
            "numOfExperts": self.num_of_experts,
            "numOfDeviceExperts": self.num_of_device_expert,
            "deviceExpert": self.device_expert,
            "firstKDenseReplace": self.first_k_dense_replace,
            "nSharedExperts": self.n_shared_experts,
            "processLogits": self.get_process_logits_type(),
            "routedScalingFactor": self.routed_scaling_factor,
            "numOfSelectedExperts": self.num_of_selected_experts,
            "numOfGroups": self.n_group,
            "topkGroups": self.topk_group,
            "quantGroupSize": self.config.quantization_config.group_size,
            "routingMethod": self.get_routing_method_type(),
            "worldSize": self.mapping.world_size,
            "rankTableFile": ENV.rank_table_file,
            "qkvHasBias": False,
            "hasP2DWeight": self.p_to_d_weight,
            "enableSwigluQuant": True if is_w8a8_dynamic and (not self.enable_gmmswigluquant) else False,
            "enableInitQuant": True if is_w8a8_dynamic else False,
            "enableCVOverlap": ENV.enable_cv_overlap,
            "finalStateOut": True if self.num_speculative_tokens else False,
            "enableFusedTopk": True if self.topk_method == "noaux_tc" and self.n_group * 32 >= self.num_of_experts \
                                    else False,
            "enableGMMSwigluQuant": True if self.enable_gmmswigluquant else False,
            "enableMlaPreprocess": True if self.q_lora_rank is not None and self.config.hidden_size == 7168 \
                                        and self.mla_quantize == "w8a8" and self.dtype == torch.float16 else False,
            "enableAllToAllMC2": self.ep_level == ExpertParallelDegree.DYNAMIC_EP,
            "enableGatherPreNorm": True,
            "lmHeadLocalTp": False if self.parallel_config is None else self.parallel_config.lm_head_local_tp,
            "enableExtraOprojTp": False if self.parallel_config is None else self.parallel_config.extra_o_proj_tp,
            "enableLoadBalance": self.eplb_level == EPLBType.FORCE_EPLB,
            "attnOprojPrefetch": False,
            "enableEPWB": self.eplb_level == EPLBType.STATIC_EPLB,
            "numOfRedundantExpert": self.num_of_redundant_expert,
            "enableExpertCumSumOutput": ENV.enable_expert_hotpot_gather,
            "isMlpFullTP": False if self.ds_config is None else self.ds_config.mlp_full_tp,
            "enableGatingDp": self.enable_gating_dp,
            "enableSharedExpertDp": self.enable_shared_expert_dp,
            "enableSharedExpertOverlap": self.enable_shared_expert_overlap,
            "enableInfNan": ENV.enable_inf_nan_mode,
            "moePackQuantType": moe_pack_type if moe_pack_type else 0,
            "isNzCache": self.nz_cache,
            "maxDecodeDpTokenSize": self.max_decode_dp_token_size,
            "enableFA3": self.config.quantization_config.fa_quant_type is not None,
            "kvcacheQuantLayers": self.kvcache_quant_layers
        }

        if self.mapping is not None:
            coder_param.update({"mapping": self.mapping.to_dict_v2()})

        if coder_param["routingMethod"] not in ['softMaxTopK', 'integratedSoftmaxTopK', 'deviceLimited', 'noAuxTc']:
            msg = "The routingMethod chosen is not valid, please choose among the following:\n \
                  'softMaxTopK': regular routing method with softmax and topk-sort operators\n \
                  'integratedSoftmaxTopK': routing method with the integration of softmax and topk-sort operators\n \
                  'deviceLimited': device-limited routing method (e.g. deepseekv2)\n \
                  'noAuxTc': routing method with sigmoid and gate bias"
            logger.error(msg, ErrorCode.ATB_MODELS_EXECUTION_FAILURE)
            raise ValueError(msg)

        if coder_param["lmHeadLocalTp"] and ENV.deepseek_mtp:
            msg = "LmHeadLocalTp and DeepseekMtp should not be enabled at the same time. \n \
                   If LM_HEAD_LOCAL_TP=1, \
                   please export DP_MOVE_UP_ENABLE=1 and DP_PARTITION_UP_ENABLE=1"
            logger.error(msg, ErrorCode.ATB_MODELS_EXECUTION_FAILURE)
            raise ValueError(msg)

        if coder_param["lmHeadLocalTp"] and not ENV.enable_dp_partition_up:
            msg = "If LmHeadLocalTp is enabled, DpPartitionUp should also be enabled. \n \
                   If LM_HEAD_LOCAL_TP=1 and DEEPSEEK_MTP=1, \
                   please unset one of them."
            logger.error(msg, ErrorCode.ATB_MODELS_EXECUTION_FAILURE)
            raise ValueError(msg)

        if self.ep_level == ExpertParallelDegree.DYNAMIC_EP and self.mapping.moe_tp.group_size > 1:
            msg = f"Dynamic EP only supports moe_tp = 1, but gets moe_tp = {self.mapping.moe_tp.group_size}."
            logger.error(msg, ErrorCode.ATB_MODELS_EXECUTION_FAILURE)
            raise ValueError(msg)

        logger.debug(f"Whether to dump hot expert information: {ENV.enable_expert_hotpot_gather}")
        logger.debug(f"Path for storing tokens processed by experts: {ENV.expert_hotpot_dump_path}")

        encoder_param = {**coder_param, "isPrefill": True, "supportLcoc": False,
                         "numOfExperts": self.num_of_experts + self.config.num_dangling_shared_experts,
                         "expertParallelDegree": self.ep_level \
                            if self.ep_level != ExpertParallelDegree.MIX_EP \
                            else ExpertParallelDegree.DYNAMIC_EP,
                         "backend": self.communication_backend if self.ep_level < 2 \
                            else self.dep_communication_backend[0],
                         "enableQkvdownDp": self.enable_qkvdown_dp,
                         "enableDpOut": ENV.enable_dp_partition_up,
                         }
        decoder_param = {**coder_param, "isPrefill": False, "supportLcoc": False,
                        "expertParallelDegree": self.ep_level \
                            if self.ep_level != ExpertParallelDegree.MIX_EP \
                            else ExpertParallelDegree.STATIC_EP,
                        "backend": self.communication_backend if self.ep_level < 2 \
                            else self.dep_communication_backend[1],
                        "enableSpeculate": self.speculate_enable,
                        "maskfree": self.maskfree,
                        "enableDpOut": ENV.enable_dp_partition_up or bool(self.distributed_enable),
                        }
        self.acl_encoder_operation.set_param(json.dumps({**encoder_param}))
        self.acl_decoder_operation.set_param(json.dumps({**decoder_param}))
        self.acl_encoder_operation.set_weight(self.ascend_weight)
        self.acl_decoder_operation.set_weight(self.ascend_weight)
        if self.num_speculative_tokens:
            encoder_param_mtp = copy.deepcopy(encoder_param)
            decoder_param_mtp = copy.deepcopy(decoder_param)

            update_param_mtp = dict()
            update_param_mtp["numHiddenLayers"] = 1
            update_param_mtp["firstKDenseReplace"] = 0
            update_param_mtp["packQuantType"] = pack_quant_configs_mtp
            update_param_mtp["attnLinearQuantType"] = attn_linear_types_mtp
            update_param_mtp["mlpLinearQuantType"] = mlp_linear_types_mtp
            update_param_mtp["moeLinearQuantType"] = moe_linear_types_mtp
            update_param_mtp["attnLinearTransposeType"] = attn_linear_transpose_types_mtp
            update_param_mtp["mlpLinearTransposeType"] = mlp_linear_transpose_types_mtp
            update_param_mtp["moeLinearTransposeType"] = moe_linear_transpose_types_mtp

            update_param_mtp["enableSwigluQuant"] = False
            update_param_mtp["enableInitQuant"] = False
            update_param_mtp["enableMlaPreprocess"] = False
            update_param_mtp["enableFusedTopk"] = False
            update_param_mtp["enableGMMSwigluQuant"] = False
            update_param_mtp["enableExpertCumSumOutput"] = False
            
            if self.eplb_level == EPLBType.STATIC_EPLB and not ENV.enable_mtp_epwb_static:
                update_param_mtp["enableEPWB"] = False
                update_param_mtp["numOfDeviceExperts"] = self.num_of_device_expert_mtp
                update_param_mtp["deviceExpert"] = self.device_expert_mtp

            encoder_param_mtp.update(update_param_mtp)
            decoder_param_mtp.update(update_param_mtp)

            self.acl_encoder_operation_mtp.set_param(json.dumps({**encoder_param_mtp}))
            self.acl_decoder_operation_mtp.set_param(json.dumps({**decoder_param_mtp}))
            self.acl_encoder_operation_mtp.set_weight(self.ascend_weight_mtp)
            self.acl_decoder_operation_mtp.set_weight(self.ascend_weight_mtp)
            
    def get_all2all_buffer_factor(self, length):
        length = length * self.mapping.attn_dp.group_size
        if hasattr(self.ds_config, "alltoall_ep_buffer_scale_factors"):
            alltoall_ep_buffer_scale_factors = self.ds_config.alltoall_ep_buffer_scale_factors
        else:
            alltoall_ep_buffer_scale_factors = \
                [(1048576, 1.32), (524288, 1.4), (262144, 1.53),
                (131072, 1.8), (32768, 3.0), (8192, 5.2), (0, 8.0)]
        for threshold in alltoall_ep_buffer_scale_factors:
            if length >= threshold[0]:
                return threshold[1]
        return self.mapping.moe_ep.group_size

    def get_process_logits_type(self) -> str:
        if self.routed_scaling_factor > 1 and self.norm_topk_prob is True:
            return "normScaling"
        elif self.routed_scaling_factor > 1:
            return "scaling"
        return "none"
    
    def get_routing_method_type(self) -> str:
        if self.topk_method == "noaux_tc":
            return "noAuxTc"
        elif self.topk_method == "group_limited_greedy":
            return "deviceLimited"
        return "softMaxTopK"

    def free_operation_inputs(self, is_prefill):
        if is_prefill:
            self.acl_encoder_operation_inputs = []
        else:
            self.acl_decoder_operation_inputs = []

    # called by super().forward()
    def prepare_inputs_for_ascend(self,
                                  input_ids: torch.Tensor,
                                  position_ids: torch.Tensor,
                                  is_prefill: bool,
                                  kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
                                  block_tables: torch.Tensor,
                                  slots: torch.Tensor,
                                  input_lengths: torch.Tensor,
                                  max_seq_len: int,
                                  lm_head_indices: Optional[torch.Tensor] = None,
                                  **kwargs):
        perf_time_start = 0
        q_lens = kwargs.get('q_lens', [])
        spec_mask = kwargs.get('spec_mask', None)
        self.rotary_embedding.update_cos_sin_cache_total(self.dtype,
                                                            self.device,
                                                            self.max_position_embeddings)
        self.cos_embed = self.rotary_embedding.get_cos_cached_total()
        self.sin_embed = self.rotary_embedding.get_sin_cached_total()

        attn_padding_idx = self.placeholder
        attn_unpadding_idx = self.placeholder
        ffn_padding_idx = self.placeholder
        ffn_unpadding_idx = self.placeholder
        lm_head_skip_padding_token_indices = self.placeholder
        gather_prenorm_idx = self.placeholder
        padding_idx = self.placeholder
        un_padding_idx = self.placeholder
        dynamic_ep_idx = self.placeholder
        moe_idx = self.placeholder

        token_size = len(input_ids)
        if self.mapping.has_dp() and not ENV.enable_dp_move_up:
            token_size_per_dp_group = kwargs.get("token_size_per_dp_group", None)
            token_size = token_size_per_dp_group.sum().tolist()
            if token_size_per_dp_group.max().item() % self.mapping.attn_tp.group_size == 0:
                max_token_size_per_dp_group = token_size_per_dp_group.max().item()
            else:
                padding_tmp = \
                    self.mapping.attn_tp.group_size - \
                    token_size_per_dp_group.max().item() % self.mapping.attn_tp.group_size
                max_token_size_per_dp_group = token_size_per_dp_group.max().item() + padding_tmp

            token_size_per_dp_group_startid = torch.cumsum(token_size_per_dp_group, dim=0)
            token_size_per_dp_group_startid[-1] = 0
            ffn_padding_idx = torch.concat([
                torch.concat([torch.arange(j) + token_size_per_dp_group_startid[rank_id - 1],
                torch.zeros(max_token_size_per_dp_group - j, dtype=torch.int32)]) \
                    for rank_id, j in enumerate(token_size_per_dp_group)], dim=0).npu()

            lm_head_skip_padding_token_indices = torch.concat([
                torch.concat([torch.arange(j) + max_token_size_per_dp_group * rank_id]) \
                    for rank_id, j in enumerate(token_size_per_dp_group)], dim=0).npu()

            rank = self.mapping.attn_tp.rank + self.mapping.attn_dp.rank * self.mapping.attn_tp.group_size
            dp_padding_idx = [0] * self.mapping.attn_dp.group_size
            new_dp_size = []
            tmp = max(token_size_per_dp_group)
            for i in range(self.mapping.attn_dp.group_size):
                input_length = token_size_per_dp_group[i]
                reduce_scatter_padding = tmp % self.mapping.attn_tp.group_size
                input_length_padding = tmp - input_length
                input_length_padding += (
                    self.mapping.attn_tp.group_size - reduce_scatter_padding) if reduce_scatter_padding != 0 else 0
                padding_idx = torch.concat([
                    torch.arange(input_length, dtype=torch.int32),
                    torch.zeros(input_length_padding, dtype=torch.int32)
                ]).view(-1)
                dp_padding_idx[i] = padding_idx
                new_dp_size += [padding_idx.shape[
                                    0] // self.mapping.attn_tp.group_size] * self.mapping.attn_tp.group_size
            attn_padding_idx = dp_padding_idx[self.mapping.attn_dp.rank].view(-1).npu()
            token_size_per_tp_rank = max_token_size_per_dp_group // self.mapping.attn_tp.group_size
            tp_rank = self.mapping.attn_tp.rank
            if self.mapping.attn_o_proj_tp.group_size > 1:
                gather_prenorm_idx = torch.arange(len(input_ids), dtype=torch.int32).npu()
            else:
                gather_prenorm_idx = \
                    attn_padding_idx[tp_rank * token_size_per_tp_rank: (tp_rank + 1) * token_size_per_tp_rank]

            all_gather_padding = torch.concat([torch.arange(new_dp_size[rank]),
                                                torch.zeros(max(new_dp_size) - new_dp_size[rank],
                                                            dtype=torch.int32)]).view(-1)
            
            if self.ep_level == ExpertParallelDegree.DYNAMIC_EP or \
            (self.ep_level == ExpertParallelDegree.MIX_EP and is_prefill):
                attn_unpadding_idx = torch.arange(new_dp_size[rank]).view(-1).npu()
                ffn_padding_idx = attn_unpadding_idx
            else:
                all_gather_unpadding = torch.concat(
                    [torch.arange(s) + i * all_gather_padding.shape[0] for i, s in enumerate(new_dp_size)])
                reduce_scatter_unpadding = torch.concat(
                    [torch.arange(s) + sum(new_dp_size[:i * self.mapping.attn_tp.group_size])
                     for i, s in enumerate(token_size_per_dp_group)])
                attn_unpadding_idx = all_gather_unpadding[reduce_scatter_unpadding].view(-1).npu()
                ffn_padding_idx = torch.concat([
                    torch.concat([torch.arange(j) + token_size_per_dp_group_startid[rank_id - 1],
                    torch.zeros(max_token_size_per_dp_group - j, dtype=torch.int32)]) \
                        for rank_id, j in enumerate(token_size_per_dp_group)], dim=0).npu()
            ffn_unpadding_idx = torch.arange(len(input_ids), dtype=torch.int32).npu()
    
        if ENV.enable_dp_move_up:
            token_size_per_dp_group = kwargs.get("token_size_per_dp_group", None)
            if ENV.enable_dp_partition_up:
                token_size = len(input_ids)
            else:
                token_size = token_size_per_dp_group.sum().item()
        
        if ENV.benchmark_enable:
            import time
            torch.npu.synchronize()
            perf_time_start = time.time()
        self.expert_array = self.placeholder
        final_hidden_states = torch.empty([token_size, self.config.hidden_size],
                                          dtype=self.dtype,
                                          device=input_ids.device)

        is_ep = (self.ep_level == ExpertParallelDegree.DYNAMIC_EP or \
            (self.ep_level == ExpertParallelDegree.MIX_EP and is_prefill))
        
        if is_ep and not ENV.enable_dp_move_up:
            if self.mapping.attn_tp.group_size == 1:
                dynamic_ep_idx = torch.tensor(
                    [i for i in range(len(input_ids) * self.config.num_experts_per_tok)],
                    dtype=torch.int32).npu().view(-1)
                dynamic_ep_idx_padding = torch.tensor(
                        [i for i in range(attn_unpadding_idx.shape[0] * self.config.num_experts_per_tok)],
                        dtype=torch.int32).npu().view(-1)
            else:
                dynamic_ep_idx = torch.tensor(
                        [i for i in range(attn_unpadding_idx.shape[0] * self.config.num_experts_per_tok)],
                        dtype=torch.int32).npu().view(-1)
                dynamic_ep_idx_padding = dynamic_ep_idx
            ep_input_length = int(
                dynamic_ep_idx_padding.shape[0] * self.get_all2all_buffer_factor(dynamic_ep_idx_padding.shape[0]))
            all2all_padding = ep_input_length % self.mapping.moe_ep.group_size
            ep_input_length_padding = (
                    self.mapping.moe_ep.group_size - all2all_padding) if all2all_padding != 0 else 0

            ep_input_length_padding += ep_input_length
            moe_idx = torch.tensor([i + 1 for i in range(ep_input_length_padding)], dtype=torch.int32).npu().view(-1)

            self.expert_array = torch.ones(moe_idx.shape[0], dtype=torch.float16).npu().view(-1, 1)

        dep_inputs = [attn_padding_idx, attn_unpadding_idx, ffn_padding_idx,
            ffn_unpadding_idx, lm_head_skip_padding_token_indices, gather_prenorm_idx,
            self.start_device_expert_id, self.max_device_expert_id,
            padding_idx.npu(), un_padding_idx, dynamic_ep_idx, moe_idx, self.placeholder]

        if self.mapping.has_dp() and ENV.enable_dp_move_up:
            if is_prefill or not self.distributed_enable:
                dep_inputs = kwargs.get("dep_inputs", None)
                dep_inputs = dep_inputs[:6] + \
                                [self.start_device_expert_id, self.max_device_expert_id] + dep_inputs[6:]
            moe_idx = dep_inputs[-2] # note that moe_idx is the second last tensor in dep_inputs
            self.expert_array = torch.ones(moe_idx.shape[0], dtype=torch.float16).npu().view(-1, 1)
        
        if self.eplb_level == EPLBType.STATIC_EPLB:
            dep_inputs.append(self.expert_routing_map)
        
        if lm_head_indices is None:
            lm_head_indices = torch.tensor(range(input_ids.shape[0]),
                                            dtype=torch.int64, device=input_ids.device)
        
        if self.eplb_level == EPLBType.FORCE_EPLB:
            fake_topk = self.fake_topk[:dep_inputs[1].shape[0] if self.mapping.has_attn_tp() else len(input_ids)]

        if is_prefill:
            if self.soc_info.need_nz:
                pad_maxs = math.ceil(self.max_position_embeddings / 16) * 16
                atten_mask = self.attn_mask.get_attn_mask(pad_maxs, self.dtype,
                                                                    kv_cache[0][0].device)
                atten_mask = self.transdata_operation.execute([atten_mask])[0]
            else:
                # 128 for maskfree
                atten_mask = self.attn_mask.get_attn_mask(128, self.dtype,
                                                                    kv_cache[0][0].device)
            if lm_head_indices is None:
                lm_head_indices = torch.tensor(range(input_ids.shape[0]),
                                                dtype=torch.int64, device=input_ids.device)
            
            self.acl_param = json.dumps({
                SEQUENCE_LENGTH: input_lengths.tolist(),
                "qLen": q_lens,
            })
            self.acl_encoder_operation_inputs = [
                input_ids,
                position_ids.to(torch.int64),
                self.cos_embed,
                self.sin_embed,
                atten_mask,
                block_tables.to(torch.int32),
                slots.to(torch.int32),
                self.placeholder,
                final_hidden_states,
                self.placeholder,
                self.placeholder,
                input_lengths.to(torch.int32),
                lm_head_indices.to(torch.int64),
                self.expert_array,
                self.expert_group,
                self.one_hot,
                self.zero_hot,
                self.placeholder
            ]
            if self.eplb_level == EPLBType.FORCE_EPLB:
                self.acl_encoder_operation_inputs.append(fake_topk)
            self.acl_encoder_operation_inputs.extend(dep_inputs)
            if self.mapping.has_attn_inner_sp():
                self.acl_encoder_operation_inputs.extend([kwargs.get("k_sp_gather_indices", None)])
            return self.acl_encoder_operation_inputs, self.acl_param, perf_time_start
        else:
            self.acl_param = json.dumps({
                SEQUENCE_LENGTH: input_lengths.tolist(),
                "qLen": [int(i) for i in q_lens if i] if q_lens else None
            })
            self.acl_decoder_operation_inputs = [
                input_ids,
                position_ids.to(torch.int64),
                self.cos_embed,
                self.sin_embed,
                # mask
                (self.atten_mask_free if self.maskfree else spec_mask) 
                    if self.speculate_enable else self.attn_mask_fake,
                block_tables.to(torch.int32),
                slots.to(torch.int32),
                self.placeholder,
                final_hidden_states,
                self.placeholder,
                self.placeholder,
                input_lengths.to(torch.int32),
                lm_head_indices.to(torch.int64) if lm_head_indices is not None \
                                                or (self.mapping.has_dp() and self.mapping.has_mlp_tp()) \
                                                else self.lm_head_indices_fake,
                self.expert_array,
                self.expert_group,
                self.one_hot,
                self.zero_hot,
                torch.tensor(q_lens, dtype=torch.int32, device=self.device) if self.speculate_enable \
                                                                            else self.placeholder
            ]
            if self.eplb_level == EPLBType.FORCE_EPLB:
                self.acl_decoder_operation_inputs.append(fake_topk)
            self.acl_decoder_operation_inputs.extend(dep_inputs)
            if self.mapping.has_attn_inner_sp():
                input_lengths_sp = kwargs.get("input_lengths_sp", None)
                self.acl_param = json.dumps({
                    SEQUENCE_LENGTH: input_lengths.tolist(),
                    SEQUENCE_LENGTH_SP: input_lengths_sp.tolist(),
                })
                self.acl_decoder_operation_inputs.extend([input_lengths_sp])

            return self.acl_decoder_operation_inputs, self.acl_param, perf_time_start

    def save_token_num_per_expert(self):
        def save_hotpot(filename, hotpot):
            _, temp_path = tempfile.mkstemp(dir=os.path.dirname(filename))
            try:
                with file_utils.safe_open(temp_path, "w", encoding='utf-8') as file:
                    for row in hotpot.cpu().numpy().tolist():
                        line = ','.join(map(str, row))
                        file.write(line + '\n')
                        file.flush()
                        os.fsync(file.fileno())
                    os.replace(temp_path, filename)
            except:
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass
                raise

        if ENV.enable_expert_hotpot_gather and ENV.expert_hotpot_dump_path is not None:
            self.hotpot_save_count += 1
            if self.hotpot_save_count % 50 == 0: # 50 means save file when decode 50 times
                self.hotpot_save_count = 0
                if self.total_prefill_token_num_per_expert is not None:
                    file_path = os.path.join(ENV.expert_hotpot_dump_path, 'prefill/')
                    os.makedirs(file_path, exist_ok=True)
                    file_name = os.path.join(file_path, f'prefill_{self.mapping.rank}.csv')
                    save_hotpot(file_name, self.total_prefill_token_num_per_expert)
                if self.total_decode_token_num_per_expert is not None:
                    file_path = os.path.join(ENV.expert_hotpot_dump_path, 'decode/')
                    os.makedirs(file_path, exist_ok=True)
                    file_name = os.path.join(file_path, f'decode_{self.mapping.rank}.csv')
                    save_hotpot(file_name, self.total_decode_token_num_per_expert)

    def execute_ascend_operator(self,
                                acl_inputs: list,
                                acl_param: str,
                                is_prefill: bool,
                                is_mtp: bool = False) -> torch.Tensor:
        """Execute the Ascend acl operator."""
        if not self.num_speculative_tokens:
            acl_hidden_state = super().execute_ascend_operator(acl_inputs, acl_param, is_prefill)
            self.save_token_num_per_expert()
            return acl_hidden_state

        if is_mtp:
            encoder_operation = self.acl_encoder_operation_mtp
            decoder_operation = self.acl_decoder_operation_mtp
        else:
            encoder_operation = self.acl_encoder_operation
            decoder_operation = self.acl_decoder_operation

        if is_prefill:
            acl_model_out = encoder_operation.execute(acl_inputs, acl_param)
        else:
            acl_model_out = decoder_operation.execute(acl_inputs, acl_param)

        if not is_mtp and ENV.enable_expert_hotpot_gather:
            cumsum_list = acl_model_out[-1]
            cumsum_list = cumsum_list[:-1, :-1]
            per_expert_token_num = cumsum_list.clone()
            per_expert_token_num[:, 1:] -= cumsum_list[:, :-1]
            if self.warmup_is_end and is_prefill:
                self.total_prefill_token_num_per_expert = per_expert_token_num \
                    if self.total_prefill_token_num_per_expert is None \
                    else self.total_prefill_token_num_per_expert + per_expert_token_num
            elif self.warmup_is_end:
                self.total_decode_token_num_per_expert = per_expert_token_num \
                    if self.total_decode_token_num_per_expert is None \
                    else self.total_decode_token_num_per_expert + per_expert_token_num
            acl_model_out = acl_model_out[:-1]
            self.save_token_num_per_expert()

        try:
            logits = acl_model_out[0]
            last_hidden_states = acl_model_out[1]
        except IndexError as e:
            raise RuntimeError("运行时报错，请开启日志进一步定位问题") from e
        return logits, last_hidden_states


    def prepare_mtp_roll_inputs_for_ascend(self, acl_inputs_mtp, acl_param_mtp, q_lens, 
                                            logits_mtp, hidden_states_mtp, first_op=False):

        next_token = logits_mtp.argmax(dim=-1)
        # all roll

        cumsum_indices = torch.cumsum(q_lens, dim=0)
        lm_head_indices_dp = cumsum_indices - 1
        
        acl_inputs_mtp[0] = torch.roll(acl_inputs_mtp[0], shifts=-1, dims=0)
        acl_inputs_mtp[0][lm_head_indices_dp] = next_token # input_ids
        acl_inputs_mtp[1] += 1 # position_ids
        
        if first_op:
            acl_inputs_mtp.insert(18, hidden_states_mtp)
        else:
            acl_inputs_mtp[18] = hidden_states_mtp
            
        return acl_inputs_mtp, acl_param_mtp

    def prepare_repeated_batch(self, acl_inputs, acl_param, q_lens):

        # blocktables
        acl_inputs[5] = acl_inputs[5].repeat_interleave(q_lens, dim=0)
        # input_lengths
        input_lengths = acl_inputs[11]
        repeat_input_lengths = input_lengths.repeat_interleave(q_lens, dim=0)
                
        offset = torch.cat([torch.arange(-i + 1, 1) for i in q_lens]).npu()
        repeat_input_lengths = repeat_input_lengths + offset

        acl_inputs[11] = repeat_input_lengths.to(torch.int32)
        
        acl_param = json.dumps({
            SEQUENCE_LENGTH: repeat_input_lengths.tolist(),
        })
        
        return acl_inputs, acl_param

    def forward(
            self,
            input_ids: torch.Tensor,
            position_ids: torch.Tensor,
            is_prefill: bool,
            kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
            block_tables: torch.Tensor,
            slots: torch.Tensor,
            input_lengths: torch.Tensor,
            max_seq_len: int,
            lm_head_indices: Optional[torch.Tensor] = None,
            **kwargs,
    ) -> torch.Tensor:
        if not self.ascend_weight:
            self.get_adapter_ids(**kwargs)
            self.init_ascend_weight()

        if not self.num_speculative_tokens:
            prof = span_start("prepareInputs", True)
            self.init_kvcache(kv_cache)
            acl_inputs, acl_param, perf_start_time = self.prepare_inputs_for_ascend(
                input_ids, position_ids, is_prefill, kv_cache,
                block_tables, slots, input_lengths, max_seq_len,
                lm_head_indices, **kwargs)
            span_end(prof, True)
            
            prof = span_start("operatorExecute", True)
            logits = self.execute_ascend_operator(acl_inputs, acl_param, is_prefill)
            self.free_operation_inputs(is_prefill)
            span_end(prof, True)
            return (logits, perf_start_time)
        
        # prefill
        if is_prefill:
            # llm prefill
            self.init_kvcache(kv_cache)
            acl_inputs, acl_param, _ = self.prepare_inputs_for_ascend(
                input_ids, position_ids, is_prefill, kv_cache,
                block_tables, slots, input_lengths, max_seq_len,
                lm_head_indices, **kwargs)
            logits, hidden_states = self.execute_ascend_operator(acl_inputs, acl_param, is_prefill)
            torch.npu.synchronize()
            llm_logits, llm_hidden_states = logits, hidden_states[lm_head_indices]

            q_lens = input_lengths            
            logits_mtp, hidden_states_mtp = logits, hidden_states
            acl_inputs_mtp, acl_param_mtp = acl_inputs, acl_param
            for mtp_idx in range(self.num_speculative_tokens):
                self.acl_encoder_operation_mtp.set_kv_cache(self.mtp_k_caches[mtp_idx: mtp_idx + 1], 
                                                            self.mtp_v_caches[mtp_idx: mtp_idx + 1])
                fake_data = False
                if self.mapping.has_dp() and not ENV.enable_dp_partition_up:
                    lm_head_indices_dp_rank_ids = kwargs.get('lm_head_indices_dp_rank_ids')
                    logits_gather_indices = \
                            torch.arange(0, lm_head_indices_dp_rank_ids.shape[0])
                    logits_gather_indices = \
                            logits_gather_indices[lm_head_indices_dp_rank_ids == self.mapping.attn_dp.rank]
                    if logits_gather_indices.numel() > 0:
                        logits_mtp = logits_mtp[logits_gather_indices]
                    else:
                        fake_data = True

                    shard_effective_token_indices = kwargs.get('shard_effective_token_indices')
                    hidden_states_mtp = hidden_states_mtp[shard_effective_token_indices]

                if fake_data:
                    if mtp_idx == 0:
                        acl_inputs_mtp.insert(18, hidden_states_mtp)
                else:
                    acl_inputs_mtp, acl_param_mtp = \
                    self.prepare_mtp_roll_inputs_for_ascend(
                        acl_inputs_mtp, acl_param_mtp, q_lens, logits_mtp, hidden_states_mtp, mtp_idx == 0)
                if self.eplb_level == EPLBType.STATIC_EPLB and not ENV.enable_mtp_epwb_static:
                    acl_inputs[-7] = self.max_device_expert_id_mtp
                    acl_inputs[-6] = self.start_device_expert_id_mtp
                    del acl_inputs[-1]
                logits_mtp, hidden_states_mtp = \
                    self.execute_ascend_operator(acl_inputs_mtp, acl_param_mtp, is_prefill, is_mtp=True)
             
            return (llm_logits, llm_hidden_states)
        else:
            hidden_states = kwargs.get('hidden_states', None)
            is_mtp = hidden_states is not None
            if is_mtp:
                q_lens = kwargs.get('q_lens')
                q_lens = torch.tensor(q_lens).npu()
                hidden_states = kwargs.get('hidden_states', None)
                self.init_kvcache(kv_cache)
                acl_inputs, acl_param, _ = self.prepare_inputs_for_ascend(
                    input_ids, position_ids, is_prefill, kv_cache,
                    block_tables, slots, input_lengths, max_seq_len,
                    lm_head_indices, **kwargs)
                # mtp decode
                all_logits_mtp = []
                acl_inputs_mtp, acl_param_mtp = acl_inputs, acl_param
                shard_effective_token_indices = kwargs.get('shard_effective_token_indices')
                acl_inputs.insert(18, hidden_states.npu())
                if self.eplb_level == EPLBType.STATIC_EPLB and not ENV.enable_mtp_epwb_static:
                    acl_inputs[-7] = self.max_device_expert_id_mtp
                    acl_inputs[-6] = self.start_device_expert_id_mtp
                    del acl_inputs[-1]

                for mtp_idx in range(self.num_speculative_tokens):
                    self.acl_decoder_operation_mtp.set_kv_cache(self.mtp_k_caches[mtp_idx: mtp_idx + 1], 
                                                                self.mtp_v_caches[mtp_idx: mtp_idx + 1])
                    logits_mtp, hidden_states_mtp = \
                        self.execute_ascend_operator(acl_inputs_mtp, acl_param_mtp, is_prefill, is_mtp=True)
                    all_logits_mtp.append(logits_mtp)
                    
                    if mtp_idx < self.num_speculative_tokens - 1:
                        fake_data = False
                        if self.mapping.has_dp() and not ENV.enable_dp_partition_up:
                            lm_head_indices_dp_rank_ids = kwargs.get('lm_head_indices_dp_rank_ids')
                            logits_gather_indices = torch.arange(0, lm_head_indices_dp_rank_ids.shape[0])
                            logits_gather_indices = \
                                    logits_gather_indices[lm_head_indices_dp_rank_ids == self.mapping.attn_dp.rank]
                            if logits_gather_indices.numel() > 0:
                                logits_mtp = logits_mtp[logits_gather_indices]
                                hidden_states_mtp = hidden_states_mtp[shard_effective_token_indices]
                            else:
                                fake_data = True

                        if not fake_data:
                            acl_inputs_mtp, acl_param_mtp = \
                            self.prepare_mtp_roll_inputs_for_ascend(
                                acl_inputs_mtp, acl_param_mtp, q_lens, logits_mtp, hidden_states_mtp)

                if self.num_speculative_tokens > 1:
                    all_logits_mtp = torch.stack(all_logits_mtp, dim=1)
                    all_logits_mtp = all_logits_mtp.view(-1, all_logits_mtp.shape[-1])
                else:
                    all_logits_mtp = all_logits_mtp[0]
                return all_logits_mtp
            else:
                q_lens = kwargs.get('q_lens')
                self.init_kvcache(kv_cache)
                acl_inputs, acl_param, _ = self.prepare_inputs_for_ascend(
                    input_ids, position_ids, is_prefill, kv_cache,
                    block_tables, slots, input_lengths, max_seq_len,
                    lm_head_indices, **kwargs)
                if lm_head_indices is None:
                    lm_head_indices = torch.tensor(range(input_ids.shape[0]),
                                                   dtype=torch.int64, device=input_ids.device)
                acl_param = json.dumps({
                    "seqLen": input_lengths.tolist(),
                    "qLen": [int(i) for i in q_lens if i] if q_lens else None
                })

                if not self.speculate_enable:
                    q_lens = kwargs.get('q_lens')
                    q_lens = torch.tensor(q_lens).npu()
                    repeat_input_lengths = input_lengths.to(torch.int32).repeat_interleave(q_lens, dim=0)
                    offset = torch.cat([torch.arange(-i + 1, 1) for i in q_lens]).npu()
                    repeat_input_lengths = repeat_input_lengths + offset
                    acl_inputs[11] = repeat_input_lengths.to(torch.int32)

                    acl_param = json.dumps({
                        "seqLen": acl_inputs[11].tolist(),
                    })


                logits, hidden_states = self.execute_ascend_operator(acl_inputs, acl_param, is_prefill)
                if lm_head_indices is not None:
                    hidden_states = hidden_states[lm_head_indices]
                return (logits, hidden_states)

    def init_kvcache(self, kv_cache: List[Tuple[torch.Tensor, torch.Tensor]]):
        """Initialzie key-value cache."""
        kcache_id_diff = self.ascend_kcache_id != id(kv_cache[0][0])
        vcache_id_diff = self.ascend_vcache_id != id(kv_cache[0][1])
        kcache_shape_diff = self.ascend_kcache_shape != kv_cache[0][0].shape
        vcache_shape_diff = self.ascend_vcache_shape != kv_cache[0][1].shape
        kcache_diff = not self.ascend_kcache_id or kcache_id_diff or kcache_shape_diff
        vcache_diff = not self.ascend_vcache_id or vcache_id_diff or vcache_shape_diff
        if kcache_diff or vcache_diff:
            k_caches, v_caches = map(lambda x: list(x), zip(*kv_cache))
            print_log(self.tp_rank, logger.info, f"<<<<<<< ori {k_caches[0].shape=}")
            if self.soc_info.need_nz or self.nz_cache:
                k_caches = [torch_npu.npu_format_cast_(k_cache, 29) for k_cache in k_caches]
                v_caches = [torch_npu.npu_format_cast_(v_cache, 29) for v_cache in v_caches]
                logger.info(f"<<<<<<<after transdata {k_caches[0].shape=}")

            if self.num_speculative_tokens:
                self.acl_encoder_operation.set_kv_cache(k_caches[:-self.num_speculative_tokens], 
                                                        v_caches[:-self.num_speculative_tokens])
                self.acl_decoder_operation.set_kv_cache(k_caches[:-self.num_speculative_tokens], 
                                                        v_caches[:-self.num_speculative_tokens])
                self.mtp_k_caches = k_caches[-self.num_speculative_tokens:]
                self.mtp_v_caches = v_caches[-self.num_speculative_tokens:]
            else:
                self.acl_encoder_operation.set_kv_cache(k_caches, v_caches)
                self.acl_decoder_operation.set_kv_cache(k_caches, v_caches)

            self.ascend_kcache_id = id(kv_cache[0][0])
            self.ascend_vcache_id = id(kv_cache[0][1])
            self.ascend_kcache_shape = kv_cache[0][0].shape
            self.ascend_vcache_shape = kv_cache[0][1].shape
            print_log(self.tp_rank, logger.info,
                      f">>>>>>id of kcache is {self.ascend_kcache_id} id of vcache is {self.ascend_vcache_id}")
