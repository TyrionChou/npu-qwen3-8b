# Copyright (c) Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.

from atb_llm.models.base.config import BaseConfig
from atb_llm.models.base.flash_causal_lm_v2 import FlashCausalLMV2
from atb_llm.models.qwen2.modeling_qwen2 import FlashQwenModel
from atb_llm.models.qwen2.modeling_qwen2_python import Qwen2Model
from atb_llm.utils.data.weight_wrapper import AttnWrapper, MlpWrapper
from atb_llm.utils.layers import load_column_multi, TensorHead, TensorEmbedding
from atb_llm.utils.loader.linear_loader import ColumnParallelLinear
from atb_llm.utils.loader.weight_loader import WeightLoader
from atb_llm.utils.op_backend import OpBackend
from atb_llm.utils.weights import Weights


class FlashQwen2ForCausalLMV2(FlashCausalLMV2):
    """
    This class serves as the primary functional class that inherits from the `FlashCausalLMV2` class.
    It is responsible for constructing the model architecture by integrating the FlashQwenModel.
    """
    def __init__(
            self,
            config: BaseConfig,
            weights: Weights | WeightLoader,
            lmhead_prefix="lm_head",
            model_prefix="model",
            **kwargs
    ) -> None:
        super().__init__(config, weights, **kwargs)
        self.infer_param.update_matmul_nz(self.soc_info, config.quantize)

        # model structure
        if self.infer_param.enable_python_engine:
            self.lm_head = ColumnParallelLinear.load(config, weights, [lmhead_prefix])
            self.model = Qwen2Model(
                config,
                weights,
                model_prefix,
                config_metadata=self.config_metadata,
                infer_param=self.infer_param,
                **kwargs
            )
        else:
            if self.config.quantize == "w8a8sc":
                self.lm_head = TensorHead.load_weight(
                    config,
                    prefix="lm_head",
                    weights=weights,
                    is_norm=False,
                )
            else:
                if config.tie_word_embeddings:
                    self.lm_head = load_column_multi(
                        config,
                        prefixes=[f"{model_prefix}.embed_tokens"],
                        weights=weights,
                        head_size=1,
                        lm_head=True,
                    )
                else:
                    self.lm_head = load_column_multi(
                        config,
                        prefixes=[f"{lmhead_prefix}"],
                        weights=weights,
                        head_size=1,
                        lm_head=True,
                    )
            self.model = FlashQwenModel(
                config,
                weights,
                attn_decode_backend=self.attn_decode_backend,
            )
            if not kwargs.get("transformer_wte_parallel", True):
                self.model.wte = TensorEmbedding(
                    prefix=f"{model_prefix}.embed_tokens", weights=weights
                )
                for p in self.model.wte.parameters():
                    p.requires_grad = False

        self.attn_wrapper = AttnWrapper(
            norm_name="ln_1",
            wrapper_name="attn",
            pack_name="c_attn",
            sep_names=["q_proj", "k_proj", "v_proj"],
            o_name="c_proj"
        )
        self.mlp_wrapper = MlpWrapper(
            norm_name="ln_2",
            wrapper_name="mlp",
            pack_name="w2_w1",
            sep_names=["w2", "w1"],
            down_name="c_proj"
        )
        # 若开启,则冒烟测试卡50ms数据需重新调整(layer多一个输出,内存占用变大)
        self.enable_intra_layer_add_norm = False
        self.enable_inter_layer_add_norm = False
        self.enable_swiglu_quant = False

    @property
    def model_torch_class_name(self):
        """
        This method returns the name of the PyTorch class for the model.
        """
        return "qwen_QwenDecoderModel"

    def update_engine_static_param(self):
        """
        The method is responsible for setting the static parameters for the engine.
        It accomplishes this by first obtaining a set of default parameters by calling
        the `update_engine_static_param method` from the `FlashCausalLMV2` class.
        Afterward, it updates these default parameters by adding the following settings:
        whether to utilize tensor parallelism in word embedding.
        """
        engine_static_param = super().update_engine_static_param()
        engine_static_param.update({
            "isEmbeddingParallel": True,
            "isYarn": self.long_seq_decorator.active,
            "isLongSeq": self.long_seq_decorator.active,
            "linearHasBias": [[True, False, False, False]] * self.config.num_hidden_layers,
            "enableIntraLayerAddNorm": self.enable_intra_layer_add_norm,
            "enableInterLayerAddNorm": self.enable_inter_layer_add_norm,
            "enableQScale": any([self.config.transformers_version in ["4.43.1", "4.44.0"]]) and
                            self.config.num_hidden_layers == 28 and
                            self.soc_info.need_nz,
                            # QwenCode2.5-7B-Instruct/Qwen2.5-7B/1.5B-Instruct模型时为True, 其他模型为False
            "matmulBackend": OpBackend.ACLNN if self.soc_info.matmul_nd_nz else OpBackend.ATB,
        })
        return engine_static_param
