# Copyright Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from atb_llm.models.base.base_lm import BaseLM
from atb_llm.models.base.engine.engine_wrapper import EngineWrapper


class LayerSkippedSpeculateEngineWrapper(EngineWrapper):
    def create_engine(self, context: BaseLM, **kwargs):
        if context.infer_param.enable_python_engine:
            raise NotImplementedError
        else:
            attn_skipped_layers = context.infer_param.inference_mode.attn_skipped_layers
            mlp_skipped_layers = context.infer_param.inference_mode.mlp_skipped_layers
            engine_weight_param = kwargs.get('engine_weight_param', {})
            engine = super().create_engine_cpp(
                context.model_torch_class_name,
                {**context.engine_static_param, **engine_weight_param, "isPrefill": False, "enableSpeculate": True,
                 "attnSkipLayerSet": attn_skipped_layers, "mlpSkipLayerSet": mlp_skipped_layers}
            )
        return engine

    def activate(self, context: BaseLM, **kwargs) -> bool:
        ls_enable = context.infer_param.inference_mode.enable_layer_skipped
        if not ls_enable:
            return False
        is_prefill = kwargs.get("is_prefill", False)
        if is_prefill:
            return False
        part_decoder = context.infer_param.inference_mode.enable_part_decoder
        if not part_decoder:
            return False
        q_lens = kwargs.get("q_lens", None)
        if q_lens is not None:
            return True
        return False
