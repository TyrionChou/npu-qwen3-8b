# Copyright Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from typing import List

import torch

from atb_llm.models.base.base_lm import PostionalEmbeddingInfo
from atb_llm.models.base.config import BaseConfig


class LongSeqDecorator:
    """
    This class contains methods and attributes required to enable long sequences functionality in a model.
    """
    def __init__(self, config: BaseConfig, **kwargs):
        self.config = config
        if config.rope_scaling.rope_type == "yarn" or config.rope_scaling.rope_type == "dynamic":
            self.active = True
        else:
            self.active = False

    def update_inputs(
            self,
            engine_inputs: List[torch.Tensor],
            pos_embed_info: PostionalEmbeddingInfo,
            position_ids
        ) -> None:
        if not self.active:
            return
        if self.config.rope_scaling.rope_type == "yarn":
            engine_inputs[1] = pos_embed_info.generator.position_ids_expanded
            engine_inputs.append(pos_embed_info.generator.ntk_inv_freqs)
            engine_inputs.append(pos_embed_info.generator.pos_lens)
            engine_inputs.append(position_ids)
        else:
            engine_inputs.append(pos_embed_info.generator.position_ids_expanded)
            engine_inputs.append(pos_embed_info.generator.ntk_inv_freqs)
            engine_inputs.append(pos_embed_info.generator.pos_lens)