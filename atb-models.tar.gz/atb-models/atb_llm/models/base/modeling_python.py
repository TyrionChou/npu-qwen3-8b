# coding=utf-8
# Copyright 2022 EleutherAI and the HuggingFace Inc. team. All rights reserved.
#
# This code is based on EleutherAI's GPT-NeoX library and the GPT-NeoX
# and OPT implementations in this library. It has been modified from its
# original forms to accommodate minor architectural differences compared
# to GPT-NeoX and OPT used by the Meta AI team that trained the model.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from ... import nn
from ...nn.ops import Ops
from ...utils.loader.weight_loader import WeightLoader
from ...models.base.config import BaseConfig


class BaseLayer(nn.Module):
    def __init__(self, config: BaseConfig, weight_loader: WeightLoader, prefix: str, layer_idx: int, **kwargs):        
        super().__init__()
        self.config = config
        self.prefix = f"{prefix}.layers.{layer_idx}"
        self.layer_idx = layer_idx

        self.self_attn = None
        self.mlp = None
        self.input_layernorm = None
        self.post_attention_layernorm = None

    def forward(self, inputs, cos_emb, sin_emb, k_cache, v_cache, slots, attention_mask=None,
                seq_len=None, block_table=None, token_offset=None, layer_ids=None, is_prefill: bool = True):
        norm_out = self.input_layernorm(inputs)
        attn_out = self.self_attn(norm_out, cos_emb, sin_emb, k_cache, v_cache, slots, attention_mask,
                                    seq_len, block_table, token_offset, layer_ids, is_prefill)
        res_add = attn_out + inputs
        post_norm_out = self.post_attention_layernorm(res_add)
        mlp_out = self.mlp(post_norm_out)
        out = mlp_out + res_add
        return out


class BaseModel(nn.Module):
    def __init__(self, config: BaseConfig, weight_loader: WeightLoader, prefix: str = "model", **kwargs):
        super().__init__()
        self.config = config
        self.mapping = weight_loader.mapping
        self.prefix = prefix

        self.parallel_embedding = False

        self.embed_tokens = None
        self.layers = None
        self.norm = None

    def forward(self, input_ids, position_ids, cosine_table, sine_table, k_caches, v_caches, slots_mapping=None,
                attention_mask=None, seq_len=None, block_table=None, token_offset=None, kv_cache_idx=None,
                is_prefill: bool = True, **kwargs):
        is_fa = False if token_offset is None and kv_cache_idx is None else True
        
        if self.parallel_embedding and self.mapping.world_size > 1:
            gather_out = self.embed_tokens(input_ids)
            all_gather_out = nn.distributed.all_gather(
                gather_out, rank=self.mapping.rank, rank_size=self.mapping.world_size
            )
            if is_fa:
                hidden_states = all_gather_out.permute([1, 2, 0, 3]).reshape(
                    lambda org_shape: [org_shape[0], org_shape[1], org_shape[2] * org_shape[3]]
                )
            else:
                hidden_states = all_gather_out.permute([1, 0, 2]).reshape(
                    lambda org_shape: [org_shape[0], org_shape[1] * org_shape[2]]
                )
        else:
            hidden_states = self.embed_tokens(input_ids)
        cos_emb = Ops.gather(cosine_table, position_ids)
        sin_emb = Ops.gather(sine_table, position_ids)
        if is_fa:
            cos_emb = cos_emb.reshape(lambda org_shape: [org_shape[0] * org_shape[1], org_shape[2]])
            sin_emb = sin_emb.reshape(lambda org_shape: [org_shape[0] * org_shape[1], org_shape[2]])
        
        for i in range(self.config.num_hidden_layers):
            hidden_states = self.layers[i](
                hidden_states, cos_emb, sin_emb, k_caches[i], v_caches[i], slots_mapping,
                attention_mask, seq_len, block_table, token_offset, kv_cache_idx, is_prefill
            )

        hidden_states = self.norm(hidden_states)

        return hidden_states