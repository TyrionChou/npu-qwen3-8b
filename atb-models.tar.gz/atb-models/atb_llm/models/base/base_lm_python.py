# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.
import torch

from ... import nn
from ...models.base.base_lm import BaseLM
from ...models.base.config import BaseConfig
from ...models.base.engine.engine_manager import engine_manager
from ...nn.network import Tensor, get_default_net
from ...nn.ops import Ops
from ...nn.parameter import WeightParameter
from ...utils.loader.weight_loader import WeightLoader


class BaseLMPython(BaseLM, nn.Module):
    """
    Base class for language models that leverages an inference engine implemented in C++.

    Args:
        config (BaseConfig): model configuration.
        weights (Weights): Weights object to load model weights.
        **kwargs: Additional keyword arguments.
    """
    def __init__(self, config: BaseConfig, weights: WeightLoader, **kwargs):
        super().__init__(config, weights, **kwargs)
        nn.Module.__init__(self)

        # model weights
        self.device_weights_dict = {}

        # engine input and outputes
        self.engine_inputs_dict = {}
        self.engine_outputs_dict = {}

    def get_device_weights(self, **kwargs):
        """
        Retrieves the weights for the device.

        Args:
            **kwargs: Additional keyword arguments.

        Returns:
            WeightWrapper: The weight wrapper object contains weight metadata.
        """
        for _, parameter in self.model.named_parameters():
            if isinstance(parameter, WeightParameter):
                parameter.weight_format_cast(self.soc_info.need_nz or self.infer_param.enable_matmul_nz)
            self.device_weights_dict.update({parameter.name : parameter.data})
        if isinstance(self.lm_head.module.weight, WeightParameter):
            self.lm_head.module.weight.weight_format_cast(self.soc_info.need_nz or self.infer_param.enable_matmul_nz)
        self.device_weights_dict.update({self.lm_head.module.weight.name : self.lm_head.module.weight})

    def get_input_names(self, is_prefill: bool, **kwargs):
        if self.is_fa:
            input_names = ["input_ids", "position_ids", "attention_mask", "seq_len", 
                            "cosine_table", "sine_table", "kv_cache_idx", "token_offset", "lm_head_indices"]
            return input_names
        else:
            input_names = []
            default_input_names = ["input_ids", "position_ids", "slots_mapping", "seq_len", 
                                    "cosine_table", "sine_table"]
            input_names.extend(default_input_names)
            if is_prefill:
                input_names.extend(["attention_mask", "lm_head_indices"])
            else:
                input_names.extend(["block_table"])
            return input_names

    def build_engine(self, is_prefill: bool, **kwargs):
        input_names = self.get_input_names(is_prefill, **kwargs)
        args = {}
        for name in input_names:
            args[name] = Tensor(name)
        
        k_caches = []
        v_caches = []
        for i in range(self.config.num_hidden_layers):
            k_caches.append(Tensor(f"layer_{i}_k_cache"))
            v_caches.append(Tensor(f"layer_{i}_v_cache"))
        args["k_caches"] = k_caches
        args["v_caches"] = v_caches
        args["is_prefill"] = is_prefill

        if is_prefill:
            lm_head_indices = args.get("lm_head_indices")
            hidden_states = self.model(**args)
            hidden_states_ = Ops.gather(hidden_states, lm_head_indices, 1 if self.is_fa else 0)
            lm_head_out = self.lm_head(hidden_states_)
            logits = nn.distributed.all_gather(lm_head_out, self.mapping.rank, self.mapping.world_size)
            get_default_net().mark_output(
                logits if self.mapping.world_size == 1 else logits.permute([1, 2, 0, 3] if self.is_fa else [1, 0, 2]),
                "model_out"
            )
        else:
            hidden_states = self.model(**args)
            lm_head_out = self.lm_head(hidden_states)
            logits = nn.distributed.all_gather(lm_head_out, self.mapping.rank, self.mapping.world_size)
            get_default_net().mark_output(
                logits if self.mapping.world_size == 1 else logits.permute([1, 2, 0, 3] if self.is_fa else [1, 0, 2]),
                "model_out"
            )

    def build_engines(self, **kwargs) -> None:
        """
        Builds inference engines for the model based on model parameters.

        Args:
            **kwargs: Additional keyword arguments.
        """
        BaseLMPython.get_device_weights(self)
        for engine_class in engine_manager.get_engine_classes(self):
            engine_wrapper = engine_class(self)
            engine_wrapper.engine.set_weights(self.device_weights_dict)
            engine_manager.register_engine(engine_wrapper)

    def execute_engine(self, **kwargs) -> torch.Tensor:
        """
        Executes the engine to generate the model's output.

        Args:
            **kwargs: Additional keyword arguments.

        Returns:
            torch.Tensor: Logits.

        Raises:
            RuntimeError: If engine execution fails.
        """
        engine = engine_manager.choose_engine(self, **kwargs)
        try:
            engine.forward(self.engine_inputs_dict, self.engine_outputs_dict, self.engine_runtime_param)
            hidden_state = self.engine_outputs_dict["model_out"]
        except KeyError as e:
            raise RuntimeError("Engine execution error. "
                               "Enable log: export ASDOPS_LOG_LEVEL=ERROR, "
                               "export ASDOPS_LOG_TO_STDOUT=1 to find the first error. "
                               "For more details, see the MindIE official document.") from e
        return hidden_state