# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.

from dataclasses import dataclass
from janus.models.modeling_vlm import MultiModalityConfig

from ..base.config import BaseConfig
from ..llama.config_llama import LlamaConfig


@dataclass
class JanusConfig(BaseConfig):
    max_position_embeddings: int = 16384
    vocab_size: int = 102400
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.model_type = 'janus'

        multi_modality_config = MultiModalityConfig(**kwargs)
        self.vision_config = multi_modality_config.vision_config
        self.aligner_config = multi_modality_config.aligner_config
        self.gen_vision_config = multi_modality_config.gen_vision_config
        self.gen_aligner_config = multi_modality_config.gen_aligner_config
        self.gen_head_config = multi_modality_config.gen_head_config

        language_config = kwargs.get("language_config", {})
        self.language_config = LlamaConfig.from_dict(language_config)
        self.language_config.head_dim = self.language_config.hidden_size // self.language_config.num_attention_heads