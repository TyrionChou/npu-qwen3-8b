# Copyright Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from typing import Optional, List, Tuple

import torch

from atb_llm.models.base.config import BaseConfig
from atb_llm.models.base.flash_causal_lm_v2 import FlashCausalLMV2
from atb_llm.models.internlm2.v2.modeling_internlm2 import FlashInternlm2Model
from atb_llm.utils.data.weight_wrapper import AttnWrapper, MlpWrapper
from atb_llm.utils.env import ENV
from atb_llm.utils.layers import load_column_multi
from atb_llm.utils.weights import Weights


class FlashInternlm2ForCausalLMV2(FlashCausalLMV2):
    """
    This class serves as the primary functional class that inherits from the `FlashCausalLMV2` class.
    It is responsible for constructing the model architecture by integrating the FlashLlamaModel.
    """

    def __init__(self, config: BaseConfig, weights: Weights, lmhead_prefix="output", model_prefix="model", **kwargs):
        super().__init__(config, weights, **kwargs)
        self.max_position_embeddings = config.max_position_embeddings
        self.long_seq_decorator.active = False
        # 按需打开特性开关
        self.infer_param.update_matmul_nz(
            self.soc_info, config.quantize
        )

        self.attn_wrapper = AttnWrapper(
            norm_name='attention_norm',
            wrapper_name='attention',
            pack_name='wqkv',
            sep_names=['q_proj', 'k_proj', 'v_proj'],
            o_name='wo'
        )
        self.mlp_wrapper = MlpWrapper(
            norm_name='ffn_norm',
            wrapper_name='feed_forward',
            pack_name='w1_w3',
            sep_names=['w1', 'w3'],
            down_name='w2'
        )

        # model structure
        self.model = FlashInternlm2Model(config, weights, model_prefix)
        self.lm_head = load_column_multi(
            config,
            prefixes=[lmhead_prefix],
            weights=weights,
            head_size=1,
            lm_head=True,
        )

    @property
    def model_torch_class_name(self):
        """
        This method returns the name of the PyTorch class for the model.
        """
        return "internlm2_20b_DecoderModel"

    def update_engine_static_param(self):
        """
        更新参数,和存量的internlm2的C++保持一致
        """
        engine_static_param = super().update_engine_static_param()
        engine_static_param.update({
            "isEmbeddingParallel": self.model.parallel_embedding,
            # rename
            "rmsNormEps": engine_static_param.get("normEps"),
            "supportLcoc": engine_static_param.get("enableLcoc"),
            "supportSwiGLU": engine_static_param.get("enableSwiGLU"),
            "kvQuant": engine_static_param.get("enableKvQuant"),
            # 重置参数为字符串ROPE
            "positionEmbeddingType": "ROPE",
            # 增加参数
            "useImMask": True,
            "splitWithStride": True,
            "supportLora": False,
            "rankTableFile": ENV.rank_table_file
        })
        weight_wrapper = self.get_device_weights()
        engine_static_param.update({
            "linearQuantType": weight_wrapper.linear_type,
            "linearTransposeType": weight_wrapper.linear_transpose_types,
            "packQuantType": weight_wrapper.pack_quant_type,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
        })
        return engine_static_param

    def generate_positional_embedding(self, max_seq_len: int, **kwargs) -> None:
        """
        internlm2 dynamic
        在python测完成 pos_ids_expanded、inv_freq、pos_lens 转换 sine_embed_table和cosine_embed_table
        """
        max_seq_len_cached = max(self.max_position_embeddings, max_seq_len)
        rope_scaling_factor = self.config.rope_scaling.factor  # Dynamic NTK 外推方法的系数
        # warm_up 阶段会传入max_seq_len=max_input_length，导致 max_seq_len_cached 开始就达到最大
        if (self.config.rope_scaling.rope_type is None):
            # RotaryEmbedding
            self.pos_embed_info.generator.update_cos_sin_cache_total(self.torch_dtype, self.torch_device,
                                                                     self.max_position_embeddings)
        elif (self.config.rope_scaling.rope_type == "dynamic") and (max_seq_len_cached > self.max_position_embeddings):
            # DynamicNTKScalingRotaryEmbedding
            base = self.config.rope_theta * (
                    (rope_scaling_factor * max_seq_len_cached / self.max_position_embeddings) - (
                    rope_scaling_factor - 1)
            ) ** (self.config_metadata.head_dim / (self.config_metadata.head_dim - 2))
            self.pos_embed_info.generator = self.pos_embed_info.generator.static(dim=self.config_metadata.head_dim,
                                                                                 base=base, device="cpu",
                                                                                 scaling_factor=1.0).to(
                self.torch_device)
            self.pos_embed_info.generator.update_cos_sin_cache_total(self.torch_dtype, self.torch_device,
                                                                     max_seq_len_cached)
        else:  # LinearScalingRotaryEmbedding
            # 如果 max_input_length > max_position_embeddings, 需要重置 base 和 rotary_embedding.inv_freq
            self.pos_embed_info.generator = self.pos_embed_info.generator.static(dim=self.config_metadata.head_dim,
                                                                                 base=self.config.rope_theta,
                                                                                 device="cpu",
                                                                                 scaling_factor=1.0,
                                                                                 ).to(self.torch_device)
            self.pos_embed_info.generator.update_cos_sin_cache_total(self.torch_dtype, self.torch_device,
                                                                     self.max_position_embeddings)
        self.pos_embed_info.cosine_table = self.pos_embed_info.generator.get_cos_cached_total()
        self.pos_embed_info.sine_table = self.pos_embed_info.generator.get_sin_cached_total()

    def prepare_default_inputs(
            self,
            input_ids: torch.Tensor,
            position_ids: torch.Tensor,
            is_prefill: bool,
            kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
            block_tables: torch.Tensor,
            slots: torch.Tensor,
            input_lengths: torch.Tensor,
            max_seq_len: int,
            lm_head_indices: Optional[torch.Tensor] = None,
            **kwargs
    ) -> None:
        """
        This method prepares the default inputs for the model.
        It first calls the parent class method to prepare the default inputs.
        Then, it updates input embedding and input ids of the input engines.
        """
        super().prepare_default_inputs(
            input_ids, position_ids, is_prefill, kv_cache,
            block_tables, slots, input_lengths, max_seq_len,
            lm_head_indices, **kwargs)
        self.engine_inputs = [
            self.placeholder if self.infer_param.skip_word_embedding else input_ids,
            input_ids if self.infer_param.skip_word_embedding else self.placeholder,
            *self.engine_inputs[1:], self.placeholder
        ]
