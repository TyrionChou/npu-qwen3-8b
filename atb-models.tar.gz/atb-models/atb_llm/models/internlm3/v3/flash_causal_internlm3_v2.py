# Copyright Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from typing import Optional, List, Tuple

import torch

from atb_llm.models.base.config import BaseConfig
from atb_llm.models.base.flash_causal_lm_v2 import FlashCausalLMV2
from atb_llm.models.llama.modeling_llama import FlashLlamaModel
from atb_llm.utils.layers import load_column_multi
from atb_llm.utils.weights import Weights


class FlashInternlm3ForCausalLMV2(FlashCausalLMV2):
    """
    This class serves as the primary functional class that inherits from the `FlashCausalLMV2` class.
    It is responsible for constructing the model architecture by integrating the FlashLlamaModel.
    """

    def __init__(self, config: BaseConfig, weights: Weights, lmhead_prefix="lm_head", model_prefix="model", **kwargs):
        super().__init__(config, weights, **kwargs)
        self.infer_param.update_matmul_nz(
            self.soc_info, config.quantize
        )
        # model structure
        self.model = FlashLlamaModel(config, weights, model_prefix, attn_decode_backend=self.attn_decode_backend)
        self.lm_head = load_column_multi(
            config,
            prefixes=[lmhead_prefix],
            weights=weights,
            head_size=1,
            lm_head=True,
        )

    @property
    def model_torch_class_name(self):
        """
        This method returns the name of the PyTorch class for the model.
        """
        return "llama_LlamaDecoderModel"

    def update_engine_static_param(self):
        """
        The method is responsible for setting the static parameters for the engine.
        It accomplishes this by first obtaining a set of default parameters by calling
        the `update_engine_static_param method` from the `FlashCausalLMV2` class.
        Afterward, it updates these default parameters by adding the following settings:
        whether to utilize tensor parallelism in word embedding.
        """
        engine_static_param = super().update_engine_static_param()
        engine_static_param.update({
            "isEmbeddingParallel": self.model.parallel_embedding,
            "isLongSeq": self.long_seq_decorator.active
        })
        return engine_static_param

    def prepare_default_inputs(
            self,
            input_ids: torch.Tensor,
            position_ids: torch.Tensor,
            is_prefill: bool,
            kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
            block_tables: torch.Tensor,
            slots: torch.Tensor,
            input_lengths: torch.Tensor,
            max_seq_len: int,
            lm_head_indices: Optional[torch.Tensor] = None,
            **kwargs
    ) -> None:
        """
        This method prepares the default inputs for the model.
        It first calls the parent class method to prepare the default inputs.
        Then, it updates input embedding and input ids of the input engines.
        """
        super().prepare_default_inputs(
            input_ids, position_ids, is_prefill, kv_cache,
            block_tables, slots, input_lengths, max_seq_len,
            lm_head_indices, **kwargs)
        self.engine_inputs = [
            self.placeholder if self.infer_param.skip_word_embedding else input_ids,
            input_ids if self.infer_param.skip_word_embedding else self.placeholder,
            *self.engine_inputs[1:]
        ]
