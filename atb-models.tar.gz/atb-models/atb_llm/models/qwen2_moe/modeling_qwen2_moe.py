# coding=utf-8
# Copyright 2022 EleutherAI and the HuggingFace Inc. team. All rights reserved.
#
# This code is based on EleutherAI's GPT-NeoX library and the GPT-NeoX
# and OPT implementations in this library. It has been modified from its
# original forms to accommodate minor architectural differences compared
# to GPT-NeoX and OPT used by the Meta AI team that trained the model.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import torch.distributed
from torch import nn
from transformers.activations import ACT2FN

from atb_llm.utils.layers import (
    TensorParallelRowLinear,
    TensorParallelEmbedding,
    load_column_multi,
)
from atb_llm.utils import OpBackend
from atb_llm.utils.log import logger
from atb_llm.utils.log.error_code import ErrorCode
from ..qwen2.modeling_qwen2 import FlashQwenAttention


class QwenRMSNorm(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        """
        QwenRMSNorm is equivalent to T5LayerNorm
        """
        super().__init__()

        weight = weights.get_tensor(f"{prefix}.weight")
        self.weight = nn.Parameter(weight)
        self.variance_epsilon = eps


class QwenRMSNormBias(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        """
        QwenRMSNorm is equivalent to T5LayerNorm
        """
        super().__init__()

        weight = weights.get_tensor(f"{prefix}.weight")
        try:
            bias = weights.get_tensor(f"{prefix}.bias")
        except AssertionError:
            bias = torch.zeros(weight.shape, dtype=torch.float16)
        self.weight = nn.Parameter(weight)
        self.bias = nn.Parameter(bias)
        self.variance_epsilon = eps


class QwenRMSNormWrapper(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        """
        QwenRMSNorm is equivalent to T5LayerNorm
        """
        super().__init__()

        self.ori = QwenRMSNorm(prefix, weights, eps)
        self.anti = QwenRMSNormBias(f'{prefix}.module', weights, eps)


class QwenRMSNormAntiOutlierWrapper(nn.Module):
    def __init__(self, prefix, weights, eps=1e-6):
        """
        QwenRMSNorm is equivalent to T5LayerNorm
        """
        super().__init__()

        self.ori = QwenRMSNorm(f'{prefix}.ori', weights, eps)
        self.anti = QwenRMSNormBias(f'{prefix}.anti', weights, eps)

        
class QwenMLP(nn.Module):
    def __init__(self, prefix, config, weights, intermediate_size):
        super().__init__()
        self.act_fn = ACT2FN[config.hidden_act]
        self.gate_up_proj = load_column_multi(
            config,
            prefixes=[f"{prefix}.gate_proj", f"{prefix}.up_proj"],
            weights=weights,
            head_size=1,
        )
        self.down_proj = TensorParallelRowLinear.load(
            config,
            prefix=f"{prefix}.down_proj",  # down_proj
            weights=weights,
            bias=False,
        )
        self.intermediate_size = (
                (intermediate_size + weights.process_group.size() - 1) // weights.process_group.size()
        )


class QwenEp(nn.Module):
    """
    for experts parallel.
    """
    def __init__(self, prefix, config, weights):
        super().__init__()
        expert_gate_proj = weights.get_tensor(f"{prefix}.gate_proj.weight")
        self.expert_gate_proj = nn.Parameter(expert_gate_proj)
        expert_up_proj = weights.get_tensor(f"{prefix}.up_proj.weight")
        self.expert_up_proj = nn.Parameter(expert_up_proj)
        expert_down_proj = weights.get_tensor(f"{prefix}.down_proj.weight")
        self.expert_down_proj = nn.Parameter(expert_down_proj)


class QwenExpertGate(nn.Module):
    def __init__(self, prefix, config, weights):
        super().__init__()
        weight = weights.get_tensor(f"{prefix}.weight")
        self.weight = nn.Parameter(weight)


class QwenSharedExpertGate(nn.Module):

    def __init__(self, prefix, config, weights):
        super().__init__()
        weight = weights.get_tensor(f"{prefix}.weight")
        self.weight = nn.Parameter(weight)


class QwenMoe(nn.Module):
    """
    A mixed expert module containing shared experts.
    """

    def __init__(self, prefix, config, weights):
        super().__init__()
        process_group = weights.process_group
        self.tp_rank = process_group.rank()
        self.tp_world_size = process_group.size()
        self.tp = True  # default the model is tensor parallel
        self.expert_parallel_degree = 1 if self.tp else self.tp_world_size
        if self.expert_parallel_degree == 0:
            msg = "expert_parallel degree should not be 0!"
            logger.error(msg, ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE)
            raise ValueError(msg)
        expert_per_rank = config.num_experts / self.expert_parallel_degree

        self.config = config
        self.num_experts_per_tok = config.num_experts_per_tok
        # gate
        gate_prefix = f"{prefix}.gate"
        self.gate = QwenExpertGate(prefix=gate_prefix, config=config, weights=weights)
        # common experts
        expert_prefix = f"{prefix}.experts"
        if self.tp:
            self.experts = nn.ModuleList([QwenMLP(prefix=f"{expert_prefix}.{i}", config=config, weights=weights,
                                                  intermediate_size=config.moe_intermediate_size)
                                          for i in range(config.num_experts)])
        else:
            self.experts = nn.ModuleList()
            for j in range(config.num_experts):
                if j < expert_per_rank:
                    expert_id = int(j + self.tp_rank * expert_per_rank)
                    self.experts.append(QwenEp(prefix=f"{expert_prefix}.{expert_id}", config=config, weights=weights))

        if config.has_shared_expert:
            # share experts
            shared_expert_prefix = f"{prefix}.shared_expert"
            self.shared_expert = QwenMLP(prefix=shared_expert_prefix, config=config, weights=weights,
                                        intermediate_size=config.shared_expert_intermediate_size)
            # share experts gate
            shared_expert_gate_prefix = f"{prefix}.shared_expert_gate"
            self.shared_expert_gate = QwenSharedExpertGate(prefix=shared_expert_gate_prefix,
                                                           config=config, weights=weights)


class FlashQwenLayer(nn.Module):
    def __init__(self, layer_id, config, weights):
        super().__init__()
        prefix = f"model.layers.{layer_id}"
        self.self_attn = FlashQwenAttention(
            prefix=f"{prefix}.self_attn", config=config, weights=weights, attn_decode_backend=OpBackend.ATB
        )
        
        if config.is_dense_layer[layer_id]:
            # update for qwen3
            self.mlp = QwenMLP(prefix=f"{prefix}.mlp", config=config, weights=weights,
                                                  intermediate_size=config.intermediate_size)
        else:
            self.mlp = QwenMoe(prefix=f"{prefix}.mlp", config=config, weights=weights)

        self.input_layernorm = QwenRMSNorm(
            prefix=f"{prefix}.input_layernorm",
            weights=weights,
            eps=config.rms_norm_eps,
        )
        
        self.post_attention_layernorm = QwenRMSNorm(
            prefix=f"{prefix}.post_attention_layernorm",
            weights=weights,
            eps=config.rms_norm_eps,
        )


class FlashQwenModel(nn.Module):
    def __init__(self, config, weights):
        super().__init__()

        process_group = weights.process_group
        self.tp_rank = process_group.rank()
        self.tp_world_size = process_group.size()
        self.embed_tokens = TensorParallelEmbedding(
            prefix="model.embed_tokens", weights=weights
        )
        self.layers = nn.ModuleList(
            [
                FlashQwenLayer(
                    layer_id,
                    config,
                    weights,
                )
                for layer_id in range(config.num_hidden_layers)
            ]
        )
        self.norm = QwenRMSNorm(
            prefix="model.norm", weights=weights, eps=config.rms_norm_eps
        )
        self.gradient_checkpointing = False

        self.head_size = self.layers[0].self_attn.head_size
        self.num_heads = self.layers[0].self_attn.num_heads
