# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
from ...nn import Module, Parameter
from ...nn.ops import Ops
from ...nn.network import Tensor
from ...models.base.config import BaseConfig


class WordEmbedding(Module):
    def __init__(self, prefix: str, config: BaseConfig, **kwargs):
        super().__init__()
        self.config = config
        self.weight = Parameter(prefix=prefix, suffix="weight", target_dtype=config.torch_dtype)

    def __call__(self, input_ids: Tensor) -> Tensor:
        return self._forward(input_ids)

    def _forward(self, input_ids: Tensor) -> Tensor:
        out = Ops.gather(Tensor(self.weight.name), input_ids, axis=0, batch_dims=0)
        return out
