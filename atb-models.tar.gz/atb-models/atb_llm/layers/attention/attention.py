# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math

from ... import nn
from ...nn.ops import Ops
from ...utils.loader.weight_loader import WeightLoader
from ...models.base.config import BaseConfig
from ...models.base.base_lm import ConfigMetadata, InferenceParameter


class Attention(nn.Module):
    def __init__(
            self, config: BaseConfig, weight_loader: WeightLoader, prefix: str,
            config_metadata: ConfigMetadata, infer_param: InferenceParameter, **kwargs):
        super().__init__()
        self.config = config
        self.prefix = prefix
        self.mapping = weight_loader.mapping

        self.head_size = config_metadata.head_dim
        self.num_heads_per_rank = config_metadata.num_attention_heads
        self.num_key_value_heads_per_rank = config_metadata.num_key_value_heads

        self.qkv = None
        self.dense = None

    def forward(self, inputs, cos_table, sin_table, k_cache, v_cache, slot_mapping=None, mask=None, seq_lens=None,
                block_table=None, token_offset=None, layer_ids=None, is_prefill: bool = True):
        if token_offset is None and layer_ids is None:
            return self.forward_pa(inputs, cos_table, sin_table, k_cache, v_cache, slot_mapping=slot_mapping,
                                    mask=mask, seq_lens=seq_lens, block_table=block_table, is_prefill=is_prefill)
        else:
            return self.forward_fa(inputs, cos_table, sin_table, k_cache, v_cache, mask=mask, seq_lens=seq_lens,
                                    token_offset=token_offset, layer_ids=layer_ids, is_prefill=is_prefill)

    def forward_pa(self, inputs, cos_table, sin_table, k_cache, v_cache, slot_mapping=None, mask=None,
                    seq_lens=None, block_table=None, is_prefill: bool = True):
        if len(self.qkv) == 1:
            qkv_out = self.qkv(inputs)[0]
            q_size = self.head_size * self.num_heads_per_rank
            kv_size = self.head_size * self.num_key_value_heads_per_rank 
            q, k, v = Ops.split(qkv_out, split_dim=1, split_num=3, split_sizes=[q_size, kv_size, kv_size])
        else:
            q, k, v = self.qkv(inputs)

        q_out, k_out = nn.functional.rope(q, k, cos_table, sin_table, seq_lens)

        q_out_ = q_out.reshape(lambda org_shape: [org_shape[0], self.num_heads_per_rank, self.head_size])
        k_out_ = k_out.reshape(lambda org_shape: [org_shape[0], self.num_key_value_heads_per_rank, self.head_size])
        v_ = v.reshape(lambda org_shape: [org_shape[0], self.num_key_value_heads_per_rank, self.head_size])

        Ops.reshape_and_cache(k_out_, v_, k_cache, v_cache, slot_mapping)

        args = {
            "q": q_out_,
            "head_num": self.num_heads_per_rank, 
            "kv_head_num": self.num_key_value_heads_per_rank, 
            "kv_lens": seq_lens, 
            "qk_scale": 1.0 / math.sqrt(self.head_size),
        }
        if is_prefill:
            args.update({
                "k": k_out_,
                "v": v_,
                "mask": mask,
                "mask_type": nn.functional.MaskType.NORM,
                "is_triu_mask": True
            })
        else:
            args.update({
                "k_cache": k_cache, 
                "v_cache": v_cache, 
                "block_table": block_table
            })
        attn_score = nn.functional.paged_attention(**args)

        attn_score_ = attn_score.reshape(lambda org_shape: [org_shape[0], org_shape[1] * org_shape[2]])

        attn_out = self.dense(attn_score_)
        attn_out_ = nn.distributed.all_reduce(attn_out, rank=self.mapping.rank,
            rank_size=self.mapping.attn_tp.group_size)
        return attn_out_

    def forward_fa(self, inputs, cos_table, sin_table, k_cache, v_cache, mask=None, seq_lens=None,
                    token_offset=None, layer_ids=None, is_prefill:bool = True):
        if len(self.qkv) == 1:
            qkv_out = self.qkv(inputs)[0]
            q_size = self.head_size * self.num_heads_per_rank
            kv_size = self.head_size * self.num_key_value_heads_per_rank 
            q, k, v = Ops.split(qkv_out, split_dim=2, split_num=3, split_sizes=[q_size, kv_size, kv_size])
        else:
            q, k, v = self.qkv(inputs)
        
        q_ = q.reshape(lambda org_shape: [org_shape[0], org_shape[1], self.num_heads_per_rank, self.head_size])
        k_ = k.reshape(
            lambda org_shape: [org_shape[0], org_shape[1], self.num_key_value_heads_per_rank, self.head_size]
        )
        v_ = v.reshape(
            lambda org_shape: [org_shape[0], org_shape[1], self.num_key_value_heads_per_rank, self.head_size]
        )
        q_out, k_out = nn.functional.rope(q_, k_, cos_table, sin_table, seq_lens)

        k_cache_ = k_cache.reshape(lambda org_shape: [1] + list(org_shape))
        v_cache_ = v_cache.reshape(lambda org_shape: [1] + list(org_shape))
        attn_score = nn.functional.flash_attention(q=q_out, k=k_out, v=v_, k_cache=k_cache_, v_cache=v_cache_,
            mask=mask, mask_type=nn.functional.MaskType.NORM, head_num=self.num_heads_per_rank,
            kv_head_num=self.num_key_value_heads_per_rank, token_offset=token_offset, seq_lens=seq_lens,
            layer_id=layer_ids, qk_scale=1.0 / math.sqrt(self.head_size), is_prefill=is_prefill)

        attn_out = self.dense(attn_score)
        attn_out_ = nn.distributed.all_reduce(attn_out, rank=self.mapping.rank,
            rank_size=self.mapping.attn_tp.group_size)
        return attn_out_