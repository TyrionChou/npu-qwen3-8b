# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from ... import nn
from ...nn.ops import Ops
from ...utils.initial import NPUSocInfo
from ...utils.loader.weight_loader import WeightLoader
from ...models.base.config import BaseConfig
from ...models.base.base_lm import ConfigMetadata, InferenceParameter


class Mlp(nn.Module):
    def __init__(
            self, config: BaseConfig, weight_loader: WeightLoader, prefix: str,
            config_metadata: ConfigMetadata, infer_param: InferenceParameter, **kwargs):
        super().__init__()
        self.config = config
        self.prefix = prefix
        self.mapping = weight_loader.mapping
        self.need_nz = NPUSocInfo().need_nz

        self.gate_up = None
        self.down = None

    def forward(self, inputs, **kwargs):
        if len(self.gate_up) == 1:
            gate_up_out = self.gate_up(inputs)[0]
            if self.need_nz:
                gate_out, up_out = Ops.split(gate_up_out, split_dim=-1, split_num=2)
        else:
            gate_out, up_out = self.gate_up(inputs)
            if not self.need_nz:
                gate_up_out = Ops.cat(gate_out, up_out, dim=-1)

        if self.need_nz:
            gate_out_ = nn.functional.activation(gate_out, nn.functional.ActType.SWISH)
            act_out = gate_out_ * up_out
        else:
            act_out = nn.functional.activation(gate_up_out, nn.functional.ActType.SWIGLU)

        down_out = self.down(act_out)
        down_out_ = nn.distributed.all_reduce(down_out, rank=self.mapping.rank,
                        rank_size=self.mapping.mlp_tp.group_size)
        return down_out_