# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
from .. import nn


class SuperLayer(nn.Module):
    def __init__(self, module):
        super().__init__()
        self.module = module

    def forward(self, *args, **kwargs):
        return self.module(*args, **kwargs)


class MergedSuperLayer(nn.ModuleList):
    def __init__(self, modules):
        super().__init__(modules)

    def forward(self, *args, **kwargs):
        outputs = []
        for module in self:
            outputs.append(module(*args, **kwargs))
        return outputs
