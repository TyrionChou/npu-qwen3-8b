# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from typing import Dict, Iterable, List, Optional, Union
import os
import json

import torch
from torch import nn
import numpy as np
from transformers.modeling_outputs import CausalLMOutputWithPast
from transformers.utils import ModelOutput

import atb_llm.nn as atb_llm_nn
from atb_llm.nn.ops import Ops
from ..models import get_model
from ..models.base.base_lm import BaseLM
from ..utils import file_utils
from ..utils.configuration_utils import GraphType
from ..utils.dist import initialize_distributed
from ..utils.weights import Weights
from ..utils.loader.weight_loader import WeightLoader
from ..utils.env import ENV
from ..utils.cpu_binding import bind_cpus
from ..utils.initial import NPUSocInfo, load_atb_speed
from ..utils.log import logger, print_log
from ..utils.log.error_code import ErrorCode
from ..utils.adapter_manager import AdapterManager
from ..utils.mapping import Mapping
from ..nn.network import Tensor, get_default_net

DEFAULT_CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'conf', 'config.json')


MAX_POSITION_NUM = 2048


class ModelRunner:
    """
    Class for running model.

    Class attributes:
        model (nn.Module, optional): Model instance, defaults to None.
        soc_info (NPUSocInfo, optional): SOC info instance, defaults to None.
        head_size (int, optional): Head size of multi-head attention, defaults to None.
        num_heads (int, optional): Number of head of multi-head attention, defaults to None.
        num_kv_heads (int, optional): Number of key-value heads, defaults to None.
        num_layers (int, optional): Number of layers, defaults to None.
        device (torch.device, optional): Device to run the model, defaults to None.
        dtype (torch.dtype, optional): Dtype of data, defaults to None.
        k_head_size (int, optional): Head size of key head in multi-head attention, defaults to None.
        v_head_size (int, optional): Head size of value head in multi-head attention, defaults to None.
    
    Args:
        model_name_or_path (str): Model name or path.
        rank (int): Rank of current process.
        world_size (int): World size of multi process.
        npu_id (int, optional): NPU id of current process, defaults to None.
        local_rank (int, optional): Local rank of current process, defaults to None.
        is_flash_causal_lm (bool, optional): Whether to use flash causal lm, defaults to True.
        load_tokenizer (bool, optional): Whether to load tokenizer, defaults to True.
        max_position_embeddings (int, optional): Max positionembeddings, defaults to None.
        tokenizer_path (str, optional): Tokenizer path, defaults to None.
        llm_config_path: (str, optional): Llm config path, defaults to None.
        **kwargs (dict, optional): Additional keyword arguments.
    """
    model: Optional[nn.Module] = None
    soc_info: Optional[NPUSocInfo] = None
    head_size: Optional[int] = None
    num_heads: Optional[int] = None
    num_kv_heads: Optional[int] = None
    num_layers: Optional[int] = None
    device: Optional[torch.device] = None
    dtype: Optional[torch.dtype] = None
    k_head_size: Optional[int] = None
    v_head_size: Optional[int] = None

    def __init__(self,
                 model_name_or_path: str,
                 rank: int,
                 world_size: int,
                 npu_id: Optional[int] = None,
                 local_rank: Optional[int] = None,
                 is_flash_causal_lm: bool = True,
                 load_tokenizer: bool = True,
                 max_position_embeddings: Optional[int] = None,
                 tokenizer_path: Optional[str] = None,
                 enable_edge: bool = False,
                 llm_config_path: str = None,
                 models_dict: dict = None,
                 **kwargs):
        self.model_name_or_path = model_name_or_path
        self.rank = rank
        self.local_rank = local_rank if local_rank is not None else rank
        self.npu_id = npu_id if npu_id is not None else self.local_rank
        self.world_size = world_size
        self.inference_mode = kwargs.get("inference_mode")
        self.plugin_params = kwargs.get("plugin_params", None)
        self.enable_atb_torch = kwargs.get("enable_atb_torch", False)
        self.trust_remote_code = kwargs.get("trust_remote_code", False)
        self.num_speculative_tokens = kwargs.get('num_speculative_tokens', None)
        self.distributed_enable = kwargs.get("distributed_enable", False)
        self.max_batch_size = kwargs.get("max_batch_size", -1)
        load_atb_speed()

        if ENV.bind_cpu:
            try:
                bind_cpus(world_size, self.npu_id, ratio=1.0)
            except RuntimeError as e:
                print_log(rank, logger.info, e)
            except ValueError as e:
                print_log(rank, logger.info, e)
            except Exception as _:
                print_log(rank, logger.info, 'Skip binding cpu.')

        enable_refactor = False
        if self.inference_mode is not None:
            enable_refactor = getattr(self.inference_mode, "enable_refactor", False)

        router_ins = get_model(model_name_or_path, is_flash_causal_lm=is_flash_causal_lm, load_tokenizer=load_tokenizer,
                               max_position_embeddings=max_position_embeddings, revision=None,
                               tokenizer_path=tokenizer_path, trust_remote_code=self.trust_remote_code,
                               enable_atb_torch=self.enable_atb_torch, enable_edge=enable_edge,
                               enable_refactor=enable_refactor,
                               llm_config_path=llm_config_path, models_dict=models_dict)
        self.model_cls = router_ins.model_cls
        self.config = router_ins.config
        self.tokenizer = router_ins.tokenizer
        self.input_builder = router_ins.input_builder
        self.postprocessor = router_ins.postprocessor
        self.config_dict = router_ins.config_dict
        self.enable_atb_torch = router_ins.enable_atb_torch
        self.llm_config = router_ins.llm_config

        if hasattr(self.config, "max_position_embeddings"):
            self.max_position_embeddings = self.config.max_position_embeddings
        else:
            self.max_position_embeddings = MAX_POSITION_NUM
        self.dtype = self.config.torch_dtype
        self.quantize = self.config.quantize
        self.is_gqa = hasattr(self.config, "num_key_value_heads") and \
            hasattr(self.config, "num_attention_heads") and \
            self.config.num_attention_heads != self.config.num_key_value_heads
        self.kv_quant_type = self.config.quantization_config.kv_quant_type
        self.fa_quant_type = self.config.quantization_config.fa_quant_type
        self.kv_cache_dtype = torch.int8 if self.kv_quant_type is not None or \
            self.fa_quant_type is not None else self.dtype
        
        if self.dtype not in [torch.float16, torch.bfloat16]:
            error_msg = "`torch_dtype` is only supported for type `float16` and" \
                " `bfloat16`, loaded from config.json -> torch_dtype. " \
                "The specific types supported by each model are different, please refer to the model README file."
            logger.error(error_msg, ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE)
            raise NotImplementedError(error_msg)

        print_log(rank, logger.info, f'model_runner.quantize: {self.quantize}, '
                                     f'model_runner.kv_quant_type: {self.kv_quant_type}, '
                                     f'model_runner.fa_quant_type: {self.fa_quant_type}, '
                                     f'model_runner.dtype: {self.dtype}', need_filter=True)
    
        self.adapter_manager = None
        self.lora_adapter = None
        self.attn_mask = None
        lora_modules = kwargs.get("lora_modules", None)
        lora_adapter_json_path = os.path.join(model_name_or_path, "lora_adapter.json")
        if lora_modules is not None:
            self.lora_adapter = json.loads(lora_modules)
        elif os.path.exists(lora_adapter_json_path):
            lora_adapter_json_path = file_utils.standardize_path(lora_adapter_json_path, check_link=False)
            file_utils.check_file_safety(lora_adapter_json_path)
            with file_utils.safe_open(lora_adapter_json_path, mode="r", encoding="utf-8") as f:
                self.lora_adapter = json.load(f)

        self.mapping = Mapping(world_size=world_size, rank=rank, llm_config=self.llm_config, **kwargs)
        self.process_group, self.device = initialize_distributed(self.rank, self.npu_id, world_size)
        torch.npu.set_compile_mode(jit_compile=False)
        self.kvcache_quant_layers = []
        print_log(rank, logger.info, 'init tokenizer done')

        self.dp_all_gather_engine = None

    def load_weights(self, **kwargs):
        """Load weights from file."""
        weights = Weights(
            self.model_name_or_path, self.device, self.dtype,
            process_group=self.process_group,
            quantize=self.quantize,
            is_gqa=self.is_gqa,
            extension=".safetensors",
            mapping=self.mapping,
            **kwargs
        )
        if self.llm_config.llm.engine.graph == GraphType.PYTHON:
            weights = WeightLoader(
                self.model_name_or_path,
                self.device,
                self.dtype,
                self.process_group,
                self.quantize,
                self.mapping
            )
        if "OMP_NUM_THREADS" not in os.environ and self.world_size > 1:
            os.environ["OMP_NUM_THREADS"] = "1"
        try:
            self.model = self.model_cls(self.config,
                                        weights,
                                        inference_mode=self.inference_mode,
                                        plugin_params=self.plugin_params,
                                        trust_remote_code=self.trust_remote_code,
                                        lora_adapter=self.lora_adapter,
                                        enable_python_engine=self.llm_config.llm.engine.graph == GraphType.PYTHON,
                                        num_speculative_tokens=self.num_speculative_tokens,
                                        distributed_enable=self.distributed_enable,
                                        max_batch_size=self.max_batch_size,
                                        llm_config=self.llm_config)
        except TypeError as e:
            print_log(self.rank, logger.warning, f'init model: {e}')
            self.model = self.model_cls(self.config, weights)
        if hasattr(self.model, "kvcache_quant_layers"):
            self.kvcache_quant_layers = self.model.kvcache_quant_layers
        if not isinstance(self.model, BaseLM) and self.lora_adapter is not None:
            self.model.adapter_manager = AdapterManager(weights)
            self.model.update_adapter_manager()
            self.model.adapter_manager.preload_adapter(self.lora_adapter)
            self.adapter_manager = self.model.adapter_manager
        if isinstance(self.model, BaseLM) and self.lora_adapter is not None:
            self.adapter_manager = self.model.lora_decorator.adapter_manager
            self.adapter_manager.preload_adapter(self.lora_adapter)
        if isinstance(self.model, BaseLM):
            self.attn_mask = self.model.attn_mask_info.generator
        else:
            self.attn_mask = getattr(self.model, "attn_mask", None)

        self.model.to(weights.device)
        weights.release_file_handler()

        if self.adapter_manager is not None:
            if self.adapter_manager.lora_weights_loader is not None:
                self.adapter_manager.lora_weights_loader.release_file_handler()
            self.adapter_manager.prepare_adapter_weights()
        if self.enable_atb_torch and not isinstance(self.model, BaseLM):
            self.model.init_graph()
        if isinstance(self.model, BaseLM):
            self.model.build_engines()

        self.soc_info = self.model.soc_info
        if isinstance(self.model, BaseLM):
            self.head_size = self.model.config_metadata.head_dim
            self.num_heads = self.model.config_metadata.num_attention_heads
            self.num_kv_heads = self.model.config_metadata.num_key_value_heads
            self.num_layers = self.model.config_metadata.num_hidden_layers
        else:
            self.head_size = self.model.head_size
            self.num_heads = self.model.num_attention_heads
            self.num_kv_heads = self.model.num_key_value_heads
            self.num_layers = self.model.num_layers

        # not equal k v length for mla
        if hasattr(self.model, 'kv_lora_rank') and hasattr(self.model, 'qk_rope_head_dim'):
            if self.soc_info.soc_version == 202 and self.config.model_type == "minicpm3":      # MiniCPM3-4B_310P
                self.k_head_size = self.model.qk_nope_head_dim + self.model.qk_rope_head_dim
                self.v_head_size = self.model.qk_nope_head_dim + self.model.qk_rope_head_dim
            else:    # deepseekv2/v3/r1
                self.num_kv_heads = 1
                self.k_head_size = self.model.kv_lora_rank
                self.v_head_size = self.model.qk_rope_head_dim
        else:
            self.k_head_size = self.head_size
            self.v_head_size = self.head_size

        print_log(self.rank, logger.info, f'model:\n {self.model}')

    def init_gather_dp_graph(self):
        # gather
        padded = Ops.gather(Tensor("accept_lens_next_tokens"), Tensor("padding"), axis=0)
        # allgather
        all_gather_out = atb_llm_nn.distributed.all_gather(send_tensor=padded, 
            rank=self.mapping.attn_dp.rank, rank_size=self.mapping.attn_dp.group_size,
            rank_ids=self.mapping.attn_dp.rank_per_group[self.mapping.attn_dp.current_group_id],
            rank_table_file=ENV.rank_table_file,
            group_id=self.mapping.attn_dp.current_group_id,
            buffer_size=self.mapping.attn_dp.buffer_size)
        all_gather_out_ = all_gather_out.reshape(lambda org_shape: [org_shape[0] * org_shape[1], org_shape[2]])
        # gather
        unpad = Ops.gather(all_gather_out_, Tensor("unpadding"), axis=0)
        # split
        reordered_accept_lens, reordered_next_tokens = Ops.split(unpad, split_dim=1, split_num=2, 
                                                                    split_sizes=[1, (ENV.deepseek_mtp + 1)])
        get_default_net().mark_output(reordered_accept_lens, "reordered_accept_lens")
        get_default_net().mark_output(reordered_next_tokens, "reordered_next_tokens")
        self.dp_all_gather_engine = get_default_net().build_engine()

    def build_inputs(self, conversations: List[List[Dict[str, str]]], **kwargs) -> list:
        """Build inputs for model."""
        return [self.input_builder.make_context(self.rank, conversation, **kwargs) for conversation in conversations]

    def forward(self, **kwargs) -> Union[CausalLMOutputWithPast, tuple]:
        """Call model's forward pass."""
        res = self.model.forward(**kwargs)
        if ENV.enable_dp_partition_up and self.mapping.has_dp() and self.dp_all_gather_engine is None:
            self.init_gather_dp_graph()
        return res

    def dap_forward(self, **kwargs):
        return self.model.dap_forward(**kwargs)

    def generate(self, **kwargs) -> Union[ModelOutput, torch.LongTensor]:
        """Generate output text via calling model's generate method."""
        return self.model.generate(**kwargs)

    def generate_position_ids(self, input_ids: np.ndarray) -> Iterable:
        """Generate position ids."""
        return self.input_builder.generate_position_ids(input_ids)

    def save_pretrained(self, **kwargs):
        """Save pretrained model."""
        save_directory_key = 'save_directory'
        if save_directory_key not in kwargs:
            raise ValueError(f'{save_directory_key} is required')
        kwargs[save_directory_key] = os.path.join(kwargs[save_directory_key], f'part{self.rank}-of-{self.world_size}')
        self.model.save_pretrained(**kwargs)
