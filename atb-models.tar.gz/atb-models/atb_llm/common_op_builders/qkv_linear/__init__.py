# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from atb_llm.common_op_builders.common_op_builder_manager import CommonOpBuilderManager
from atb_llm.common_op_builders.qkv_linear.mha_pack_common_op_builder import MhaPackCommonOpBuilder
from atb_llm.common_op_builders.qkv_linear.gqa_pack_common_op_builder import GqaPackCommonOpBuilder
from atb_llm.common_op_builders.qkv_linear.no_pack_common_op_builder import NoPackCommonOpBuilder


CommonOpBuilderManager.register(MhaPackCommonOpBuilder)
CommonOpBuilderManager.register(GqaPackCommonOpBuilder)
CommonOpBuilderManager.register(NoPackCommonOpBuilder)