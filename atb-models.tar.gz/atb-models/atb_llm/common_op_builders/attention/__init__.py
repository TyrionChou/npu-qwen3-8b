# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from atb_llm.common_op_builders.common_op_builder_manager import CommonOpBuilderManager
from atb_llm.common_op_builders.attention.atb_decoder_paged_attention_common_op_builder import \
    ATBDecoderPagedAttentionCommonOpBuilder
from atb_llm.common_op_builders.attention.atb_encoder_paged_attention_common_op_builder import \
    ATBEncoderPagedAttentionCommonOpBuilder
from atb_llm.common_op_builders.attention.atb_flash_attention_common_op_builder import \
    ATBFlashAttentionCommonOpBuilder

CommonOpBuilderManager.register(ATBDecoderPagedAttentionCommonOpBuilder)
CommonOpBuilderManager.register(ATBEncoderPagedAttentionCommonOpBuilder)
CommonOpBuilderManager.register(ATBFlashAttentionCommonOpBuilder)
