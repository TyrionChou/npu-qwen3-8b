# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from atb_llm.common_op_builders.common_op_builder_manager import CommonOpBuilderManager
from atb_llm.common_op_builders.linear_parallel.all_reduce_linear_parallel_common_op_builder import \
    AllReduceLinearParallelCommonOpBuilder
from atb_llm.common_op_builders.linear_parallel.all_gather_linear_parallel_common_op_builder import \
    AllGatherLinearParallelCommonOpBuilder
from atb_llm.common_op_builders.linear_parallel.lcoc_linear_parallel_common_op_builder import \
    LCOCLinearParallelCommonOpBuilder


CommonOpBuilderManager.register(LCOCLinearParallelCommonOpBuilder)
CommonOpBuilderManager.register(AllGatherLinearParallelCommonOpBuilder)
CommonOpBuilderManager.register(AllReduceLinearParallelCommonOpBuilder)
