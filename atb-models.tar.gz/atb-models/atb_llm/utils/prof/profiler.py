# Copyright Huawei Technologies Co., Ltd. 2025-2025. All rights reserved


try:
    import functools
    from ..log.logging import logger
    from atb_llm.utils.env import ENV
    from ms_service_profiler import Profiler, Level
    from ms_service_profiler.mstx import service_profiler

    if ENV.framework_backend.lower() == 'ms':
        import mindspore
        npu = mindspore.hal
    else:
        import torch
        import importlib
        importlib.import_module('torch_npu')
        npu = torch.npu

    def no_error(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as err:
                logger.debug(f"[prof error] {err}")
                return None
        return wrapper

    @no_error
    def span_start(name, sync=False, *args, **kwargs):
        if sync and service_profiler.is_enable(Level.INFO):
            npu.synchronize()
        return Profiler(Level.INFO).span_start(name)

    @no_error
    def span_end(prof, sync=False, *args, **kwargs):
        if sync and service_profiler.is_enable(Level.INFO):
            npu.synchronize()
        return prof.span_end()

    @no_error
    def span_req(prof, req_list):
        return prof.res([{"rid": str(rid)} for rid in req_list])

except ImportError:

    def span_start(*args, **kwargs):
        return 0

    def span_end(*args, **kwargs):
        pass

    def span_req(prof, req_list):
        pass
