# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
import torch
from torch import nn
import numpy as np
import torch_npu

from ..layers.linear.linear_utils import LinearUtils
from .pack_type import TransposeType
from .quant_type import LinearTypeV2
from .w4a16 import int42int8


class W4A8LinearDynamic(nn.Module, LinearUtils):
    def __init__(self, weight, scale, scale_second, offset=None, offset_second=None):
        super().__init__()
        super(nn.Module, self).__init__()

        self.weight_quant_name = 'w4a8_dynamic'
        self.linear_desc = LinearTypeV2.W4A8_DYNAMIC

        # per group 推荐不Transpose，per channel转置
        self.trans_flag = TransposeType.NOT_TRANSPOSE

        weight_in_k_n = weight.transpose(-1, -2).contiguous()  # k, n
        scale_in_k_n, scale_second_in_k_n = scale.transpose(-1, -2), scale_second.transpose(-1, -2) # k, n

        weight_trans = weight_in_k_n if self.trans_flag == TransposeType.NOT_TRANSPOSE \
            else weight_in_k_n.transpose(-1, -2).contiguous()
        
        scale_uint32, bias = self.process_scale(weight_in_k_n, scale_in_k_n, scale_second_in_k_n)
        weight_compact = int42int8(weight_trans)  # [k, n // 2] or [n, k // 2]
        
        self.register_buffer('weight', weight_compact.to(torch.int8))

        self.register_buffer('weight_scale', scale_uint32)

        if bias.dtype == torch.bfloat16:
            bias = bias.to(torch.float32)
        self.register_buffer('bias', bias)
        self.has_bias = True
            
        if offset is not None:
            self.register_buffer('weight_offset', (-offset)
                                 if self.trans_flag == TransposeType.TRANSPOSE
                                 else (-offset).transpose(-1, -2).contiguous())

    def weight_format_cast(self, tensor, enable_nz=False, nd_weight=False):
        need_nz = enable_nz or self.soc_info.need_nz or self.soc_info.matmul_nd_nz
        if need_nz and not nd_weight:
            torch.npu.config.allow_internal_format = True
            torch_npu.npu_format_cast_(tensor, 29)
        return tensor

    def process_scale(self, weight: torch.Tensor, scale, per_group_scale):
        group_num, k, n = weight.shape  
        per_group_scale = per_group_scale.reshape(group_num, -1, n)
        group_num, quantgroup_num, n = per_group_scale.shape
        weight_high = weight.to(torch.float32).reshape([group_num, quantgroup_num, -1, n]) * \
            per_group_scale.reshape([group_num, quantgroup_num, 1, n])
        weight_high = weight_high.reshape([group_num, k, n]) 
        bias = 8 * (weight_high.to(torch.float32) * scale).sum(axis=1)
        scale_fp32 = (scale * per_group_scale).to(torch.float16).to(torch.float32)
        scale_fp32_np = scale_fp32.numpy()
        scale_fp32_np.dtype = np.uint32
        sscale_uint64 = np.zeros((group_num, quantgroup_num, n * 2), dtype=np.uint32) 
        
        sscale_uint64[..., ::2] = scale_fp32_np
        
        sscale_uint64_buffer = np.frombuffer(sscale_uint64.tobytes(), dtype=np.int64).copy()
        sscale_uint64_tensor = torch.from_numpy(sscale_uint64_buffer).reshape(group_num, quantgroup_num, n)
        return sscale_uint64_tensor, bias