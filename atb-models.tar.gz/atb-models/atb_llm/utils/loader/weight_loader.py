# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
# Part of this file was copied from project text-generation-inference 0.9.1
import json
import os
from typing import List
from enum import Enum
from pathlib import Path

import torch
from safetensors import safe_open

from ..quantize.quant_type import QuantType, LinearTypeV2, QUANTIZE_DESC_REQUIRED_LIST
from .. import file_utils
from ..singleton import Singleton


class ProcessGroupType(Enum):
    ATTN = "attn"
    MLP = "mlp"


class FileHandler(Singleton):
    def __init__(self, rank):
        self.rank = rank
        self._handlers = {}

    def release_file_handler(self):
        if self._handlers:
            del self._handlers
            self._handlers = {}

    def get_handler(self, filename):
        if filename not in self._handlers:
            f = safe_open(filename, framework="pytorch")
            self._handlers[filename] = f
        return self._handlers[filename]


def get_weight_filenames(
        model_weight_path: str, extension: str = ".safetensors"
) -> List[Path]:
    """Get the local files"""
    if Path(model_weight_path).exists() and Path(model_weight_path).is_dir():
        local_files = list(Path(model_weight_path).glob(f"*{extension}"))
        if not local_files:
            raise FileNotFoundError(
                f"No local weights found in {model_weight_path} with extension {extension};"
                f"Only safetensor format is supported. Please refer to model's README for more details."
            )
        return local_files
    raise FileNotFoundError("The input model id is not exists or not a directory")


def load_weight_file_routing(weight_filenames: List[str]):
    routing = {}
    for filename in weight_filenames:
        filename = file_utils.standardize_path(str(filename), check_link=False)
        file_utils.check_path_permission(filename)
        with safe_open(filename, framework="pytorch") as f:
            for k in f.keys():
                if k in routing:
                    raise AssertionError(f"Key {k} was found in multiple files: {filename} and {routing[k]}")
                routing[k] = filename
    return routing


def get_quant_descs(model_weight_path: str, quantize):
    if quantize not in QUANTIZE_DESC_REQUIRED_LIST:
        return None
    try:
        filename = os.path.join(model_weight_path, f'quant_model_description_{quantize}.json')
        with file_utils.safe_open(filename, 'r') as f:
            quant_descs = json.load(f)
        return quant_descs
    except Exception as err:
        raise AssertionError from err


class WeightLoader:
    def __init__(
            self,
            model_name_or_path,
            device,
            dtype,
            process_group,
            quantize=None,
            mapping=None,
            **kwargs
    ):
        self.device = device
        self.dtype = dtype
        self.mapping = mapping
        self.process_group = process_group
        self.process_group_dict = {
            ProcessGroupType.ATTN: process_group,
            ProcessGroupType.MLP: process_group
        }

        if quantize == QuantType.W8A8SC:
            model_name_or_path = os.path.join(model_name_or_path,
                                              f'part{process_group.rank()}-of-{process_group.size()}'
            )
            model_name_or_path = file_utils.standardize_path(model_name_or_path, check_link=False)
            file_utils.check_path_permission(model_name_or_path)
        self.model_name_or_path = model_name_or_path
        self.filenames = get_weight_filenames(model_name_or_path, extension=".safetensors")
        self.routing = load_weight_file_routing(self.filenames)
        self._file_handle = FileHandler(self.process_group.rank())

        self.quantize = quantize
        self.quant_desc = get_quant_descs(model_name_or_path, quantize)

    def release_file_handler(self):
        self._file_handle.release_file_handler()

    def get_linear_quant_type(self, key):
        if self.quant_desc is None:
            return LinearTypeV2.FLOAT16 if self.dtype == torch.float16 else LinearTypeV2.BFLOAT16
        if self.quant_desc.get(key, "INVALID") == "FLOAT":
            return LinearTypeV2.FLOAT16 if self.dtype == torch.float16 else LinearTypeV2.BFLOAT16
        return LinearTypeV2[self.quant_desc.get(key, "INVALID")]

    def get_shape(self, tensor_name: str):
        return self._get_slice(tensor_name).get_shape()

    def get_tensor(self, tensor_name: str):
        filename, tensor_name = self._get_filename(tensor_name)
        f = self._get_handle(filename)
        tensor = f.get_tensor(tensor_name)
        return tensor

    def get_sharded(self, tensor_name: str, dim: int):
        num_parallel_group = self.process_group.size()
        rank = self.process_group.rank()

        slice_ = self._get_slice(tensor_name)
        group_size = slice_.get_shape()[dim]
        if group_size < num_parallel_group:
            raise ValueError(
                f"The size of the tensor {tensor_name} intended for parallel processing is smaller than "
                f"the number of groups designated for parallelism.")

        block_size = group_size // num_parallel_group
        start = rank * block_size
        stop = (rank + 1) * block_size

        if dim == 0:
            tensor = slice_[start:stop]
        elif dim == 1:
            tensor = slice_[:, start:stop]
        else:
            raise AssertionError(f"Dimension {dim} is invalid in `get_sharded`.")
        return tensor

    def _get_filename(self, tensor_name: str) -> (str, str):
        filename = self.routing.get(tensor_name)
        return str(filename), tensor_name

    def _get_handle(self, filename):
        return self._file_handle.get_handler(filename)

    def _get_slice(self, tensor_name: str):
        filename, tensor_name = self._get_filename(tensor_name)
        f = self._get_handle(filename)
        slice_ = f.get_slice(tensor_name)
        return slice_
