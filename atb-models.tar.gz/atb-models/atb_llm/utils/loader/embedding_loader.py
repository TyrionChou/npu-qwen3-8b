# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from .weight_loader import WeightLoader
from ...layers import SuperLayer
from ...layers.embedding.word_embedding import WordEmbedding
from ...models.base.config import BaseConfig


class ParallelEmbedding(SuperLayer):
    @classmethod
    def load(cls, config: BaseConfig, weight_loader: WeightLoader, prefix: str, **kwargs):
        embed_module = WordEmbedding(prefix, config)
        embed_module.weight.load_parallel_weight(weight_loader, [prefix], dim=1, **kwargs)
        return cls(embed_module)


class ReplicatedEmbedding(SuperLayer):
    @classmethod
    def load(cls, config: BaseConfig, weight_loader: WeightLoader, prefix: str, **kwargs):
        embed_module = WordEmbedding(prefix, config)
        embed_module.weight.load_whole_weight(weight_loader, [prefix], **kwargs)
        return cls(embed_module)
