# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from .weight_loader import WeightLoader
from ...models.base.config import BaseConfig
from ...layers import SuperLayer
from ... import nn


class Norm(SuperLayer):
    @classmethod
    def _load(cls, norm_cls: nn.modules.Module, config: BaseConfig, weight_loader: WeightLoader, prefix: str, **kwargs):
        norm_module = norm_cls(prefix, config.epsilon, config.torch_dtype)
        for _, parameter in norm_module.named_parameters():
            if isinstance(parameter, nn.Parameter):
                parameter.load_whole_weight(weight_loader, [prefix], **kwargs)
        return cls(norm_module)


class RmsNorm(Norm):
    @classmethod
    def load(cls, config: BaseConfig, weight_loader: WeightLoader, prefix: str, **kwargs):
        return cls._load(nn.modules.RmsNorm, config, weight_loader, prefix, **kwargs)
