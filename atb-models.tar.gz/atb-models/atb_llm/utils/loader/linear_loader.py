# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import List

from .weight_loader import WeightLoader
from ..quantize.quant_type import LinearTypeV2
from ...models.base.config import BaseConfig
from ...layers import SuperLayer, MergedSuperLayer
from ... import nn


LINEAR_MODULE_ROUTER = {
    LinearTypeV2.FLOAT16: nn.modules.Linear,
    LinearTypeV2.BFLOAT16: nn.modules.Linear
}


class RowParallelLinear(SuperLayer):
    @classmethod
    def load(cls, config: BaseConfig, weight_loader: WeightLoader, prefixes: List[str], bias=False, **kwargs):
        linear_quant_type = weight_loader.get_linear_quant_type(f"{prefixes[0]}.weight")
        linear_cls = LINEAR_MODULE_ROUTER.get(linear_quant_type)
        linear_module = linear_cls("_".join(prefixes), config.torch_dtype, bias=bias)
        for _, parameter in linear_module.named_parameters():
            if isinstance(parameter, nn.Parameter):
                parameter.load_parallel_weight(weight_loader, prefixes, dim=1, **kwargs)
        return cls(linear_module)


class ColumnParallelLinear(SuperLayer):
    @classmethod
    def load(cls, config: BaseConfig, weight_loader: WeightLoader, prefixes: List[str], bias=False, **kwargs):
        linear_quant_type = weight_loader.get_linear_quant_type(f"{prefixes[0]}.weight")
        linear_cls = LINEAR_MODULE_ROUTER.get(linear_quant_type)
        linear_module = linear_cls("_".join(prefixes), config.torch_dtype, bias=bias)
        for _, parameter in linear_module.named_parameters():
            if isinstance(parameter, nn.Parameter):
                parameter.load_parallel_weight(weight_loader, prefixes, dim=0, **kwargs)
        return cls(linear_module)


class MergedColumnParallelLinear(MergedSuperLayer):
    @classmethod
    def load(cls, config: BaseConfig, weight_loader: WeightLoader, prefixes: List[str], bias=False, **kwargs):
        linear_quant_types = []
        for prefix in prefixes:
            linear_quant_types.append(weight_loader.get_linear_quant_type(f"{prefix}.weight"))
        if len(set(linear_quant_types) - {LinearTypeV2.INVALID, }) == 1:
            return cls([ColumnParallelLinear.load(config, weight_loader, prefixes, bias)])
        else:
            module_list = []
            for prefix in prefixes:
                module_list.append(ColumnParallelLinear.load(config, weight_loader, prefix, bias))
            return cls(module_list)
