# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
import math
import json
from enum import Enum
from .log import logger


class EPLBType(int, Enum):
    NO_EPLB = 0
    STATIC_EPLB = 1
    DYNAMIC_EPLB = 2 # not supported yet
    FORCE_EPLB = 3 # no accuracy guarantee in the forced load balance case


def assign(expert_count, world_size):
    per_device = math.ceil(expert_count / world_size)
    assignment = []
    if expert_count % world_size == 0:
        for i in range(world_size):
            assignment.append([i * per_device + j for j in range(per_device)])
    else:
        for i in range(world_size - 1):
            assignment.append([i * per_device + j for j in range(per_device)])
        assignment.append([])
        for i in range(expert_count % world_size):
            assignment[-1].append(per_device * (world_size - 1) + i)
    return assignment


def is_ep_file_valid(ep_file_path, n_device=1, layer_id=0):
    import os
    if (not os.path.exists(ep_file_path)):
        logger.error(f"EPLB file path '{ep_file_path}' does not exist.")
        return False
    flag_current_layer_exist = False
    with open(ep_file_path) as handle:
        ep_file = json.load(handle)
        if ("moe_layer_count" not in ep_file or "layer_list" not in ep_file):
            logger.error("Required fields 'moe_layer_count' or 'layer_list' are missing.")
            return False
        
        layer_count = ep_file["moe_layer_count"]
        layer_list = ep_file["layer_list"]
        if (len(layer_list) != layer_count or layer_count < 1):
            logger.error(
                f"Invalid 'moe_layer_count'. It should be greater than 0. "
                f"Found: {layer_count}, but 'layer_list' has {len(layer_list)} elements."
                )
            return False
        
        for list_idx in range(layer_count):
            layer_info = layer_list[list_idx]
            if ("layer_id" not in layer_info or "device_count" not in layer_info or
                "device_list" not in layer_info):
                logger.error(
                    f"Missing required fields "
                    f"'layer_id', 'device_count', or 'device_list' in layer {list_idx}."
                    )
                return False
            if layer_id == int(layer_info["layer_id"]):
                flag_current_layer_exist = True
            device_count = layer_info["device_count"]
            device_list = layer_info["device_list"]
            if (len(device_list) != device_count or device_count < 1 or n_device != device_count):
                logger.error(
                    f"Mismatch in device list. "
                    f"Expected {n_device} devices, "
                    f"but found {device_count} devices in layer {list_idx}."
                    )
                return False
            
            for device_list_idx in range(device_count):
                device_info = device_list[device_list_idx]
                if ("device_id" not in device_info or "device_expert" not in device_info):
                    logger.error(
                        f"Missing 'device_id' or 'device_expert' "
                        f"in device {device_list_idx} of layer {list_idx}."
                        )
                    return False
    if not flag_current_layer_exist:
        logger.error(f"Layer {layer_id} not found in the EPLB balance file.")
    return flag_current_layer_exist


def parse_ep_file(ep_file_path):
    experts_table = []
    with open(ep_file_path) as handle:
        ep_file = json.load(handle)
        layer_count = ep_file["moe_layer_count"]
        layer_list = ep_file["layer_list"]
        
        for layer_list_idx in range(layer_count):
            layer_info = layer_list[layer_list_idx]
            device_count = layer_info["device_count"]
            device_list = layer_info["device_list"]
            layer_expert_table = []

            for device_list_idx in range(device_count):
                device_info = device_list[device_list_idx]
                device_expert = device_info["device_expert"]
                layer_expert_table.append(device_expert)

            experts_table.append(layer_expert_table)
    
    return experts_table
       

def parse_ep_balance_file(ep_file_path, n_device=1, layer_id=0): # ENV.ep_balance_file
    if (is_ep_file_valid(ep_file_path, n_device=n_device, layer_id=layer_id)):
        return parse_ep_file(ep_file_path)
    else:
        logger.error(
            "[moe_util.py] parse_ep_balance_file: " \
            "EPLB balance file is invalid. Please check the file format and contents.")
        return None